
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
typedef pair<int,int> TT;
class water{
	int n,k,m;
	map<TT,TT> D;
	void inkq(TT f)
{
	stack<TT> S;
	do 
	{
	  S.push(f);f=D[f];
    }while(f.first ||f.second); cout<<""
    while(S.size())
    {
      cout<<"("<<S.top().firsrt<<","<<S.top().second<<")->";
      S.pop();
    }
}
void DFS(){
	{
		stack<TT> S;
		S.push(make_pair(0,0));
		D=[{0,0}]={-1,-1};
}
;}
int main() {


}
