
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
typedef pair<int,int> TT;
class water{
	int n,k,m;
	/*map<TT,TT> D;
	void inkq(TT f)
{
	stack<TT> S;
	do 
	{
	  S.push(f);f=D[f];
    }while(f.first!=-1)
    while(S.size())
    {
      cout<<"("<<S.top().firsrt<<","<<S.top().second<<")->";
      S.pop();
    }
}
	*/
	//void DFS()
	int DFS()  // tra ve do sau cua nut tim thay
	// int BFF()
	{
		stack<TT> S; //queue<TT>.S (use: BFF)
		map<TT,int> D; //version 2 : map<TT,TT> D; // mang cha D[{3,2}]={0,5}
		S.push(make_pair(0,0));   // C2: S.push({0,0}) C3: S.push(TT(0,0))
		D[{0,0}]=0; // D=[{0,0}]={-1,-1};
		while (S.size())
		{
			int x=S.top().first, y=S.top().second,z=x+y;
			// int x=S.front().first, y=S.front().second,z=x+y;
			S.pop();
			TT Next[6]={{0,y},{x,0},{n,y},{x,m},{max(0,z-m), min(z,m)},{min(z,n), max(0,z-n)}} ;
			for(auto v:Next)
			if(D.find(v) ==D.end())
			{
				S.push(v);
				D[v]=D[{x,y}]+1; //D[v]={x,y};
				 if(v.first ==k || v.second ==k) // inkq(v); return ;
				  return D[v];
			}
		}
		return -1;
    }
public: void sol()
{
	cin>>n>>m>>k;
	int res=DFS();
	if(res==-1) cout<<"\nkhong dong duoc nuoc";
	else cout<<res;
}
};   
int main() {
water W;
W.sol();
}
