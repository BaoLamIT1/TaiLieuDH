/*
Thuật toán DFS( Depth First Search)
   Thuật toán tìm kiếm trong không gian trạng thái . K=(S , &,F,R)
   với S- tập các trạng thái
   & thuộc S: trạng thái xuất phát
    F tập con S: tập trạng thái kết
    R: S-> S quy tắc biến đổi
         
    Minh hoạ n =3 , n=5.
    (x,y) ->(0,y)
          ->(x,0)
          ->(n,y)
          ->(x,m)
    1-2   ->(0,x+y)
    1-2   ->(x+y-m,m)
    2-1   ->(x+y,0)
    2-1   ->(n,x+y-n)
Sơ đồ chung của thuật toán DFS
procedure DFS(K=(5,3,F,R))
Begin 
    Stalk = rỗng
    D = rỗng
    Stack, push(&)
    D[3]=true
    While(Stack khác rỗng) do
    Begin 
       u=Stack top()
       Stack pop()
        for each v thuộc R[u] do
        if D[v] ==false than
        By  Stack push(v)
            D[v]= true
        End  if(v thuộc F)  return true
        return False
    End
*/