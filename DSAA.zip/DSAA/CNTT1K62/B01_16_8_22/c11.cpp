#include<bits/stdc++.h>
using namespace std;
class hcn
{
	public:
	int d,r;
	void nhap()
	{
		cout<<"Nhap dai :"; cin>>d;
		cout<<"Nhap rong :"; cin>>r;
	}
	int dtich() {return d*r;}
};
int main()
{
	hcn A;
	A.nhap();
	cout<<"Chieu dai "<<A.d<<" chieu rong "<<A.r;
	cout<<"\nDien tich "<<A.dtich();
}


