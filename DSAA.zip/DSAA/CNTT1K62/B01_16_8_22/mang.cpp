#include<bits/stdc++.h>
using namespace std;
void nhap(int &n,int *&a)
{
	cin>>n;
	a=new int [n];
	for(int i=0;i<n;i++) cin>>a[i];
}
void xuat(int n,int *a) 
{
	for(int i=0;i<n;i++) cout<<a[i]<<" ";
}
int main()
{
	int *x,*y,n,m;
	nhap(n,x);
	nhap(m,y);
	cout<<"\nx :"; xuat(n,x);
	cout<<"\ny :"; xuat(m,y);
	delete []x;delete[]y;
}


