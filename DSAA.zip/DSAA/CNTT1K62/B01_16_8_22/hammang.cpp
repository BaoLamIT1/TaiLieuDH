#include<bits/stdc++.h>
using namespace std;
void nhap(int **p,int *q)
{
	cin>>(*q);  //nhap n;
	*p=new int[*q];  //cap phat bo nho dong
	for(int i=0;i<*q;i++) cin>>(*p)[i];
}
void xuat(int *p,int n)
{
	for(int i=0;i<n;i++) cout<<p[i];
}
int main()
{
	int *a,n;
	nhap(&a,&n);
	cout<<"\nDay so: "; xuat(a,n);
	delete []a;
}


