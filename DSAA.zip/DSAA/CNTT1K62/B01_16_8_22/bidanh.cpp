//bi danh trong C++
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int x;  //
	cout<<"Dia chi x : "<<&x;
	int &y=x;  //y la bi danh cua x
	cout<<"\nDia chi y : "<<&y;
	x=15343;
	cout<<"\nGia tri y : "<<y;
	

}


