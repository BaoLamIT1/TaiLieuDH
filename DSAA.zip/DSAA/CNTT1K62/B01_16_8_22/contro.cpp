//con tro
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int x,y[10]={1,2,3,4,5},*p;
	p=&x;
	*p=5;  //x=5
	p=&y[0]; 
	*p=7;    //y[0]=7;
	p[0]=8;  //y[0]=0;
	p++;
	*p=6;  //y[1]=6
	for(auto z:y) cout<<z<<" ";
	p=y+5;   //p=p+4 hoac p=&y[5]
	p[0]=-1;  //y[5]=-1
	p[-2]=9;  //y[3]=9
	cout<<"\n";for(auto z:y) cout<<z<<" ";
	
}


