#include<bits/stdc++.h>
using namespace std;
int main()
{
	string s="Truong dai hoc Giao thong van tai";
	cout<<"Nhap vao quy danh : ";
	//cin.ignore(1);
	//cin>>s;
	getline(cin,s);  //nhap ca dong
	cout<<"xin chao "<<s;

}


