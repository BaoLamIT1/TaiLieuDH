#include<bits/stdc++.h>
using namespace std;
int main()
{
	char x[30];
	scanf("%[^\n]",x);  //nhap vao den khi gap enter
	printf("x : %s",x);

}


