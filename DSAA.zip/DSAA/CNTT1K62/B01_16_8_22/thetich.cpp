#include<bits/stdc++.h>
using namespace std;
int main()
{
	double r; //tinh the tich hinh cau ban kinh r
	cin>>r;
	cout<<"the tich : "<<setw(40)<<setfill('0')<<setprecision(10)<<fixed<<4.0/3*acos(-1)*r*r*r;

}


