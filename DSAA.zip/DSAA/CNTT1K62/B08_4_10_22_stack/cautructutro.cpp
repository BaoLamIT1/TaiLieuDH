//Cai dat stack bang danh sach lien ket
#include<bits/stdc++.h>
using namespace std;
struct nguoi
{
	string ten;
	int tuoi;
	struct nguoi *bo,*me;
	nguoi(string t="vo danh",int tt=18)
	{
		ten=t;
		tuoi=tt;
		bo=me=NULL;
	}
};
int main()
{
	nguoi X("chi pheo",15),Y("thi no"),*Z=new nguoi("ba kien",12);
	Z->bo=&X;
	Z->me=&Y;
	cout<<"\nX: "<<X.ten<<" "<<X.tuoi;
	cout<<"\nY: "<<Y.ten<<" "<<Y.tuoi;
	cout<<"\nZ: "<<Z->ten<<" "<<(*Z).tuoi;
	cout<<"\nBo cua Z: "<<Z->bo->ten;
	delete Z;

}


