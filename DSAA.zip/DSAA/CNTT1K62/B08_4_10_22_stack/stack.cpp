//Cai dat stack bang danh sach lien ket
#include<bits/stdc++.h>
using namespace std;
#ifndef ___stack__cpp___
#define ___stack__cpp___
template <class T>
struct Node
{
	T elem;
	Node *next;
	Node(T e,Node*N=0){elem=e;next=N;}  //Ham tao 1 Node
};
template <class T>
class STACK
{
	Node<T> *Head;  //Con tro tro vao top
	int n;    	    //size
	public:
		STACK(){Head=NULL;n=0;}
		~STACK(){while(n) pop();}
		int size(){return n;}
		bool empty(){return n==0;}
		void push(T x)
		{
			//Node<T> *p=new Node<T>(x,Head);    Head=p;
			Head=new Node<T>(x,Head);
			n++;
		}
		void pop()
		{
			Node<T> *p=Head; 
			Head=Head->next;
			delete p;
			n--;
		}
		T &top(){return Head->elem;}
};
#endif


//int main()
//{
//	STACK<int> *S=new STACK<int>();
//	for(int x:{234,62,27,63,724,846}) S->push(x);
//	S->top()=0;
//	while(S->size()) {cout<<S->top()<<" "; S->pop();}
//	delete S;
//}
