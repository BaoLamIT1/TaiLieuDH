//danh sach lien ket
#include<bits/stdc++.h>
using namespace std;
struct node
{
	int elem;
	node *next;
	node(int e=0,node *N=NULL)
	{
		elem=e;
		next=N;
	}
};
int main()
{
	node E,D(7,&E),*C=new node(6,&D),*B=new node(4,C),A(3,B);
	//A->*B->*C->D->E
	for(node *p=&A;p!=NULL;p=p->next) cout<<p->elem<<" ";
	delete C;
	delete B; 
}


