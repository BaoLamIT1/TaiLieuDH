//de quy tren mang
#include<bits/stdc++.h>
using namespace std;
void nhap(int *a,int n)
{
	if(n==0) return;
	nhap(a,n-1);
	cout<<"a["<<n<<"]="; cin>>a[n];	
}
void xuat(int *a,int n)
{
	if(n==0) return;
	xuat(a,n-1); 
	cout<<a[n]<<" ";
}
int tong(int *a,int n) {return n==0?0:a[n]+tong(a,n-1);}
void dao(int *a,int u,int v)
{
	if(u>=v) return;
	swap(a[u],a[v]); 
	dao(a,u+1,v-1);
}
void sx(int *a,int n)
{
	if(n<=1) return;
	sx(a,n-1);
	for(int i=n;i>1 && a[i]<a[i-1];i--) swap(a[i],a[i-1]);
}
int main()
{
	int n,a[100];
	cout<<"n = "; cin>>n;	nhap(a,n);
	cout<<"\nDay gom : "; xuat(a,n);
	cout<<"\nTong = "<<tong(a,n);
	dao(a,1,n);
	cout<<"\nDay sau dao : "; xuat(a,n);
	sx(a,n);
	cout<<"\nDay sau sx : "; xuat(a,n);
}


