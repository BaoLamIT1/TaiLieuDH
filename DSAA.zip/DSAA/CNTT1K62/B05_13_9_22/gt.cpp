#include<bits/stdc++.h>
using namespace std;
long long gt(int n)
{
	return n==0?1:gt(n-1)*n;
}
int main()
{
	cout<<gt(7);

}


