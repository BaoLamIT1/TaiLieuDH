//sinh day nhi phan
/*n=3
000
001
010
011

...
111
*/
#include<bits/stdc++.h>
using namespace std;
void sinh(string x,int n)
{
	if (x.size()==n) cout<<x<<"\n";
	else
	{
		sinh(x+"0",n);
		sinh(x+"1",n);
	}
}
int main()
{
	sinh("",3);
}


