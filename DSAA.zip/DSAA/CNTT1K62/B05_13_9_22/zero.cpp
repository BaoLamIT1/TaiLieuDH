#include<bits/stdc++.h>
using namespace std;
int zero(int s,int f)
{
	if(s==f) return 1;
	if(s<f) return 0;
	int res=0;
	for(int a=1;a*a<=s;a++)
	if(s%a==0) res+=zero((a-1)*(s/a+1),f);
	return res;
}
int main()
{
	cout<<zero(100,19);
}


