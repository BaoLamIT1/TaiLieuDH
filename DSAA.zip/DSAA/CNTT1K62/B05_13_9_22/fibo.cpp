#include<bits/stdc++.h>
using namespace std;

long long fibo(int n)
{
	return n<2?1:fibo(n-1)+fibo(n-2);
}

int main()
{
	cout<<fibo(46);

}


