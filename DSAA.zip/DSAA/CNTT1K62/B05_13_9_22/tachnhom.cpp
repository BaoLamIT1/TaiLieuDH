//
#include<bits/stdc++.h>
using namespace std;
int tach(int n)
{
	if (n<=4 || n%2) return 1;
	return tach(n/2+2)+tach(n/2-2);
}
int in(int n,string p="\n")
{
	if(n>4 && n%2==0) in(n/2+2,p+"\t");
	cout<<p<<n;
	if(n>4 && n%2==0) in(n/2-2,p+"\t");
}
int main()
{
	cout<<"so nhom "<<tach(60)<<" tach nhu sau\n";
	in(60);
}


