//Luy thua
#include<bits/stdc++.h>
using namespace std;

double POW(double x,int n)
{
	if(n==0) return 1;
	return POW(x,n-1)*x;
}
double mypow(double x,int n)
{
	if(n==0) return 1;
	double t=mypow(x,n/2);
	return n%2?t*t*x:t*t;
}
double lt(double x,int n)
{
	if(n==0) return 1;
	if(n%2==0) return lt(x*x,n/2);
	return x*lt(x*x,n/2);
}
int main()
{
	cout<<POW(3,10);
	cout<<"\n"<<mypow(3,10);
	cout<<"\n"<<lt(3,10);
}


