#include<bits/stdc++.h>
using namespace std;
int menu()
{
	cout<<"1. kem\n";
	cout<<"2. tra sua\n";
	cout<<"3. tra da\n";
	cout<<"4. nhan tran\n";
	cout<<"\nMoi ban chon mon : "; 
	int n;
	cin>>n;
	if(1<=n && n<=4) {cout<<"ban chon dung"; return n;}
	return menu();
}
int main()
{
	int k=menu();
	cout<<"Mon thu "<<k;
}


