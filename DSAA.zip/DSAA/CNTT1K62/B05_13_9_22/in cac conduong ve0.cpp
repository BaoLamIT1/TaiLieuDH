#include<bits/stdc++.h>
using namespace std;
void TRY(int *x,int k,int f)
{
	if(x[k]==f) 
	{
		for(int i=1;i<k;i++) cout<<x[i]<<"->";
		cout<<x[k]<<"\n";
	}
	for(int a=1;a*a<=x[k];a++)
	if(x[k]%a==0) 
	{
		x[k+1]=(a-1)*(x[k]/a+1);
		if(x[k+1]>=f) TRY(x,k+1,f);
	}
}
int main()
{
	int x[100],f;
	cin>>x[1]>>f;
	TRY(x,1,f);
}


