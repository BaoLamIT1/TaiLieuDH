//Trinh tham
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n,k;
	cin>>n>>k;
	int a[n]; for(int &x:a)cin>>x;
	for(int i=0,j=k;j<=n;i++,j++)
	cout<<*max_element(a+i,a+j)<<" ";
}


