//xoa k chu so
#include<bits/stdc++.h>
using namespace std;
void xoa(string x,int k)
{
	list<char> L;
	for(auto c:x)
	{
		while(L.size() && k>0 && L.back()<c) {L.pop_back();k--;}
		L.push_back(c);
	}
	while(k>0) {L.pop_back();k--;}
	for(auto z:L) cout<<z;
	cout<<"\n";
}
int main()
{
	string x;
	int test,k;
	cin>>x>>test;
	while(test--)
	{
		cin>>k;
		xoa(x,k);
	}
}


