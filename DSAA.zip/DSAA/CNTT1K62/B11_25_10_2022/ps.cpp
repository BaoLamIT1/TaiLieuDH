#include<bits/stdc++.h>
using namespace std;
struct ps
{
	int t,m;
	ps(int a=0,int b=1) {t=a;m=b;}
	ps(ps &p)
	{
		cout<<"toan tu copy";
		t=p.t;
		m=p.m;
	}
	ps &operator=(ps &p)
	{
		cout<<"toan tu assignment";
		this->t=p.t;
		this->m=p.m;
		return *this;
	}
};
int main()
{
	ps A(3,4);
	ps B=A;  //Su dung toan tu copy
	ps C; 
	C=A;     //toan tu =


}


