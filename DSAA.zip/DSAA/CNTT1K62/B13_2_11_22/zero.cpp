#include<bits/stdc++.h>
using namespace std;

struct node
{
	int elem;
	vector<node*> child;
	node(int n) //de quy
	{
		elem=n;
		for(int a=1;a*a<=n;a++)
		if(n%a==0) child.push_back(new node((a-1)*(n/a+1)));
	}
};
void preorder(node *H)
{
	if(!H) return;  //H==NULL
	cout<<H->elem<<" ";
	for(auto h:H->child) preorder(h);
}
void postorder(node *H)
{
	if(!H) return;  //H==NULL
	for(auto h:H->child) postorder(h);
	cout<<H->elem<<" ";
}
void inorder(node *H)
{
	if(!H) return;  //H==NULL
	if(H->child.size())inorder(H->child[0]);
	cout<<H->elem<<" ";
	for(int i=1;i<H->child.size();i++) inorder(H->child[i]);
}
void INORDER(node *H,string p="\n")
{
	//if(!H) return;  
	if(H->child.size())INORDER(H->child[0],p+"\t");
	cout<<p<<H->elem;
	for(int i=1;i<H->child.size();i++) INORDER(H->child[i],p+"\t");
}
int main()
{
	node*root=new node(24);
	//cout<<root->elem<<"\n";
	//cout<<root->child[2]->child[2]->child[1]->elem;
	cout<<"\npreorder : ";preorder(root);
	cout<<"\nin order : ";inorder(root);
	cout<<"\npostorder: ";postorder(root);
	cout<<"\n\nCay\n\n"; INORDER(root);
}


