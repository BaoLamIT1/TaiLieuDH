#include<bits/stdc++.h>
using namespace std;
#ifndef _my_double_list_
#define _my_double_list_
template <class T>
struct node
{
	T elem;
	node *prev,*next;
	node(T e,node<T> *P=0,node<T> *N=0)
	{
		elem=e;
		prev=P;
		next=N;
	}
};
template <class T>
class dlist_ite  //Bo lap xuoi
{
	node<T> *curr;
	public:
		node<T>*&getcur(){return curr;} 
		dlist_ite(node<T>*c=NULL) {curr=c;}  //ham tao
		dlist_ite<T>& operator=(dlist_ite<T> const &it)  //toan tu gan
		{
			this->curr=it.curr;
			return *this;
		}
		bool operator!=(dlist_ite<T> it)  //so sanh ko bang
		{
			return curr!=it.curr;
		}
		T &operator*(){return curr->elem;}  //toan tu lay gia tri *it
		dlist_ite<T> operator++()  //++it
		{
			curr=curr->next;
			return curr;
		}
		dlist_ite<T> operator++(int)  //it++
		{
			node<T>*p=curr;
			curr=curr->next;
			return p;
		}
};
template <class T>
class dlist_rite  //Bo lap nguoc
{
	node<T> *curr;
	public:
		node<T>*&getcur(){return curr;} 
		dlist_rite(node<T>*c=NULL) {curr=c;}  //ham tao
		dlist_rite<T>& operator=(dlist_rite<T> const &it)  //toan tu gan
		{
			this->curr=it.curr;
			return *this;
		}
		bool operator!=(dlist_rite<T> it)  //so sanh ko bang
		{
			return curr!=it.curr;
		}
		T &operator*(){return curr->elem;}  //toan tu lay gia tri *it
		dlist_rite<T> operator++()  //++it
		{
			curr=curr->prev;
			return curr;
		}
		dlist_rite<T> operator++(int)  //it++
		{
			node<T>*p=curr;
			curr=curr->prev;
			return p;
		}
};
template <class T>
class dlist
{
	node<T>*Head,*Trail;
	int n;
	public:
		dlist() {Head=Trail=0; n=0;}
		dlist(int k,T x)
		{
			Head=Trail=0;
			n=0;
			while(k--) push_back(x);
		}
		~dlist()
		{
			while(Head)
			{
				node<T>*p=Head;
				Head=Head->next;
				delete p;
			}
		}
		int size() {return n;}
		bool empty(){return n==0;}
		T &front() {return Head->elem;}
		T &back() {return Trail->elem;}
		T &operator[](int k)             //list trong STL khong co ham nay
		{
			node<T> *p=Head;
			while(k--) p=p->next;
			return p->elem;
		}
		void push_back(T x)
		{
			if(n==0) Head=Trail=new node<T>(x);
			else Trail=Trail->next=new node<T>(x,Trail,0);
			n++;
		}
		void push_front(T x)
		{
			if(n==0) Head=Trail=new node<T>(x);
			else Head=Head->prev=new node<T>(x,0,Head);
			n++;
		}
		void pop_back()
		{
			if(n==1) {delete Head; Head=Trail=0; n=0; return;}
			Trail=Trail->prev;
			delete Trail->next;
			Trail->next=0;
			n--;			
		}
		void pop_front()
		{
			if(n==1) {delete Head; Head=Trail=0; n=0; return;}
			Head=Head->next;
			delete Head->prev;
			Head->prev=0;
			n--;			
		}
		void sort(bool ok=true) //mac dinh sap xep tang dan
		{
			if(n<=1) return;
			for(node<T>*p=Head;p!=NULL;p=p->next)
			for(node<T>*q=p->next;q!=NULL;q=q->next)
			if(q->elem<p->elem==ok) swap(p->elem,q->elem);  
		}
		
		typedef dlist_ite<T> iterator;
		iterator begin() {return Head;}
		iterator end() {return NULL;}
		
		typedef dlist_rite<T> reverse_iterator;
		reverse_iterator rbegin() {return Trail;}
		reverse_iterator rend() {return NULL;}
		void insert(iterator it,T x)
		{
			node<T> *p=it.getcur();
			if(p==Head) return push_front(x);
			node<T> *q=p->prev;
			q->next=p->prev=new node<T>(x,q,p);
			n++;
		}
		void erase(iterator it)
		{
			node<T> *p=it.getcur();
			if(p==Head) return pop_front();
			if(p==Trail) return pop_back();
			node<T> *q=p->prev,*r=p->next;
			q->next=r; r->prev=q;
			delete p;
			n--;
		}
};
#endif
//int main()
//{
//	dlist<int> L(5,6);
//	for(int x:{7,8,9}) L.push_back(x);
//	for(int x:{1,2,3}) L.push_front(x);
//	cout<<"\nL: ";for(int i=0;i<L.size();i++) cout<<L[i]<<" ";
//	L.sort(false);
//	L.pop_back();
//	L.pop_front();
//	cout<<"\nL: ";for(int i=0;i<L.size();i++) cout<<L[i]<<" ";
//	cout<<"\nDuyet xuoi : "; for(auto z:L) cout<<z<<" ";
//	cout<<"\nDuyet nguoc: "; 
//	for(dlist<int>::reverse_iterator it=L.rbegin();it!=L.rend();it++) cout<<*it<<" ";
//	auto it=L.begin(); for(int s=1;s<=4;s++) it++;
//	L.insert(it,10);
//	cout<<"\nL: "; for(auto z:L) cout<<z<<" ";
//	L.erase(L.begin());
//	it=L.begin(); for(int s=1;s<=6;s++) it++;
//	*it=-2;
//	cout<<"\nL: "; for(auto z:L) cout<<z<<" ";
//	L.erase(it);
//	cout<<"\nL: "; for(auto z:L) cout<<z<<" ";
//	
//}


