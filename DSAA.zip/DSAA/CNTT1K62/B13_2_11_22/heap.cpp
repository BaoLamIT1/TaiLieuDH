//cay heap
#include<bits/stdc++.h>
using namespace std;

template <class T>
struct node 
{
	T elem;
	int n;    //n size no bang 1+ size(left)+size(right)
	node*left,*right;
	node(T x,node<T>*L=0,node<T>*R=0,int _n=1)
	{
		n=_n;
		elem=x;
		left=L;
		right=R;
	}
};
template<class T,class CMP>
void update(node<T> *&H,T x,CMP ss)
{
	if(!H) H=new node<T>(x);
	else if(ss(H->elem,x))H=new node<T>(x,H,0,H->n+1);
	else
	{
		H->n++;
		if(!H->left) H->left=new node<T>(x);
		else if(!H->right) H->right=new node<T>(x);
		else update(H->left->n<H->right->n?H->left:H->right,x,ss);
	}
}
template<class T,class CMP>
void remove(node<T> *&H,CMP ss)
{
	if(!H) return;
	if(!H->left) H=H->right;
	else if(!H->right) H=H->left;
	else
	{
		H->n--;
		if(ss(H->left->elem,H->right->elem)) {H->elem=H->right->elem;remove(H->right,ss);}
		else {H->elem=H->left->elem;remove(H->left,ss);}
	}
}
template <class T,class CMP=less<T> >
class Priority_Queue  //hang doi uu tien
{
	node<T> *root=0;
	CMP ss;
	public:
		Priority_Queue() {root=0;}
		int size(){if(!root) return 0; return root->n;}
		bool empty(){return root==NULL;}
		void push(T x) {update(root,x,ss);}
		void pop() {remove(root,ss);}
		T top() {return root->elem;}
};
int main()
{
	Priority_Queue<string,greater<string> > Q;
	for(auto x:{"chi pheo","lao hac","thi no","thang muc","ba kien","thang xien","cau vang"}) Q.push(x);
	while(Q.size())
	{
		cout<<Q.top()<<"\n";
		Q.pop();
	}
}


