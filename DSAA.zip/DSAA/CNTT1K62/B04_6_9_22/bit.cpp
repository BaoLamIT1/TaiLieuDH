#include<bits/stdc++.h>
using namespace std;
int main()
{
	long long a=12,b=a<<3,c=123>>2;  //b=a*2^3; c=123/4
	cout<<"b = "<<b;
	cout<<"\nc = "<<c<<"\n";
	for(int i=0;i<11;i++)
	{
		cout<<"2^"<<i<<" = "<<(1<<i)<<"\n";
	}
}


