#include<bits/stdc++.h>
using namespace std;
void sx(int *a,int n,bool cmp(int,int))
{
	for(int i=0;i<n;i++)
	for(int j=i+1;j<n;j++) 
	if(cmp(a[j],a[i])) {a[i]^=a[j];a[j]^=a[i];a[i]^=a[j];}
}
bool ss(int a,int b)
{
	if(a%2==b%2) return a<b;
	return a%2<b%2;
}
int main()
{
	int n=100;
	int a[n];
	for(auto &x:a) x=rand();  //tao mang ngau nhien trong [0,32767] co n phan tu
	sx(a,n,ss);
	cout<<"sau khi sap : ";
	for(int x:a) cout<<x<<" ";
}


