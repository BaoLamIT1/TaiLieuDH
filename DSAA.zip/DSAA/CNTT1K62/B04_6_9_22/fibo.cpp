#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n;									 //1  khai bao		
	cin>>n;									 //1  	 
	long long a[n+5]={1,1};					 //1+1+2+2 //khai bao, + , 2 phep gan
	int i=2;								 //1+1     //khai bao va gan
	for(;i<=n;) {a[i]=a[i-1]+a[i-2];i++;}    //(n-1)*9 {<=,[],=,[],-,+,[]-,++}
	//										 //1 ra khoi vong			
	cout<<a[n];								 //2		
}
//Khong gian K(n)=sizoef(n)+sizoef(a)+sizoef(i) = 4 +8*(n+5) +4 = 8n+45 =O(n)
//Thoi gian T(n) = 10+9(n-1) +3 = 9n+4=O(n)


