#include<bits/stdc++.h>
using namespace std;
struct node
{
	int elem;
	node*child[26]={};
	node(){elem=1;}
};
void update(node *&H,char *p)
{
	if(!H) H=new node();
	else H->elem++;
	if(*p) update(H->child[*p-'a'],p+1);
}
int get(node*H,char *p)
{
	if(!H) return 0;
	if(*p==0) return H->elem;
	return get(H->child[*p-'a'],p+1);
}
int main()
{
//	freopen("db.txt","r",stdin);
	node *root=nullptr; //new node();
	int n;
	char q[10],x[1000];
	scanf("%d",&n);
	while(n--)
	{
		scanf("\n%s %s",q,x);
		if(q[0]=='a') update(root,x);
		else printf("%d\n",get(root,x));
	}
}


