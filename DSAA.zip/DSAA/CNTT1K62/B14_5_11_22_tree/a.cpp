#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("a5.in","w",stdout);
	char x[10005]="aschoolisaneducationalinstitutiondesignedtoprovidelearningspacesandlearningenvironmentsfortheteachingofstudentsunderthedirectionofteachersmostcountrieshavesystemsofformaleducationwhichissometimescompulsoryinthesesystemsstudentsprogressthroughaseriesofschoolsthenamesfortheseschoolsvarybycountrydiscussedintheregionaltermssectionbelowbutgenerallyincludeprimaryschoolforyoungchildrenandsecondaryschoolforteenagerswhohavecompletedprimaryeducationaninstitutionwherehighereducationistaughtiscommonlycalledauniversitycollegeoruniversityinadditiontothesecoreschoolsstudentsinagivencountrymayalsoattendschoolsbeforeandafterprimaryelementaryintheusandsecondarymiddleschoolintheuseducationkindergartenorpreschoolprovidesomeschoolingtoveryyoungchildrentypicallyagesuniversityvocationalschoolcollegeorseminarymaybeavailableaftersecondaryschoolaschoolmaybededicatedtooneparticularfieldsuchasaschoolofeconomicsordancealternativeschoolsmayprovidenontraditionalcurriculumandmethodsnongovernmentschoolsalsoknownasprivateschoolsmayberequiredwhenthegovernmentdoesnotsupplyadequateorspecificeducationalneedsotherprivateschoolscanalsobereligioussuchaschristianschoolsgurukulahinduschoolsmadrasaarabicschoolshawzasshiimuslimschoolsyeshivasjewishschoolsandothersorschoolsthathaveahigherstandardofeducationorseektofosterotherpersonalachievementsschoolsforadultsincludeinstitutionsofcorporatetrainingmilitaryeducationandtrainingandbusinessschoolscriticsofschooloftenaccusetheschoolsystemoffailingtoadequatelypreparestudentsfortheirfuturelivesofencouragingcertaintemperamentswhileinhibitingothersofprescribingstudentsexactlywhattodohowwhenwhereandwithwhomwhichwouldsuppresscreativityandofusingextrinsicmeasuressuchasgradesandhomeworkwhichwouldinhibitchildren";
	int n=strlen(x);
	//printf("%d",n);
	map<string,bool> M,Z;
	for(int i=0;i<=n;i+=3)
	{
		string y="";
		y+=x[i];
		y+=x[i+1];
		y+=x[i+2];
		M[y]=true;
	}
	n=167;
	cout<<n<<"\n";
	Z["asc"]=true;
	for(int i=1;i<n;i++)
	{
		int x=rand()%Z.size();
		string u;
		map<string,bool>::iterator it=Z.begin();
		for(int j=0;j<x;j++) it++;
		u=it->first;
		for(auto v:M)
		if(Z.find(v.first)==Z.end())
		{
			Z[v.first]==true;
			cout<<u<<" "<<v.first<<"\n";
			break;
		}
	}
}


