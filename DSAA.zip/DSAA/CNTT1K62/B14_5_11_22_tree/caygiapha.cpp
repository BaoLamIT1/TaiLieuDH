//Cay gia pha
#include<bits/stdc++.h>
using namespace std;
struct node
{
	string elem;
	vector<node*> child;
	node(string t){elem=t;}
};
node*find(node*H,string a)
{
	if(H->elem==a) return H;
	for(auto h:H->child)
	{
		node*p=find(h,a);
		if(p) return p;
	}
	return NULL;
}
void update(node*H,string a,string b)
{
	node*p=find(H,a);
	p->child.push_back(new node(b));
}
int maxchild(node *H)
{
	int res=H->child.size();
	for(auto h:H->child) 
	{
		int k=maxchild(h);
		if (res<k) res=k;
	}
	return res;
}
int high(node *H)
{
	if(H->child.size()==0) return 1;
	int res=0;
	for(auto h:H->child) 
	{
		int k=high(h);
		if (res<k) res=k;
	}
	return res+1;
}
//void inorder(node *H)
//{
//	if(H->child.size()) inorder(H->child[0]);
//	cout<<H->elem<<" ";
//	for(int i=1;i<H->child.size();i++) inorder(H->child[i]);
//}
void inorder(node *H,list<string> &L)
{
	if(H->child.size()) inorder(H->child[0],L);
	//cout<<H->elem<<" "; 
	L.push_back(H->elem);
	for(int i=1;i<H->child.size();i++) inorder(H->child[i],L);
}
class Giapha
{
	node *root;  //quan ly goc cay
	int n;		 //quan ly nguoi trong gia pha
	list<string> L;
	public:
		Giapha(){n=0;root=NULL;}
		void nhap()
		{
			cin>>n;
			for(int i=1;i<n;i++)
			{
				string x,y;
				cin.ignore(1);
				cin>>x>>y;
				if(i==1) root=new node(x);
				update(root,x,y);
			}
		}
		typedef typename list<string>::iterator iterator;
		iterator begin()
		{
			L.clear();
			inorder(root,L);
			return L.begin();	
		}
		iterator end() {return L.end();}
};

int main()
{
//	inorder(root);
//	cout<<"\n"<<maxchild(root)<<"\n"<<high(root);
	Giapha G;
	G.nhap();
//	for(Giapha::iterator it=G.begin(); it!=G.end();it++) cout<<(*it)->elem<<" ";	
	for(auto g:G) cout<<g<<" ";	
}


