#include<bits/stdc++.h>
using namespace std;
int main()
{
	vector<int> A;
	for(int i:{2,41,51,24,36})A.push_back(i);
	cout<<"\nA : ";
	//for(auto x:A) cout<<x<<" ";
	for(vector<int>::iterator it=A.begin();it!=A.end();it++) cout<<*it<<" ";

}


