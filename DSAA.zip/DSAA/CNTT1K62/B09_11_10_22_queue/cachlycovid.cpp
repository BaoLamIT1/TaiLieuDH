//Thuat toan BFS cho bai toan cach ly covid
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n,m,q,x,u,v;
	cin>>n>>m;
	vector<int> A[n+5];  //Mang cac vector
	while(m--)
	{
		cin>>u>>v;
		A[u].push_back(v);	A[v].push_back(u);
	}
	int d[n+5]; fill(d,d+n+1,-1);  //d[x]=k thi x la F[k]
	int F[n+5]={};                 //so F[i] ban dau toan 0
	queue<int> Q;
	cin>>F[0];
	for(int i=1;i<=F[0];i++){cin>>x; 	Q.push(x); d[x]=0;}
	while(Q.size())
	{
		int u=Q.front(); Q.pop();
		for(int v:A[u])
		if(d[v]==-1)
		{
			d[v]=d[u]+1;
			Q.push(v);
			F[d[v]]++;
		}
	}
	for(int i=0;F[i]!=0;i++) cout<<"F"<<i<<": "<<F[i]<<"\n";
}


