//Cai dat queue bang mang

#include<bits/stdc++.h>
using namespace std;
template <class T> 
class QUEUE
{
	int n,F,L,cap;
	T *buf;
	public:
		QUEUE() {buf=NULL;n=0;F=L=0;}
		~QUEUE(){if(buf) delete [] buf;}
		int size(){return n;}
		bool empty(){return n==0;}
		T&front() {return buf[F];}
		T&back() {return L==0?buf[cap-1]:buf[L-1];}
		void pop() {n--; if(n==0) F=L=0; else F=(F+1)%cap;}
		void push(T x)
		{
			if(n==cap) //day phai mo rong bo nho
			{
				cap=cap?cap*2:1;
				T*tem=new T[cap];
				for(int i=F,j=0;i<F+n;i++,j++) tem[j]=buf[i%cap];
				if(buf) delete[]buf;
				buf=tem;
				F=0;
				L=n;
			}
			buf[L]=x; L=(L+1)%cap;
			n++;
		}
};
int main()
{
	QUEUE<int> Q;
	for(int x:{53,526,21,1364,236}) Q.push(x);
	Q.front()=100;
	Q.back()=20;
	while(Q.size())
	{
		cout<<Q.front()<<" ";
		Q.pop();
	}
}



