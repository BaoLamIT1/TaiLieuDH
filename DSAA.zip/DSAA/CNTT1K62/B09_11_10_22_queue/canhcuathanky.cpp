#include<bits/stdc++.h>
using namespace std;
int main()
{
	queue<pair<string,int>> Q;
	for(string x:{"Anh","Bac","Chu","Duong","Em"})Q.push({x,1});
	int n;
	cin>>n;
	while(n>Q.front().second)
	{
		n-=Q.front().second;
		Q.push(Q.front());
		Q.back().second*=2;
		Q.pop();
	}
	cout<<Q.front().first;
}


