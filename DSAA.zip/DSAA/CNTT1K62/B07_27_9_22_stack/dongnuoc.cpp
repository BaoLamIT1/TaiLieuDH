#include<bits/stdc++.h>
using namespace std;
typedef pair<int,int> TT;
class water
{
	int n,m,k;
	int BFS()  //tra ve do sau cua nut tim thay
	{
		queue<TT> S;
		map<TT,int> D;
		S.push({0,0});    //{0,0} make_pair(0,0) TT(0,0)
		D[{0,0}]=0;
		while (S.size())
		{
			int x=S.front().first,y=S.front().second,z=x+y; 
			S.pop();
			TT Next[6]={{0,y},{x,0},{n,y},{x,m},{max(0,z-m),min(z,m)},{min(z,n),max(0,z-n)}};
			for(auto v:Next)
			if(D.find(v)==D.end())
			{
				S.push(v);
				D[v]=D[{x,y}]+1;
				if(v.first ==k ||v.second==k) return D[v];
			}
		}
		return -1;
	}

	int DFS()  //tra ve do sau cua nut tim thay
	{
		stack<TT> S;
		map<TT,int> D;
		S.push({0,0});    //{0,0} make_pair(0,0) TT(0,0)
		D[{0,0}]=0;
		while (S.size())
		{
			int x=S.top().first,y=S.top().second,z=x+y; 
			S.pop();
			TT Next[6]={{0,y},{x,0},{n,y},{x,m},{max(0,z-m),min(z,m)},{min(z,n),max(0,z-n)}};
			for(auto v:Next)
			if(D.find(v)==D.end())
			{
				S.push(v);
				D[v]=D[{x,y}]+1;
				if(v.first ==k ||v.second==k) return D[v];
			}
		}
		return -1;
	}
	public: void sol()
	{
		cin>>n>>m>>k;
		int res=BFS();
		if(res==-1) cout<<"\nkhong dong duoc nuoc";
		else cout<<res;
	}
}; 
int main(){	water W; W.sol();}


