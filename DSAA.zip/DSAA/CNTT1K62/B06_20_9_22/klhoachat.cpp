//Khoi luong hoa chat
#include<bits/stdc++.h>
using namespace std;
int main()
{
	map<char,int> K={{'C',12},{'H',1},{'O',16},{'(',0}};
	string x;
	getline(cin,x);
	stack<int> S;
	for(auto c:x)
	if (K.find(c)!=K.end()) S.push(K[c]);
	else if ('0'<=c && c<=='9') S.top()*=c-'0';
	else //')'
	{
		int t=0; while(S.top()) {t+=S.top(); S.pop();}
		S.top()=t;
	}
	int t=0; while(S.size()) {t+=S.top(); S.pop();}
	cout<<t;
}


