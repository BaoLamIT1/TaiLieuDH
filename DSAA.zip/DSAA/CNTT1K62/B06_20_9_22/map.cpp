#include<bits/stdc++.h>
using namespace std;
int main()
{
	map<string,int> M;
	M["ha noi"]=29;
	M["ha nam"]=90;
	M["thai binh"]=17;
//	cout<<M["ha nam"];
	string x;
	getline(cin,x);
	if (M.find(x)==M.end()) cout<<"not found";
	else cout<<M[x];
}


