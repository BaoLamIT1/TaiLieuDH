#include<bits/stdc++.h>
#include"Stack.cpp"
using namespace std;
int main()
{
	bool ok=1;
	unordered_map<char,char> M={{'(',')'},{'[',']'},{'{','}'}};
	map<char,int> ut={{'(',1},{'[',2},{'{',3}};
	string x;
	getline(cin,x);
	Stack<char> S;
	for(char c:x)
	if(c=='(' || c=='[' || c=='{') 
	{
		if(S.size() && ut[c]>ut[S.top()]) {ok=0;break;}
		S.push(M[c]);
	}
	else if(c==')'||c==']'||c=='}')
	{
		if(S.empty() or S.top()!=c) {ok=0;break;}
		else S.pop();	
	}
	cout<<(S.empty() and ok?"hop le":"khong hop le");
}


