//Doi sang co so 2
#include<bits/stdc++.h>
using namespace std;
char Hex[]="0123456789ABCDEFGHIJKLMNOPQRSTUVXYZ";
int main()
{
	long long n,b=16;
	stack<char> S;
	cin>>n;
	while(n)
	{
		S.push(Hex[n%b]);
		n/=b;
	}
	while(S.size()) {cout<<S.top(); S.pop();}
}


