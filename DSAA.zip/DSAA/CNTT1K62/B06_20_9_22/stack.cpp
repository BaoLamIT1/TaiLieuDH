//cai dat stack bang mang
#include<bits/stdc++.h>
using namespace std;
#ifndef __stack__cpp__
#define __stack__cpp__
template <class T>
class Stack
{
	int n,cap;  //n-size, cap-capacity
	T *buf;     //buffer chua cac phan tu stack
	public:
		Stack() {n=cap=0;buf=NULL;} 
		~Stack(){if(buf) delete []buf;}
		bool empty() {return n==0;}
		int size() {return n;}
		void pop() {n--;}
		T &top() {return buf[n-1];}  //readwrite function
		void push(T x)
		{
			if(n==cap) //full
			{
				cap=1+cap*2;   //cap==0?1:cap*2;
				T *tem=new T[cap];
				for(int i=0;i<n;i++) tem[i]=buf[i];
				if(buf) delete []buf;
				buf=tem;
			}
			buf[n++]=x;
		}
};
#endif
//int main()
//{
//	Stack<int> S;
//	for(int x:{43,23,52,22}) S.push(x);
//	while(S.size())
//	{
//		cout<<S.top()<<" ";
//		S.pop();
//	}
//}
