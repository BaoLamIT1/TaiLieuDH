#include<bits/stdc++.h>
#include"stack.cpp"
#include<stack>
using namespace std;
int main()
{
	Stack<int> S;
	for(int x:{4,7,2,8,1,6}) S.push(x);
	S.top()=9;
	while (S.size())
	{
		cout<<S.top()<<" ";
		S.pop();
	}
}


