#include<bits/stdc++.h>
using namespace std;
vector<int> cong(vector<int> a,vector<int> b)
{
	vector<int> c=a;
	if(a.size()<b.size()) c.resize(b.size(),0);
	for(int i=0;i<b.size();i++) c[i]+=b[i];
	int nho=0;
	for(auto &x:c)
	{
		nho+=x;
		x=nho%10;
		nho/=10;
	}
	if(nho) c.push_back(nho);
	return c;
}
int main()
{
	int n;
	cin>>n;
	if (n==0||n==1) {cout<<n; return 0;}
	vector<int>a(1,0),b(1,1),c;
	for(int i=2;i<=n;i++)
	{
		c=cong(a,b);  //a, b truyen vao thong qua toan tu copy, c= dung toan tu gan
		a=b;
		b=c;
	}
	for(auto it=b.rbegin();it!=b.rend();it++) cout<<*it;

//	string a,b;
//	cin>>a>>b;
//	vector<int> A,B,C;
//	for(auto c=a.rbegin();c!=a.rend();c++) A.push_back(*c-'0');
//	for(auto c=b.rbegin();c!=b.rend();c++) B.push_back(*c-'0');
//	C=cong(A,B);
//	reverse(C.begin(),C.end());
//	for(auto c:C) cout<<c;
}


