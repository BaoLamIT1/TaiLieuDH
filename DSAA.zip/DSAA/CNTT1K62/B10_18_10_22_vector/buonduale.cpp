#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n,k,m,x;
	long long res=0;
	cin>>n>>k>>m;
	queue<pair<int,int>> Q;
	for(int i=1;i<n+k;i++)
	{
		if(i<=n) cin>>x; else x=0;
		Q.push({i,x});
		while(Q.size() && i-Q.front().first>=k) Q.pop();
		//
		int t=0;
		while(Q.size() && t+Q.front().second<=m) {t+=Q.front().second; Q.pop();}
		if(Q.size()) {Q.front().second-=m-t; t=m;}
		res+=t;
	}
	cout<<res;
}


