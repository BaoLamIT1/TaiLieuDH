#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int a[n],L[n+5],R[n+5];
	for(int &x:a) cin>>x;
	stack<pair<int,int>> SL,SR;
	SL.push({-1,INT_MAX});
	for(int i=0;i<n;i++)
	{
		while(SL.top().second<=a[i]) SL.pop();
		L[i]=SL.top().first;
		SL.push({i,a[i]});
	}
	SR.push({-1,INT_MAX});
	for(int i=n-1;i>=0;i--)
	{
		while(SR.top().second<=a[i]) SR.pop();
		R[i]=SR.top().first;
		SR.push({i,a[i]});
	}
	for(int i=0;i<n;i++)
	if(L[i]==-1 || R[i]==-1) cout<<L[i]+R[i]+1<<" ";
	else cout<<(i-L[i]<=R[i]-i?L[i]:R[i])<<" "; 
}


