//nhom ban
#include<bits/stdc++.h>
using namespace std;
class Group
{
	int n,m,k=0,d[10005]={},res=0;
	vector<int> A[10005];
	public: void sol()
	{
		cin>>n>>m;
		for(int i=1;i<=m;i++)
		{
			int u,v;
			cin>>u>>v;	A[u].push_back(v);	A[v].push_back(u);
		}
		for(int i=1;i<=n;i++)
		if(d[i]==0)
		{
			k++;
			int z=BFS(i);	if(res<z) res=z;
		}
		cout<<k<<"\n"<<res;
	}
	int BFS(int s)  //Tim nhom choi voi s tra ve so nguoi
	{
		queue<int> S;
		int dem=1;
		S.push(s);
		d[s]=k;
		while(S.size())
		{
			int u=S.front(); S.pop();
			for(int v:A[u])
			if(d[v]==0)
			{
				d[v]=k;
				dem++;
				S.push(v);
			}
		}
		return dem;
	}
};
int main(){	Group G;	G.sol();}


