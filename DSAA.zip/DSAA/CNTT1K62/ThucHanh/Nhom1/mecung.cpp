//mecung
#include<bits/stdc++.h>
using namespace std;
class Mecung
{
	int n,m,A[105][105];
	public:void sol()
	{
		int sx,sy,fx,fy;
		cin>>n>>m;
		for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++) cin>>A[i][j];
		//Quay tuong bao 4 xung quanh toan 1
		for(int i=0;i<=n+1;i++) A[i][0]=A[i][m+1]=1;
		for(int j=0;j<=m+1;j++) A[0][j]=A[n+1][j]=1;
		cin>>sx>>sy>>fx>>fy;
		cout<<BFS(sx,sy,fx,fy);
	}
	int BFS(int sx,int sy,int fx,int fy) //so buoc ngan nhat
	{
		queue<pair<int,int>> Q;
		A[fx][fy]=0;
		A[sx][sy]=1; 
		Q.push({sx,sy});
		while(Q.size())
		{
			int z=Q.front().first,t=Q.front().second; Q.pop();
			pair<int,int> Next[]={{z+1,t},{z-1,t},{z,t-1},{z,t+1}};
			for(auto v:Next)
			if(A[v.first][v.second]==0)
			{
				A[v.first][v.second]=A[z][t]+1;
				Q.push(v);
			}	
			if(A[fx][fy]!=0) return A[fx][fy]-1;
		} 
		return -1;
	}
};
int main(){Mecung M; M.sol();}


