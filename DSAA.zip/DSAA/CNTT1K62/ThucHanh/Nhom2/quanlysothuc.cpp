#include<bits/stdc++.h>
#include"docfile.cpp"
using namespace std;
class quanly
{
	vector<sv> A;

	public:
		int menu()
		{
			system("cls");
			cout<<"0. Nhap danh sach sv tu file\n";
			cout<<"1. Them sinh vien vao cuoi\n";
			cout<<"2. sap xep\n";
			cout<<"3. Thay the tai vi tri k\n";
			cout<<"4. Dao day nguoc lai\n";
			cout<<"5. Xoa tai 1 vi tri\n";
			cout<<"6. Liet ke cac phan tu:\n";
			cout<<"7. Tim sinh vien co diem lon nhat\n";
			cout<<"8. Liet ke nhung vi tri co max\n";
			cout<<"9. Thoat";
			cout<<"\nMoi ban chon : "; 
			int chon;
			cin>>chon;
			if(0<=chon and chon<=9) return chon;
			return menu();
		}
		void run()
		{
			string fname;
			ifstream fin;
			int n;
			sv x;
			while(1)
			{
				switch(menu())
				{
					case 0: 
						cout<<"\nNhap ten file : "; 
						cin.ignore(1);
						getline(cin,fname);
						fin.open(fname,ifstream::in);  
						fin>>n;
						fin.ignore(1);
						while(n--){fin>>x; A.push_back(x);}
						fin.close();
						break;
					case 6:
						cout<<"\nNoi dung danh sach : \n";
						for(auto x:A) cout<<x<<"\n";
						break;
					default: return ;
				}
				system("pause");	
			}
		}
};
int main()
{
	quanly Q;
	Q.run();
}


