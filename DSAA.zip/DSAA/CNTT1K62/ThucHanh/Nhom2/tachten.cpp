#include<bits/stdc++.h>
using namespace std;
int main()
{
	char y[]="cong ty tu nhan 1421 15 9.2";
	char x[30];
	int ma,tuoi;
	double diem;
	sscanf(y,"%[^0-9] %d%d%lf",x,&ma,&tuoi,&diem);
	printf("\nten la :%s",x);
	printf("\nma :%d",ma);
	printf("\ntuoi :%d",tuoi);
	printf("\ndiem :%lf",diem);

}


