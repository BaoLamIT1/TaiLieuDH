#include<bits/stdc++.h>
using namespace std;
struct sv
{
	string ten;
	int tuoi,ma;
	double diem;
};
istream &operator>>(istream &is,sv &S)
{
	string s,x;
	getline(is,s);
	vector<string> z;
	istringstream ssin(s);
	while(ssin>>x) z.push_back(x);
	x=z.back(); z.pop_back();
	istringstream ssin1(x);
	ssin1>>S.diem;
	x=z.back(); z.pop_back();
	istringstream ssin2(x);
	ssin2>>S.tuoi;
	x=z.back(); z.pop_back();
	istringstream ssin3(x);
	ssin3>>S.ma;
	S.ten="";
	for(auto x:z) S.ten+=x+" ";
	if(S.ten.back()==' ')S.ten.pop_back();
	return is;
}
ostream &operator<<(ostream &os,sv S)
{
	os<<setw(20)<<left<<S.ten<<" "<<setw(5)<<S.ma<<" "<<setw(5)<<S.tuoi<<" "<<S.diem;
	return os;
}
//int main()
//{
//	vector<sv> A;
//	ifstream fin("sv.txt");
//	int n;
//	sv s;
//	fin>>n;
//	fin.ignore(1);
//	while(n--){fin>>s; A.push_back(s);}
//	fin.close();
//	for(auto a:A) cout<<a<<"\n";
//}
//int main()
//{
//	FILE *f=fopen("sv.txt","r");
//	int n;
//	vector<sv> C;
//	fscanf(f,"%d\n",&n);
//	for(int i=0;i<n;i++)
//	{
//		char ten[30];
//		int tuoi,ma;
//		double diem;
//		fscanf(f,"%[^0-9]",ten);
//		fscanf(f,"%d%d%lf\n",&ma,&tuoi,&diem);
//		sv s;
//		s.ten=ten; s.ten.pop_back();
//		s.tuoi=tuoi;
//		s.diem=diem;
//		C.push_back(s);
//	}
//	fclose(f);
//	for(auto v:C) cout<<setw(20)<<left<<v.ten<<" "<<v.tuoi<<" "<<v.diem<<"\n";
//}
//

