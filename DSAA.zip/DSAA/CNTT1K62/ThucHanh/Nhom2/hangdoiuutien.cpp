//Hang doi uu tien
#include<bits/stdc++.h>
using namespace std;
int main()
{
	//priority_queue<int> Q;
	priority_queue<int,vector<int>,greater<int>> Q;
	for(int x:{31,523,263,346,52,76}) Q.push(x);
	while(Q.size())
	{
		cout<<Q.top()<<" ";
		Q.pop();
	}

}


