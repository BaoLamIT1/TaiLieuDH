//duong di trong me cung 
#include<bits/stdc++.h>
using namespace std;
class mecung
{
	int n,m,A[105][105],sx,sy,fx,fy;
	public:
		void sol()
		{
			cin>>n>>m;
			for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++) cin>>A[i][j];
			cin>>sx>>sy>>fx>>fy;
			//Xay rao bao quanh toan 1
			for(int i=0;i<=n+1;i++) A[i][0]=A[i][m+1]=1;
			for(int j=0;j<=m+1;j++) A[0][j]=A[n+1][j]=1;
			cout<<BFS(sx,sy,fx,fy);
		}
		int BFS(int sx,int sy,int fx,int fy)
		{
			queue<pair<int,int>>Q;  //Hang doi chua cac toa do duyet
			Q.push({sx,sy});
			A[sx][sy]=1;
			while(Q.size())
			{
				int x=Q.front().first,y=Q.front().second; 
				Q.pop();
				pair<int,int> Next[]={{x,y+1},{x,y-1},{x-1,y},{x+1,y}};
				for(auto v:Next)
				if(A[v.first][v.second]==0)
				{
					A[v.first][v.second]=A[x][y]+1;
					Q.push(v);
				}
				if(A[fx][fy]!=0) return A[fx][fy]-1;
			}
			return -1;
		}
};
int main(){	mecung M; M.sol();}


