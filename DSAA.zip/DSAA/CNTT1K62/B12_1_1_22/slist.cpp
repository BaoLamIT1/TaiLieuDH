//cai dat danh sach lien ket don
#include<bits/stdc++.h>
using namespace std;
//Khai bao mot node
template<class T>
struct Node
{
	T elem;
	Node *next;
	Node(T e,Node *N=NULL) {elem=e;next=N;}
};
template <class T>
class slist_ite  //Bo lap xuoi
{
	Node<T> *curr;
	public:
		Node<T>*&getcur(){return curr;} 
		slist_ite(Node<T>*c=NULL) {curr=c;}  //ham tao
		slist_ite<T>& operator=(slist_ite<T> const &it)  //toan tu gan
		{
			this->curr=it.curr;
			return *this;
		}
		bool operator!=(slist_ite<T> it)  //so sanh ko bang
		{
			return curr!=it.curr;
		}
		T &operator*(){return curr->elem;}  //toan tu lay gia tri *it
		slist_ite<T> operator++()  //++it
		{
			curr=curr->next;
			return curr;
		}
		slist_ite<T> operator++(int)  //it++
		{
			Node<T>*p=curr;
			curr=curr->next;
			return p;
		}
};
template<class T>
class slist               //danh sach lien ket don
{
	Node<T> *Head,*Trail;   //Hai con tro nam lay dau va duoi
	int n;                  //size
	public:
		slist() {Head=Trail=NULL; n=0;}
		~slist()
		{
			if(n>0)
			{
				for(Node<T>*p=Head->next;p!=NULL;p=p->next)
				{
					delete Head;
					Head=p;
				}
				delete Head;
				n=0;
				Head=Trail=0;
			}
		}
		int size() {return n;}
		bool empty() {return n==0;}
		T &front() {return Head->elem;}
		T &back() {return Trail->elem;}
		T &operator[](int k)             //list trong STL khong co ham nay
		{
			Node<T> *p=Head;
			while(k--) p=p->next;
			return p->elem;
		}
		void push_front(T x)
		{
			if(n==0) Head=Trail=new Node<T>(x);
			else Head=new Node<T>(x,Head);
			n++;
		}
		void push_back(T x)
		{
			if(n==0) Head=Trail=new Node<T>(x);
			else Trail=Trail->next=new Node<T>(x);
			n++;
		}
		void pop_back()
		{
			if(n==1) {delete[]Head; Head=Trail=NULL;}
			else
			{
				Node<T>*p=Head; 
				while(p->next!=Trail) p=p->next;
				delete Trail;
				Trail=p;
				Trail->next=NULL;
			}
			n--;
		}
		void pop_front()
		{
			if(n==1) {delete[]Head; Head=Trail=NULL;}
			else 
			{
				Node<T>*p=Head; Head=Head->next; delete p;
			}
			n--;
		}
		typedef slist_ite<T> iterator;
		iterator begin(){return Head;}
		iterator end() {return NULL;}
		void insert(iterator it,T x)
		{
			Node<T>*q=it.getcur();
			Node<T>*p=new Node<T>(q->elem,q->next);
			q->next=p;
			q->elem=x;
			if(q==Trail) Trail=p;
			n++;
		}
		void erase(iterator it)
		{
			Node<T>*p=it.getcur();
			if(p==Head) pop_front(); 
			else if(p==Trail) pop_back(); 
			else
			{
				Node<T>*q=Head; while(q->next!=p) q=q->next;
				q->next=p->next;
				delete p;
				n--;
			}
		}
		void sort(bool ok=true) //mac dinh sap xep tang dan
		{
			if(n<=1) return;
			for(Node<T>*p=Head;p!=NULL;p=p->next)
			for(Node<T>*q=p->next;q!=NULL;q=q->next)
			if(q->elem<p->elem==ok) swap(p->elem,q->elem);  
			//ve code doi moi noi thay vi doi du lieu
		}
};

int main()
{
	slist<int> L;
	for(int x:{234,262,55,557,235,26,521,624,63,67,36,34})
	x%2==0?L.push_front(x):L.push_back(x);
	//for(int i=0;i<L.size();i++) cout<<L[i]<<" ";
	cout<<"\nL: "; for(slist<int>::iterator it=L.begin();it!=L.end();it++) cout<<*it<<" ";
	slist<int>::iterator it1;
	it1=L.begin();
	L.insert(it1,-5);
	cout<<"\nL: "; for(auto z:L) cout<<z<<" ";
	it1=L.begin(); for(int i=1;i<=5;i++) it1++;
	L.insert(it1,-3);
	cout<<"\nL: "; for(auto z:L) cout<<z<<" ";
	it1=L.begin(); for(int i=1;i<L.size();i++) it1++;
	cout<<"\n"<<*it1<<"\n";
	L.insert(it1,-7);
	cout<<"\nL: "; for(auto z:L) cout<<z<<" ";
	L.push_back(100);
	cout<<"\nL: "; for(auto z:L) cout<<z<<" ";
	L.erase(L.begin());
	it1=L.begin(); for(int i=1;i<L.size();i++) it1++;
	L.erase(it1);
	it1=L.begin(); for(int i=1;i<=7;i++) it1++;
	L.erase(it1);
	cout<<"\nL: "; for(auto z:L) cout<<z<<" ";
	L.sort(false);
	cout<<"\nL: "; for(auto z:L) cout<<z<<" ";
	
}


