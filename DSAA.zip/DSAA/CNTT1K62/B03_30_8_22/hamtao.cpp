//Ham tao va ham huy
#include<bits/stdc++.h>
using namespace std;
class ps
{
	public: 
	int t,m;
	//hamtao tao nen hinh hai voc dang ban dau
	//co ten trung ten lop khong co kieu tra ve
	ps() {t=0;m=1;}
	ps(int a,int b) {t=a,m=b;}
	~ps() {cout<<"\ngoi ham huy";}
};
int main()
{
	ps p; //goi den ham tao neu co ham tao neu khong goi ham tao mac dinh
	cout<<"\np = "<<p.t<<"/"<<p.m;
	ps q(4,5);  //goi ham tao co doi
	cout<<"\nq = "<<q.t<<"/"<<q.m;
	ps *r=new ps,*s=new ps(3,4);
	cout<<"\nr = "<<r->t<<"/"<<r->m;
	cout<<"\ns = "<<s->t<<"/"<<s->m;
	delete r;
	delete s;
}


