#include<bits/stdc++.h>
using namespace std;
template <class T,class K>
T UCLN(T a,K b)
{
	while(b!=0)  //while(b)
	{
		T r=a%b;
		a=b;
		b=r;
	}
	return a;
}
int main()
{
	long long a=1980000000000000,b=3000000000000;
	cout<<UCLN<long long,long long>(a,b)<<"\n";
	cout<<UCLN<long,int>(13680L,300);

}


