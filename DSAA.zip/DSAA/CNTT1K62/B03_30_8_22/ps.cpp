//
#include<bits/stdc++.h>
using namespace std;
class ps
{
	public:
	int t,m;
	ps(int a=0,int b=1) {t=a;m=b;}
};
int main()
{
	ps p(3,4),q,*r= new ps(-1);
	q=3; //gan duoc vi no co ham tao
	cout<<"q : "<<q.t<<"/"<<q.m;
	delete r;


}


