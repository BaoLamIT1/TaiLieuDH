//chu vi va dien tich tam giac
#include<bits/stdc++.h>
using namespace std;
#define x first
#define y second

int main()
{
	pair<double,double> A,B,C,D,*E,F(1,1);
	A.first=A.second=5.2;
	B=A;
	C=make_pair(1.2,2.1);
	D={3,4};   //tao pair thong qua {}
	E=new pair<double,double>(6,7);
	cout<<"\nA : "<<A.first<<"\t"<<A.second;
	cout<<"\nB : "<<B.first<<"\t"<<B.second;
	cout<<"\nC : "<<C.x<<"\t"<<C.y;
	cout<<"\nD : "<<D.first<<"\t"<<D.second;
	cout<<"\nF : "<<F.first<<"\t"<<F.second;
	cout<<"\nE : "<<E->first<<"\t"<<(*E).second;
	delete E;
}


