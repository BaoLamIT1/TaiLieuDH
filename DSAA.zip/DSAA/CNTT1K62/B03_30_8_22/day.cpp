//Nhap day va xuat
#include<bits/stdc++.h>
using namespace std;
template <class T>
void nhap(int &n,T a[])
{
	cin>>n;
	for(int i=0;i<n;i++) cin>>a[i];
}

template <class T>
void xuat(int n,T a[])
{
	for(int i=0;i<n;i++) cout<<a[i]<<" ";
}
template <class T>
T tong(int n,T *a)
{
	T s(0);  //T s=0
	for(int i=0;i<n;i++) s+=a[i];
	return s;	
}
int main()
{
	int a[100],n,m,k;
	double b[1000];
	complex<double> C[20];
	cout<<"\nNhap day a:"; nhap<int>(n,a);
	cout<<"\nNhap day b:"; nhap<double>(m,b);
	cout<<"\nNhap day C:"; nhap<complex<double> > (k,C);
	cout<<"\nDay a :"; xuat(n,a);
	cout<<"\nDay b :"; xuat(m,b);
	cout<<"\nDay C :"; xuat(k,C);
	cout<<"\nTong a : "<<tong(n,a);
	cout<<"\nTong b : "<<tong(m,b);
	cout<<"\nTong c : "<<tong(k,C);
}


