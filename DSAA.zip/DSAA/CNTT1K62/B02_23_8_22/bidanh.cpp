//bi danh trong C++
#include<bits/stdc++.h>
using namespace std;
void bp(int x,int &y)
{
	y=x*x;
}
int main()
{
//	int x=5;
//	cout<<"x = "<<x<<" luu tai dia chi "<<&x<<"\n";
//	int &y=x;
//	cout<<"y = "<<y<<" luu tai dia chi "<<&y;
	int a=7,b=3;
	bp(a,b);
	cout<<"b = "<<b;
	bp(a+b,a);
	cout<<"\na = "<<a; //56^2
}


