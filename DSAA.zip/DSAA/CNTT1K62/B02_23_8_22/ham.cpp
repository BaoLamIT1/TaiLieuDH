#include<bits/stdc++.h>
using namespace std;

int fun(int a,int b)
{
	return 2*a+3*b;
}

int main()
{
	int x=fun(3+4,2*5);
	cout<<x;
}


