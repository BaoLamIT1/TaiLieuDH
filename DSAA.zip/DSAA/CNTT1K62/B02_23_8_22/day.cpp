//Nhap vao 1 day so nguyen co cap phat bo nho dong, tinh tong,
#include<bits/stdc++.h>
using namespace std;
void nhap(int &n,int *&a,char ten)
{
	cout<<"\nnhap so pt day "<<ten<<" "; cin>>n;
	a=new int [n+1];
	for(int i=0;i<n;i++) {cout<<ten<<"["<<i<<"]= ";cin>>a[i];}
}
void xuat(int n,int *a)
{
	for(int i=0;i<n;i++) cout<<a[i]<<" ";
}
int sum(int n,int *a)
{
	int s=0;
	for(int i=0;i<n;i++) s+=a[i];
	return s;
}
int main()
{
	int n,m,*a,*b;
	nhap(n,a,'a');	cout<<"\nDay a:"; xuat(n,a);
	nhap(m,b,'b');	cout<<"\nDay b:"; xuat(m,b);
	cout<<"\nTong 2 day a va b :"<<sum(n,a)+sum(m,b);
	delete []a;
	delete []b;
}


