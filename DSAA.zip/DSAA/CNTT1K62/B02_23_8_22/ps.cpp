//nap chong toan tu
//Viet cac toan tu ++, < , *, / , -
#include<bits/stdc++.h>
using namespace std;

struct ps
{
	int t,m;
};
ps operator+(ps p,ps q)
{
	ps r;
	r.t=p.t*q.m+p.m*q.t;
	r.m=p.m*q.m;
	return r;
}

int main()
{
	ps a,b,c; a.t=5;a.m=6; b.t=2;b.m=4; c.t=3;c.m=2;
	ps d=a+(-b)+c;
	cout<<d.t<<"/"<<d.m;
	cout<<"\nUCLN "<<__gcd(-12,21);
}


