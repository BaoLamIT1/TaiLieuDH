#include<bits/stdc++.h>
using namespace std;

void binhphuong(int x,int *y)  //x - tham tri; y->tham bien con tro
{
	*y=x*x;
}


int main()
{
	int a=7,b=3;
	binhphuong(a,&b);
	cout<<b;

}


