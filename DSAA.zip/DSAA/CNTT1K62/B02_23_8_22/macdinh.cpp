//Ham co doi mac dinh
#include<bits/stdc++.h>
using namespace std;
int func(int a=3,int b=6);  //khai bao nguyen mau ham, co mac dinh cho cac tham so
int main()
{
	int u=12,v=5;
	cout<<func(2*u,v)<<"\n"; //29
	cout<<func(2*u)<<"\n";   //30
	cout<<func()<<"\n";      //9
}
int func(int a,int b)
{
	return a+b;
}


