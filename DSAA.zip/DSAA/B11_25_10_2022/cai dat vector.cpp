//cai dat vector
#include<iostream>
#include<bits/stdc++.h>
using namespace std;
template<class T>
class vt_rite // xay dung bo lap nguoc cho vector
{
	T*curr ;
	public:
		vt_rite(T *c=NULL){curr=c;}
		vt_rite<T> &operator=(vt_rite<T> it) { this-> curr=it.curr; return *this;
		}
		bool operator !=(vt_rite<T> it) { return this-> curr != it.curr;
		}
	
};
template <class T>
class Vector{
int n , cap; // n_size, cap_ capacity;
T*buf; // luu cac phan tu
private:
	void recap(int k) // mo rong kha nang luu theo k
	{
		if(cap>=k) return ;
		cap=k;
		T *temp= new T[cap];
		for(int i=0;i<n;i++) tem[i] = buf[i];
		if(buf) delete[] buf;
		buf=tem;
	} 
public:
	typedef T*iterator;
	iterator begin() {return buf;	}
	iterator end() { return buf+n;	}
	typedef vt_rite<T> reverse_iterator;
	reverse_iterator rbegin(){ return buf+n-1;}
	reverse_iterator rend(){ return buf-1;}
	Vector() { n=cap=0;buf=NULL;
	}
	Vector(int k,T,x)
	{
		if(v.n==0){this ->buf=0; this->n=this->cap=0;
		}
		else{
			this->buf=new T[cap];
			for(int i=0;i<n;i++) this-> buf[i]=v.buf[i];
			this->n=v.n;
			this->cap=v.cap;
		}
	}
	Vector<T> &operator =(Vector<T> &v)
	{
		if(v.n==0) {this->buf=0;this->n=this->cap=0;	}
		else{
			this->buf=new T[cap];
			for(int i=0;i<n;i++) this-> buf[i]=v.buf[i];
			this->n=v.n;
			this->cap=v.cap;
		}
		return *this;
	}
	~Vector() { if(buf) delete[]buf;}
	int size() { return n;}
	bool empty(){ return n==0;}
	T &front(){ return buf[0];}
	T &back(){ return buf[n-1];}
	T &operator[](int i){ return buf[i];}
	void pop_back() {n--;}
	void push_back(T x)
	{
		if(n==cap) recap(cap?cap*2:1);
		buf[n++]=x;
	}
void reszie(int k,T,)
{
	if(n>=k) { n=k; return ;} //thu nho
	if(k>cap) recap(k);
	for(int i=n;i<k;i++) buf[i]=x;
	n=k;
}
void insert(iterator it,T x)
{
	if(n==cap)
	{
		int k=it-buf;
		recap(cap?cap*2:1);
		it=buf+k;
	}
	for(iterator it1=buf+n-1;it>=it;it1--) *(it1+1)*it1;
	*it=x;
	n++;
}
void erase(iterator it)
{
	for(iterator it1=it; it1<buf+n;it1++) *it1=*(it1+1);
	n--;
}
};
int main() {
/*Vector <int> A(5,3);
A.front()=7;
A.back()=4;
for(int i=0;i<A.size();i++) 
cout<<A[i]<<" ";
for(Vector<int> ::iterator it=A.begin();it != A.end(); it++) cout<<*it<<" ";
for(auto x:A) cout<<x<<" ";
*/
Vector<int> A(5,7);
for(int x:{42,63,7543,83,73}) A.push_back(x);

//auto it=A.begin();
Vector <int> ::iterator it=A.begin();
it++; it++;it++;
*it+6;
cout<<"\nA: "; for(auto x:A) cout<<x<<" ";
A.insert(it,100);
cout<<"\nA: "; for(auto x:A) cout<<x<<" ";
it=A.begin()+6; // it++; it++;it++;
A.erase(it);
cout<<"\nA: " ; for(auto x:A) cout<<x<<" ";
Vector<int> B=A; //toan tu copy
cout<<"\nB: "; for(auto x:B) cout<<x<<" ";
Vector<int> C;
C=A; // toan tu gan=
cout<<"\nC: "; for(auto x:C) cout<<x<<" ";
cout<<"\nC dao nguoc: \n";
for(Vector<int> ::reverse_iterator it=A.rbegin(); it!=A.rend();it++)
cout<<*it<<" ";
}
