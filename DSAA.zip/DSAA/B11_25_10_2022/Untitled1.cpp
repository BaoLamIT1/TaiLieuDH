
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;

      
int main() {
int n , k;
cin>>n>>k;
int a[n]; for(int &x:a) cin>>x;
for(int i=0;j=k-1;j<n;i++,j++)
cout<<*max_element(a+i,a+j+1) <<" ";
}
