#include<bits/stdc++.h>
using namespace std;
int main()
{
	vector<int> A(5,7); 
	for(int x:{42,63,7543,83,73}) A.push_back(x);
	
	//auto it=A.begin();
	vector<int>::iterator it=A.begin();
	it++; it++;it++;
	*it=6;
	cout<<"\nA: ";for(auto x:A) cout<<x<<" ";
	A.insert(it,100);
	cout<<"\nA: ";for(auto x:A) cout<<x<<" ";
	it=A.begin()+6;//;	it++; it++;it++; it++;
	A.erase(it);	
	cout<<"\nA: ";for(auto x:A) cout<<x<<" ";
//	cout<<"\nA: ";for(auto x:A) cout<<x<<" ";
	
}


