// LIST
#include<list>
#include<bits/stdc++.h>
      using namespace std;     
int main() {
list<int> L(5,3);
L.front()=7;
L.back()=8; // 7 3 3 3 8
L.push_front(1);
L.push_back(6); // 1 7 3 3 3 8 6
cout<<"\nL: ";
for(list<int>::iterator it=L.begin(); it!= L.end();it++) cout<<*it<<" ";
L.pop_front();
L.pop_back();
cout<<"\nTruoc sort L: "; for(auto x:L) cout<<x<<" ";
L.sort();
cout<<"\nSau sort L: "; for(auto x:L) cout<<x<<" ";
auto it=L.begin(); it++;it++;++it;
L.insert(it,9);
cout<<"\nL : "; for(auto x:L) cout<<x<<" ";
it=L.begin(); it++;it++;
L.erase(it); //xoa so 3
it=L.begin(); while(*it!=7) it++; L.erase(it);
cout<<"\n L:"; for(auto x:L) cout<<x<<" ";
cout<<"\nsize : " << L.size();

}
