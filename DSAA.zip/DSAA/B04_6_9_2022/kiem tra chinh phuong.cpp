#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<conio.h>
#include<string.h>
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
bool ktcp( long long n){
	if(n<0 || n%3>1|| n%4>1) return 0;
	int L =0, R=n;
	while(L<=R)
	{
		int m=(L+R) /2;
		if(m*m==n) return 1;
		m*m>n?R=m-1:L=m+1;
	}
	return 0;
}
      
int main() {
	for ( int i=0; i<1000; i++)
	if( ktcp(i)) cout<<i<<" ";


}
