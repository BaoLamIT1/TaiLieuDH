
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;

      
int main() {
vector<int> A;
cout<<"\nsize : " <<A.size();
cout<<"\ncapacity : "<<A.capacity();
vector<int> B(5,1); // vector k co phan tu nao
B.push_back(3);
cout<<"\nB : " ; for(int i=0;i<B.size();i++) cout<<B[i]<< " ";
B.front()=4;
B.back()=6;
B[2]=2;
B.at(3)=5;
cout<<"\nB: " ; for(int x:B) cout<<x<<" ";
cout<<"\nDuyet xuoi B";
for(vector<int>::iterator it=B.begin(); it!=B.end();it++)
cout<<*it<<" ";
cout<<"\nDuyet nguoc B: ";
for(vector<int> ::reverse_iterator it=B.rbegin();it!=B.rend();it++) cout<<*it<<" ";
}
