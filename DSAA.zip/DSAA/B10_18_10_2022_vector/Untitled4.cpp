
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;

      
int main() {
vector<int>cong<vector<int>a,vector<int> b)
{
	vector<int> c=a;
	if(a.size() <b.size()) c.size
}

}
