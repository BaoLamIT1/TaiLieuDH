//Tinh n! (1<=n<=1000)
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
      
int main() {
int n ; cin>>n;
vector<int> A(1,1); // tao vector [1]
for(int i=2;i<=n;i++)
{
	long long nho=0;
	for(auto &x:A)
	{
		nho +=x*i;
		x=nho%10;
		nho/=10;
		
	}
	while(nho) {
		A.push_back(nho%10); nho/=10;
	
	}
}
	reverse(A.begin(), A.end());
	for(auto x:A) cout<<x;
}


