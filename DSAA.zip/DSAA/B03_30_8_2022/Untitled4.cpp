
#include<bits/stdc++.h>
      using namespace std;
struct diem                                  // LT Huong doi tuong class diem {
{                                             // public :
	double x,y;
	void nhap()
	{cin >>x>>y;}
	double kc(diem P) // tinh khoang cach hien tai den 1 diem khac
	{
		return sqrt((P.x-x)*(P.x-x)+(P.y-y)*(P.y-y));
	}
};
class tamgiac {
	public:
		diem A,B,C;
		void nhap();
		double chuvi()
		{  return B.kc(C) +A.kc(C) + A.kc(B);  }
		double dientich()
		{
			double a=B.kc(C), b=A.kc(C) , c=A.kc(B), p=(a+b+c)/2;
			return sqrt(p*(p-a)*(p-b)*(p-c));
	}
};  
void tamgiac::nhap(){
	cout<<"A : "<<A.nhap();
	cout<<"B : "<<B.nhap();
	cout<<"C : "<<C.nhap();
}
int main() {
   //diem A,*B=new diem;
   //A.nhap();
   //B->nhap();
   //cout<<"A : "<<A.x<<" " <<A.y;
   //cout<<"B :"<<B->x<<" " <<B->y;
   //cout<<"\ndo dai AB"<<A.kc(*B)<<" do dai BA"<<B->kc(A);
   //delete B;
   tam giac T;
   T.nhap();
   cout<<"\nChu vi : "<<T.chuvi();
   cout<<"\nDien tich :"<<T.dientich();}
