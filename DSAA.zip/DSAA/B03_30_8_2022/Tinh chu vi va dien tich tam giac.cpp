//Tinh chu vi va dien tich tam giac
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<conio.h>
#include<string.h>
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;

      
int main() {
	pair<double, double> A,B,C,D,F(1,1),*E;
	A.first=A.second=5.2;
	B=A; 
	C= make_pair(1.2,2.1);
	D={3,4}; // tao pair thong qua {}
	E= new pair<double,double>(6,7); //E la doi con tro
	cout <<"\nA: "<<A.first<<"\t"<<A.second;
	cout <<"\nB: "<<B.first<<"\t"<<B.second;
	cout <<"\nC: "<<C.first<<"\t"<<C.second;
	cout <<"\nD: "<<D.first<<"\t"<<D.second;
	cout <<"\nF: "<<F.first<<"\t"<<F.second;
	cout <<"\nE: "<<E->first<<"\t"<<(*E).second;
	delete E;

}
