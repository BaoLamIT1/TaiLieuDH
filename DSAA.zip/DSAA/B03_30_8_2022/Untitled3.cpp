//tam giac
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<conio.h>
#include<string.h>
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
    typedef pair<double,double> Diem;
    struct TG(Diem A,B,C); //C++
    //typedef struct(Diem A,B,:) TG ; //C
    #define x first 
    #define y second
    double kc(Diem A, Diem B) // Tinh khoang cach AB
    {
    	A.x -=B.x;
    	A.y-= B.y;
    	return sqrt(A.x*A.x+A.y*A.y);
	}
void nhap(TG &t)
{
	cout <<"A: "; cin>> t.A.first>>t.A.second;
	cout <<"B: "; cin>> t.B.first>>t.B.second;
	cout <<"C: "; cin>> t.C.first>>t.C.second;
}
double chuvi(TG t){
	return kc(t.B,t.C) + kc(t.A,t.C)+ kc(t.A,t.B);
}

double dientich(TG t){
	double a = kc(t.B,t.C) , b=kc(t.A,t.C), c=kc(t.A,t.B), p=(a+b+c)/2;
	return sqrt(p*(p-a)*(p-b)*(p-c));
}
int main() {
	TG P;
	nhap(&P);
	cout<<"\nChu vi : " << chuvi(P);
	cout<<"\nDien tich :" << dientich(P);
}

