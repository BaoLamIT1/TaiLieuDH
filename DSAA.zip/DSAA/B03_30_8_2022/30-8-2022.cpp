#include<stdio.h>
//30/8/2022
#include<math.h>
#include<stdlib.h>
#include<conio.h>
#include<string.h>
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
template <class T>
void nhap(int &n,T a[])
{
	cin >> n;
	for(int i=0;i<=n;i++)
	cin >>a[i];
}     
template <class T>
void xuat(int n , T a[]){
	for(int i=0;i<=n;i++) cout << a[i]<<" ";
} 
template <class T>
T tong(int n, T *a){
	T s(0);
	for( int i=0;i<=n;i++) s+=a[i];
	return s;
}
int main() {
     int a[ 100],n,m,k;
     double b[100];
     complex<double> C[20];
     cout <<"\nNhap day a:"; nhap<int>(n,a);
     cout <<"\nNhap day b:"; nhap<double>(m,b);
     cout <<"\nNhap day c:"; nhap<complex<double>>(k,C);
     cout <<"\nDay a "; xuat(n,a);
     cout <<"\n3 phan tu dau cua day b "; xuat(3,b);
     cout <<"\nDay C "; xuat(k,C);
     cout <<"\nTong a: "<< tong(n,a);
     cout <<"\nTong b: "<< tong(m,b);
     cout <<"\nTong c: "<< tong(k,C);
}
