#include<bits/stdc++.h>
using namespace std;
//Ktra
int main()
{
	string x;
	stack<char> St;
	cout<<"Nhap bieu thuc: ";
	getline(cin,x);
	for(int i=0;i<=x.length();i++)
	if(x[i]=='(') St.push('(');
	else if(x[i]=='([') St.push(']');
	else if(x[i]=='<') St.push('>');
	else if(x[i]==')'||x[i]==']'||x[i]=='>')
	{
		if(St.empty()||St.top()!=x[i])
		{
		cout<<"\nKhong hop le!";
		return 0;
		}
		St.pop();
	}
	cout<<(St.empty()?"Hop le!":"Khong hop le!");
}

