#include<bits/stdc++.h>
using namespace std;

int main()
{
	string x;
	cin>>x;
	stack<int> S;
	for(auto c:x)
	{
		if(c=='()')
		S.push(0);
		else if(c=='O') S.push(16);
		else if(c=='H') S.push(1);
		else if(c=='C') S.push(12);
		else if(c==')')
		{
			int t=0;
			while (S.top()!=0)
			{
				t*=S.top();
				S.pop();
			}
			S.pop();
			S.push(t);
		}
		else 
		{
			int t=S.top();
			S.pop();
			S.push(t*(c-'0'));
		}
	}
	int t=0;
	while(!S.empty())
	{
		t+=S.top();
		S.pop();
	}
	cout<<"Khoi luong phan tu: "<<t;
}

