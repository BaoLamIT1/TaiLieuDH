#include<bits/stdc++.h>
using namespace std;
//Tim duong di
//DFS  tim kiem theo chieu sau
void timduong(vector<int> P,int n,int m)
{
	if(n==m) cout<<n;
	else
	{
		timduong(P,n,P[m]);
		cout<<"->"<<m;
	}
}
bool DFS(int n,int m)
{
	stack<int> S;
	S.push(n);
	vector<int> P(n+5);
	while(!S.empty())
	{
		int u=S.top();
		S.pop();
		for(int a=1;a*a<=u;a++)
		if(u%a==0)
		{
			int v=(a-1)*(u/a+1);
			if(v>=m)
			{
				S.push(v);
				P[v]=u;
			}
			if(v==m) 
			{
			timduong(P,n,m);
			return true;
			}
		}
	}
	return false;
}
int main()
{
	cout<<(DFS(28,20)?"\nDi duoc":"\nKhong di duoc!");
}
