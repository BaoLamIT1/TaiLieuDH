#ifndef	stack_cpp
#define stack_cpp
template<class T>
struct node
{
	T elem;
	node *next;
	node(T e,node *n=0)
	{
		elem=e;
		next=n;
	}
};
template<class T>
class nganxep
{
	node<T> *head;
	int n;
	public:
		nganxep()
		{
			head=0;
			n=0;
		}
};
#endif
