#include<bits/stdc++.h>
using namespace std;
//vd stack
int main()
{
	stack<int> S;
	S.push(3);
	S.push(4);
	S.push(8);
	while(!S.empty())
	{
		cout<<S.top()<<endl;
		S.pop();
	}
}

