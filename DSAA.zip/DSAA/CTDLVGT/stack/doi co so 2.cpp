#include<bits/stdc++.h>
using namespace std;
//doi sang co so 2 tu 1 stn n
int main()
{
	char Hex[]="0123456789abcdefghiklmnopqrstuvwxyz";
	long long n,cs=20;
	cin>>n;
	printf("\nSo n co co so 16 la %x\n",n);
	stack<char> S;
	while(n)
	{
		S.push(Hex[n%16]);
		n/=16;
	}
	while (!S.empty())
	{
		cout<<S.top();
		S.pop();
	}
}

