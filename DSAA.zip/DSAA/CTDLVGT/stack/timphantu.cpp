#include<bits/stdc++.h>
using namespace std;
//Tim phan tu ben trai lon hon vi tri hien tai nhat
int main()
{
	int n;
	cin>>n;
	int a[n+5];
	for(int i=1;i<=n;i++)
	cin>>a[i];
	a[0]=INT_MAX;
	stack<int> S;
	S.push(0);
	for(int i=1;i<=n;i++)
	{
		while (a[S.top()]<a[i]) S.pop();
		cout<<S.top()<<" ";
		S.push(i);
	}
}

