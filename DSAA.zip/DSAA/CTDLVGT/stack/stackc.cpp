#ifndef	stack_cpp
#define stack_cpp
template<class T>
class Stack
{
	int C;//Kha nang luu tru
	T *a;//Luu du lieu
	int t;//Dinh cua stack
	void extra()
	{
		C=(C+100)*2;
		T*b=new T[C];
		for(int i=0;i<=t;i++)
		b[i]=a[i];
		delete []a;
		a=b;
	}
	public:
		Stack()
		{
			C=0;
			a=0;
			t=-1;
		}
		~Stack()
		{
			if(a) delete []a;
		}
		int size()
		{
			return t+1;
		}
		bool empty()
		{
			return t<0;
		}
		void push(T x)
		{
			if(t+1==C) extra();
			a[++t]=x;
		}
		T &top()
		{
			return a[t];
		}
		void pop()
		{
			if(empty()) return;
			t--;
		}
};
#endif

