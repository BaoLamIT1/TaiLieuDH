#include<bits/stdc++.h>
using namespace std;
struct ps
{
	int t,m;
	ps(int t=0,int m=1)
	{
		this->t=t;
		this->m=m;
	}
	ps &operator=(ps q)
	{
		this->t=q.t;
		this->m=q.m;
		return *this;
	}
	friend istream &operator>>(istream &is,ps &p)
	{
		cout<<"\nTu so: ";is>>p.t;
		cout<<"\nMau so: ";is>>p.m;
		return is;
	}
	friend ostream &operator<<(ostream &os,ps p)
	{
		os<<p.t<<"/"<<p.m;
		return os;
	}
	friend ps operator+(ps a,ps b)
	{
		return ps(a.t*b.m+a.m*b.t,a.m*b.m);
	}
};
int main()
{
	ps s(2,3),p(3,4);
	cout<<"Nhap 2 phan so"; cin>>s>>p;
	cout<<"\ns= "<<s<<"\np= "<<p;
	cout<<"\nTong p+s= "<<p+s;
}

