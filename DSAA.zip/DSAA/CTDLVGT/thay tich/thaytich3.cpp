#include<bits/stdc++.h>
using namespace std;
struct ps
{
	int t,m;
	ps(int t=0,int m=1)
	{
		this->t=t;
		this->m=m;
	}
	ps &operator=(ps q)
	{
		this->t=q.t;
		this->m=q.m;
		return *this;
	}
};
int main()
{
	ps s(2,3),p(2,4);
	cout<<"s= "<<s.t<<"/"<<s.m;
	s=p;
	cout<<"\ns= "<<s.t<<"/"<<s.m;
}

