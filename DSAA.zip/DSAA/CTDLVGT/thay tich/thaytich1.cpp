#include<bits/stdc++.h>
using namespace std;
struct num
{
	int n;//do dai
	int *a;
	num(long long m=0)
	{
		n=m>0?log10(m):0;
		a=new int[n+1];
		for(int k=n;m>0;k--,m/=10) a[k]=m%10;
	}
	~num()
	{
		delete []a;
	}
	num(string s)
	{
		n=s.length()-1;
		a=new int[n+1];
		for(int i=0;i<=n;i++)
		a[i]=a[i]-'0';
	}
	xuat()
	{
		for(int i=0;i<=n;i++) cout<<a[i];
	}
	num &operator=(num y)
	{
		n=y.n;
		delete []a;
		a=new int[n+1];
		for(int i=0;i<=n;i++) a[i]=y.a[i];
		return *this;	
	}
	friend void mult(num &p,long long x)
	{
		int s[10000],k=0;
		long long nho = 0;
		for(int i=p.n;i>=0;i--)
		{
			nho+=p.a[i]*x;
			s[k++]=nho%10;
			nho/=10;
		}
		while(nho>0)
		{
			s[k++]=nho%10;
			nho/=10;
		}
		k--;
		p.n=k;
		delete []p.a;
		p.a=new int[k+1];
		for(int i=0;i<=p.n;i++,k--) p.a[i]=s[k];
	}
};
int main()
{
	long long n;
	cout<<"Nhap n = ";cin>>n;
	num q=1;
	for(long long i=2;i<=n;i++) mult(q,i);
	cout<<n<<"! = ";
	q.xuat();
	
}

