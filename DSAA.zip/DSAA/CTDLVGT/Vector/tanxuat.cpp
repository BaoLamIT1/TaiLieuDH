#include<bits/stdc++.h>
using namespace std;

int main()
{
	int i,d[300],*p=d+'a';
	for(i=0;i<26;i++) p[i]=0;
	char x[100000];
	cout<<"Nhap xau a ";cin>>x;
	for(i=0;i<strlen(x);i++)
	p[x[i]-'a']++;
	cout<<"Tan xuat nhung chu cai xuat hien la : \n";
	for(i=0;i<26;i++)
	if(p[i]) cout<<"Ky tu "<<char(i+'a')<<" co tan xuat "<<p[i]<<endl;
}

