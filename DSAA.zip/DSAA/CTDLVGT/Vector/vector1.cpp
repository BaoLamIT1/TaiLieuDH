#include<bits/stdc++.h>
using namespace std;

int main()
{
	vector<int>  v;
	cout<<"\nKha nang chua : "<<v.capacity();
	cout<<"\nSo phan tu dang co "<<v.size();
	v.resize(10);
	cout<<"\nKha nang chua : "<<v.capacity();
	cout<<"\nSo phan tu dang co "<<v.size();
	v.resize(5);
	cout<<"\nKha nang chua : "<<v.capacity();
	cout<<"\nSo phan tu dang co "<<v.size();
	//duyet
	cout<<"\n";
	for(int i=0;i<=v.size();i++)
	v[i]=i;
	//duyet auto
	for(auto x:v)
	cout<<x<<"\t";
	cout<<"\n";
	//duyet theo bo lap xuoi
	for(vector<int>::iterator it=v.begin();it!=v.end();it++) *it=(*it)*(*it);
	//duyet theo bo lap xuoi
	for(vector<int>::reverse_iterator it=v.rbegin();it!=v.rend();it++) cout<<*it<<"\t";;
}

