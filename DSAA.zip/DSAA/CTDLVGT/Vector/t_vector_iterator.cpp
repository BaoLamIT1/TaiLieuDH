#include<bits/stdc++.h>
#include<iterator>
#include"t_vector.cpp"

using namespace std;
template <class T>
class VectorItr
{
	private:
		Vector<T>* theVector;
		T* current_Index;
	public:
		VectorItr(Vector<T>*v)
		{
			theVector = v;
			current_Index=theVector->begin();
		}
		T operator*()
		{
			return *current_Index;
		}
		T *operator++(int k)
		{
			current_Index++;
			return current_Index;
		}
		bool operator!=(T *x){return current_Index!=x;}	
};
int main()
{
	Vector<int> V(5);
	for(int i=1;i<V.size();i++) V[i]=i*i;
	for(VectorItr<int> iV(&V);iV!=V.end();iV++)
	cout<<*iV<<" ";	
}

