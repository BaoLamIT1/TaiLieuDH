#include<bits/stdc++.h>
using namespace std;

int main()
{
	string s;
	cout<<"Nhap vao xau s : ";
	getline(cin,s);
	cout<<"\nXau vua nhap la : \n";
	for(char x:s) cout<<x;
	for(char &x:s) x=toupper(x);
	cout<<"\nXau vua nhap sau khi viet hoa la : \n"<<s;
	cout<<"\nDuyet xau \n";
	for(int i=0;i<s.length();i++)
	cout<<s[i];	
}

