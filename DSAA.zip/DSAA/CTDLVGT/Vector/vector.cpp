#include<bits/stdc++.h>
using namespace std;

int main()
{
	vector<int> a(100);
	vector<int> b(10,3);	//10 ptu3
	for(int i=0;i<10;i++)
	cout<<b[i]<<"\t";
	b.resize(5);// co phan tu con 5 .
	cout<<endl;
//	for(int i=0;i<5;i++)
//	cout<<b[i]<<"\t";
	cout<<"\nDay b sau khi rz la :\n";
	for(auto x:b) cout<<x<<"\t";
	b.push_back(7);
	b.push_back(8);
	b.push_back(9);
	cout<<"\nDay b sau khi bo sung la :\n";
	for(auto x:b) cout<<x<<"\t";
	int s=0;
	//Duyet tinh tong
	for(auto x=b.begin();x!=b.end();x++)//for(vector<int>::iterator ...)
	s+=*x;
	cout<<"\nTong la " <<s;
	//Duyet nguoc 
	cout<<"\nDay b sau khi dao la :\n";
	for(auto x=b.rbegin();x!=b.rend();x++) cout<<*x<<"\t";//for(vector<int>::reverse_iterator ..)
	
}

