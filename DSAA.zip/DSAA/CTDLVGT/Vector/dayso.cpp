#include<bits/stdc++.h>
using namespace std;

int main()
{
	int n;
	cout<<"\nNhap so phan tu :";
	cin>>n;
	vector<float> A(n);
	for(auto &x:A) cin>>x;
	cout<<"\nDay vua nhap la : \n";
	for(int i=0;i<A.size();i++)
	cout<<A[i]<<"\t";//A[i]=A.at[i];
	if(A.empty()) cout<<"\nDay khong co phan tu nao!";
	else
	{
		float M=A.front();
		for(auto it=A.begin();it!=A.end();it++)
		if(M<*it)M=*it;
		cout<<"\nMax cua day la : "<<M;
	}
	vector<float>::iterator p=A.begin()+2;
	A.insert(p,100);
	cout<<"\nDay sau khi chen la : \n";
	for(int i=0;i<A.size();i++)
	cout<<A[i]<<"\t";//A[i]=A.at[i];
	for(p=A.begin();p!=A.end();p++)
	if(*p==4) break;
	if(p==A.end()) cout<<"\nDay khong co so 4.";
	else
	{
		A.erase(p);
		cout<<"\nDay sau khi xoa so 4 :\n";
		for(int i=0;i<A.size();i++)
		cout<<A[i]<<"\t";
	}
	sort(A.begin(),A.end());
	cout<<"\nDay sau khi sx la : ";
	for(int i=0;i<A.size();i++)
	cout<<A[i]<<"\t";//A[i]=A.at[i];
	sort(A.begin(),A.end(),greater<float>());
	cout<<"\nDay sau khi sx la : ";
	for(int i=0;i<A.size();i++)
	cout<<A[i]<<"\t";//A[i]=A.at[i];	
}

