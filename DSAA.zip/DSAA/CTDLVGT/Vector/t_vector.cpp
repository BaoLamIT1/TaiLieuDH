#include<bits/stdc++.h>
using namespace std;
template <class T>
class Vector
{
	private:
		int C;//Kha nang luu tru
		int n;//So luong hiem thoi
		T *A;//Chua cac phan tu
		void extra()	//mo rong kha nag luu tru
		{
			if(n<C) return;
			C=C*2;
			T *B=new T[C];
			for(int i=0;i<n;i++)
			B[i]=A[i];
			delete []A;
			A=B;
		}
	public:
		T *begin()
		{
			return &A[0];
		}
		T *end()
		{
			return &A[n];
		}
		Vector()
		{
			delete []A;
		}
		Vector(int m=0)
		{
			C=max(100,m);
			n=m;
			A=new T[C];
		}
		int size()	
		{
			return n;
		}
		bool empty()
		{
			return 0;
		}
		T &operator[](int k)	//truy cap phu tu vi tri k
		{
			if(k>=n||k<0)
			{
				cout<<"Loi chi so";
				return A[0];
			}
			return A[k];
		}
		void push_back(T x)
		{
			if(n==C) extra();
			A[n++]=x;
		}
		void insert(int r,T x)	//Chen x vao r
		{
			if(r<0||r>n) return;
			if(n==C) extra();
			for(int i=n-1;i>=r;i--)
			A[i+1]=A[i];
			A[r]=x;
			n++;
		}
		void remove(int r)
		{
			if(r<0||r>=n) return;
			for(int i = r+1;i<n;i++)A[i-1]=A[i];
			n--;			
		}
};

