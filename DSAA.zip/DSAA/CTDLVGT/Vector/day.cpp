#include<bits/stdc++.h>
using namespace std;

int main()
{
	int n;
	cin>>n;
	int a[n];
	for(int *p=a;p<a+n;p++)
	{
		cout<<"["<<p-a<<"]= ";
		cin>>(*p);
	}
	cout<<"Day vua nhap la : \n";
	for(int *p=a;p<=a+n;p++)
	cout<<(*p)<<"t";
}

