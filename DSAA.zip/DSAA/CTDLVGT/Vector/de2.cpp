/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Admin
 *
 */

#include <iostream>
#include <vector>
using namespace std;

/*
 * 
 */

class Vector {
private:
    int soChieu;
    vector<int> thanhPhan;
public:

    Vector(int soChieu) :
    soChieu(soChieu) 
	{
    }

    int GetSoChieu() const 
	{
        return soChieu;
    }

    void SetSoChieu(int soChieu) 
	{
        this->soChieu = soChieu;
    }

    vector<int> GetThanhPhan() const 
	{
        return thanhPhan;
    }

    void SetThanhPhan(vector<int> thanhPhan) 
	{
        this->thanhPhan = thanhPhan;
    }

    friend istream& operator>>(istream& in, Vector& vector) 
	{
        for (int i = 0; i < vector.soChieu; i++) 
		{
            cout << "Thanh phan thu " << i + 1 << ": ";
            int thanhPhan;
            in >> thanhPhan;
            vector.thanhPhan.push_back(thanhPhan);
        }
        return in;
    }

    friend ostream& operator<<(ostream& out, Vector& vector) 
	{
        cout << "\nSo chieu cua vector: " << vector.soChieu << endl;
        cout << "( ";
        for (int i = 0; i < vector.soChieu; i++) 
		{
            cout << vector.thanhPhan[i] << " ";
        }
        cout << ")" << endl;
    }

    int operator*(Vector& vector2) 
	{
        int tong = 0;
        for (int i = 0; i<this->thanhPhan.size(); i++) 
		{
            tong += this->thanhPhan[i] * vector2.thanhPhan[i];
        }
        return tong;
    }

    Vector operator+(Vector& vector2) 
	{
        Vector cong2Vector(this->thanhPhan.size());
        for (int i = 0; i<this->thanhPhan.size(); i++) 
		{
            int thanhPhan;
            thanhPhan = this->thanhPhan[i] + vector2.thanhPhan[i];
            cong2Vector.thanhPhan.push_back(thanhPhan);
        }
        return cong2Vector;
    }


};

int main(int argc, char** argv) 
{
	int soChieu;
    do 
	{
        cout << "Nhap so chieu cua 2 vector: ";
        cin >> soChieu;
    } while (soChieu < 1);
    Vector vector1(soChieu);
    Vector vector2(soChieu);
    cout << "Nhap vector thu 1:" << endl;
    cin >> vector1;
    cout << "\nNhap vector thu 2:" << endl;
    cin >> vector2;
    cout << "\nTich vo huong 2 vector = " << vector1*vector2;
    Vector tong2Vector = vector1+vector2;
    cout << "\nVector tong cua 2 vector vua nhap:" << endl;
    cout << tong2Vector;
    return 0;
}



