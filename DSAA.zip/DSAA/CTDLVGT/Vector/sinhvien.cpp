//danh sach sinh vien
#include<bits/stdc++.h>
using namespace std;
struct sv
{
	int tuoi;
	string hoten;
	float diem;
	friend istream &operator>>(istream &is,sv &s)
	{
		cout<<"ho ten : ";is.ignore(1);getline(is,s.hoten);
		cout<<"tuoi : ";is>>s.tuoi;
		cout<<"diem : ";is>>s.diem;
		return is;
	}
	friend ostream &operator<<(ostream &os,sv &s)
	{
		os<<setw(30)<<s.hoten<<setw(10)<<s.tuoi<<setw(10)<<s.diem;
		return os;
	}		
};
struct lop
{
	int n;
	vector<sv> A;
	void nhap();
	void xuat(string tb="");
	void sapten();
	void sapdiem();
	void diemtb();
};
void lop::sapten()
{
	sort(A.begin(),A.end(),[](sv u,sv v){return u.hoten<v.hoten;});
}
void lop::sapdiem()
{
	sort(A.begin(),A.end(),[](sv u,sv v){return u.diem>v.diem;});
}
void lop::nhap()	
{
	cout<<"so sinh vien n=";cin>>n;
	A.resize(n);
	cout<<"nhap danh sach sinh vien:\n";
	for(sv &x:A)cin>>x;
}
void lop::xuat(string tb)
{
	cout<<"\n"<<tb<<"\n";
	for(auto x:A)cout<<x<<endl;
}
int main()
{
	lop L;
	L.nhap();
	L.xuat("danh sach vua nhap");
	L.sapdiem();
	L.xuat("danh sach theo diem giam dan");
	L.sapten();
	L.xuat("danh sach theo ten tang dan");	
}
