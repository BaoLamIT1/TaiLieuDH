#include<bits/stdc++.h>
#include"t_vector.cpp"
using namespace std;
//Cai dat vector trong mang

int main()
{
	Vector<int> V(3);
	for(int i=0;i<3;i++) V[i]=i*i;
	for(int i=0;i<V.size();i++)
	cout<<V[i]<<"\t";
	cout<<"\n";
	V.push_back(0);
	V.push_back(0);
	V.push_back(8);
	for(int i=0;i<V.size();i++)
	cout<<V[i]<<"\t";
	V.insert(5,20);
	cout<<"\n";
	for(int i=0;i<V.size();i++)
	cout<<V[i]<<"\t";	cout<<"\n";
	V.remove(4);
	cout<<"\n";
	for(int i=0;i<V.size();i++)
	cout<<V[i]<<"\t";
}

