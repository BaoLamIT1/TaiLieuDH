#include<bits/stdc++.h>
using namespace std;

int main()
{
	vector<vector<int>> M;
	int m,n;
	cout<<"\nNhap so hang so cot : ";
	cin>>n>>m;
	M.resize(n);
	for(int i=0;i<n;i++)
	{
		M[i].resize(m);
		for(int j=0;j<m;j++)
		{
			cout<<"M["<<i+1<<"]["<<j+1<<"]=";
			cin>>M[i][j];
		}
	}
	cout<<"\nMa tran vua nhap la : \n";
	for(int i=0;i<n;i++)//for(auto x:M)
	{
			for(int j=0;j<m;j++)//for(auto y:x)
			cout<<M[i][j]<<"\t";
			cout<<endl;
	}
}

