#include<bits/stdc++.h>
#include"VECTOR2.CPP"
#include"VECTORITR.CPP"
using namespace std;

int main()
{
	int n,x;
	cin>>n;
	Vector<int> V;
	for(int i=0;i<n;i++)
	{
		cin>>x;
		V.insertAtRank(i,x);
	}
	cout<<"\nDay so thuc: ";
	for(int i=0;i<n;i++)
	{
		int o;
		V.getAtRank(i,o);
		cout<<o<<" ";
	}
}

