//Cai dat slist
#include<bits/stdc++.h>
#include"Node.cpp"
using namespace std;
template <class T>
class Slist
{
	private :
		Node<T> *Head ,* Trail; //Head - dau ds, Trail - cuoi ds
		int n; // So phan tu dang co trong ds
		public:
			Slist() { Head=Trail=0;n=0;} // Tao ra danh sach rong
			bool empty() { return n==0; }
			int size() {return n;}
		void push_front(T e) // Them phan tu vao dau
		{
			if(n==0) Head=Trail=new Node<T>(e);
			else Head = new Node<T>(e,Head);
			n++;
		}
		void push_back(T e) // Them phan tu vao cuoi
		{
			if(n==0) Head=Trail=new Node<T>(e);
			else
			{
				Trail->setNext(new Node<T>(e));
				Trail=Trail->getNext();
			}
		n++;
		}
		void visit() //Duyet
		{
			for(Node<T> *p=Head;p;p=p->getNext())
			cout<<p->getElem()<<"\t";
		}	
		void pop_front() //Loai bo phan tu dau
		{
			if(n=0) return;
			Head=Head->getNext();
			n--;
		}
		void pop_back() //Loai bo phan tu duoi
		{
			if(n==0) return;
			if(n==1) Head=Trail=NULL;
			else
			{
				Node<T> *p=Head;
				while(p->getNext()!=Trail) p=p->getNext();
				p->setNext(0);
				Trail=p;
			}
			n--;
		}
		void insertAfter(Node<T> *p,T e)
		{
			if(p==Trail) {push_back(e);return;}
			Node<T> *q=p->getNext();
			p->setNext(new Node<T>(e,p->getNext()));
			n++;
	    }
		Node<T> *find (T e)
		{
			for(Node<T> *p=Head;p;p=p->getNext()) if(p->getElem()==e) return p;
			return 0;
		}	
		T front() { return Head->getElem();}
		T back() { return Trail->getElem();}	
		void remove(Node<T> *p)
		{
			if(p==Trail) pop_back();
			else if(p==Head) pop_front();
		    else
			{
				Node<T> *q=Head;
				while(q->getNext()!=p) q=q->getNext();
				q->setNext(p->getNext());
				n--;
			}
		}
	void replace(Node<T> *p,T e)
	{
		p->setElem(e);
	}	
		
};
int main()
{
	Slist<int> S;
	for(int i=1;i<=10;i++) i%2?S.push_back(i):S.push_front(i);
	cout<<"\nNoi dung danh sach\n";
	S.visit();
	S.pop_front();
	S.pop_front();
	S.pop_back();
	S.pop_back();
	cout<<"\nNoi dung danh sach\n";
	S.visit();
	Node<int> *p=S.find(3);
	if(p) S.insertAfter(p,9);
	cout<<"\nNoi dung danh sach\n";
	S.visit();
	p=S.find(3);
	if(p) S.remove(p);
	cout<<"\nNoi dung danh sach\n";
	S.visit();
	p=S.find(2);
	if(p) S.replace(p,10);
	cout<<"\nNoi dung danh sach\n";
	S.visit();
}				
		 

