#include<bits/stdc++.h>
using namespace std;
struct node
{
	int Elem;
	node  *Next;
	node(int E,node *N=0)
	{
		Elem=E;
		Next=N;
	}
};
int main()
{
//	node A(3),B(4,&A),C(5,&B);
	node *A=new node(3);
	node *B=new node(4,A);
	node *C=new node(5,B);
	for(node *p=C;p!=NULL;p=p->Next)
	cout<<p->Elem<<" ";
}

