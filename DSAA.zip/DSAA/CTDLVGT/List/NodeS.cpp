//Cai dat cau truc Node
#ifndef Node__cpp
#define Node__cpp

template<class T>
class Node
{
	private:
		T Elem;
		Node *Next;
	public:
		Node(T E,Node *N=0){ Elem=E;Next=N; }
		T getElem(){ return Elem;}
		Node *getNext() {return Next;}
		void setElem(T e) {Elem=e;}
		void setNext(Node *N) { Next=N;}
	
};
#endif
