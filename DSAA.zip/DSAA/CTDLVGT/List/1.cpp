#include<bits/stdc++.h>
using namespace std;

int main()
{
	list<int> L(5);
	for(auto &x:L) cin>>x;
	cout<<"\nDay vua nhap la : ";
	for(list<int>::iterator it=L.begin();it!=L.end();it++)
	cout<<*it<<"\t";
	cout<<"\nDay dao nguoc la : ";
	for(list<int>::reverse_iterator it=L.rbegin();it!=L.rend();it++)
	cout<<*it<<"\t";
	L.push_back(4);
	L.push_front(20);
	L.push_front(60);
	cout<<"\nDay sau khi them la : ";
	for(list<int>::iterator it=L.begin();it!=L.end();it++)
	cout<<*it<<"\t";
	L.pop_back();
	L.pop_front();
	cout<<"\nDay sau khi bo la : ";
	for(list<int>::iterator it=L.begin();it!=L.end();it++)
	cout<<*it<<"\t";
	L.resize(4);
	cout<<"\nDay sau khi resize : \n";
	for(auto x:L)
	cout<<x<<"\t";
	auto itt=L.begin();
	itt++;
	L.insert(itt,10); // chen 10 vao vi tri l1;
	cout<<"\nDay sau khi chen : \n";
	for(auto x:L)
	cout<<x<<"\t";
	L.erase(L.begin(),itt);
	cout<<"\nDay sau khi chen : \n";
	for(auto x:L)
	cout<<x<<"\t";	
				
}

