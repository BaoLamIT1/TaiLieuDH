#ifndef Vector_cpp
#define Vector_cpp
template<class T>
class Vector
{
	private:
		int N;
		int n;
		T *V;
	public:
		Vector();
		~Vector();
		int getAtRank(int r,T &o);
		int replaceAtRank(int r,T o);
		int insertAtRank(int r,T o);
		int removeAtRank(int r,T &o);
		int size();
		bool empty();
};
template<class T>
Vector<T>::Vector()
{
	n=0;
	N=1;
	V=new T[1];
}
template<class T>
Vector<T>::~Vector()
{
	delete []V;
}
template<class T>
Vector<T>::getAtRank(int r,T &o)
{
	if(r<0||r>=n) return 0;
	o=V[r];
	return 1;
}
template<class T>
Vector<T>::replaceAtRank(int r,T o)
{
	if(r<0||r>=n) return 0;
	V[r]=o;
	return 1;
}
template<class T>
Vector<T>::insertAtRank(int r,T o)
{
	if(r<0||r>n) return 0;
//	V[r]=o;
	if(n==N)
	{
		if(N==0) N=10;
		else N=N*2;
		T *U;
		U=new T [N];
		for(int i=0;i<=n;i++)
		{
			U[i]=V[i];
		}
		delete []V;
		V=U;
	}
	for(int i=n-1;i>=r;i--)
	{
		V[i+1]=V[i];
	}
	V[r]=o;
	n++;
	return 1;
}
template<class T>
Vector<T>::removeAtRank(int r,T &o)
{
	if (r < 0 || r >= size()) 
	return 0;
	V[r]=o;
	for(int i=r+1;i<n;i++)
	V[i-1]=V[i];
	n--;
	return 1;
}
template<class T>
int Vector<T>::size()
{
	return n;
}
template<class T>
bool Vector<T>::empty()
{
	return n==0;
}
#endif
