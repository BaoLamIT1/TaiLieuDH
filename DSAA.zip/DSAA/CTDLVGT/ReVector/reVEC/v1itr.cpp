#ifndef VECTORITR_CPP
#define VECETORITR_CPP 
#include "v1.cpp"
template<class T>
class VectorIr
{
	private:
		Vector<T> *theVector;
		int curIndex;
	public:
		VectorIr(Vector<T>*V1)
		{
			theVector=V1;
			curIndex=0;
		}
		int hasNext()
		{
			return curIndex<theVector->size();
		}
		T next()
		{
			T o;
			theVector->getAtRank(curIndex,o);
			curIndex++;
			return o;
		}		
};
#endif
