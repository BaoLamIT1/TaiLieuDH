#ifndef VECTOR_CPP
#define VECTOR_CPP 1
template <class T>
class Vector{
	private:
		int N; //S? chi?u t?i da c?a Vector
		T *V; //luu tr? d? li?u
		int n; //S? ph?n t? hi?n c� trong Vector
	public:
		Vector();
		~Vector();
		int getAtRank(int r, T &o);	//xem
		int replaceAtRank(int r, T o);	//sua
		int insertAtRank(int r, T o);		//chen
		int removeAtRank(int r, T &o);	//xoa
		void pushback(T o)
		{
			insertAtRank(n,o);
		}
		int size(){return n;}
		int isEmpty(){return n == 0;}
};

template <class T>
Vector<T>::Vector() {
	N = 1;
	n = 0;
	V = new T[1];
}

template<class T>
Vector<T>::~Vector() {
	delete V;
}

template<class T>
//tra vi tri tai vi tri r
int Vector<T>::getAtRank(int r, T &o) {
	if (r < 0 || r >=n) return 0;
	o = V[r];
	return 1;
}
template<class T>
int Vector<T>::insertAtRank(int r, T o) {
	if (r < 0 || r >n) return 0;		//neu r = n thi chen cao cuoi
//	V[r] = o;
	if (r == n) {
		if (N == 0) N = 10;
		else N = N *2;
		T *W = new T[N];
		for (int i; i<n; i++) W[i] = V[i];
		delete []V;
		V = W;
	}
	for (int i = n-1; i >=r  ; i--) {
		V[i+1] = V[i];
	}
	V[r] = o;
	n++;
	return 1;
}


template <class T>
int Vector<T>::replaceAtRank (int r, T o) {
	if (r < 0 || r >=n) return 0;
	V[r] = o;
	return 1;
}
template <class T>
int Vector<T>::removeAtRank(int r, T &o) {
	if (r < 0 || r >=n) return 0;
	V[r] = o;
	int k=r;	
	while(k<n-1) {
	V[k] = V[k+1];
	k++;
	}
	n--;
	return 1;
}
#endif


