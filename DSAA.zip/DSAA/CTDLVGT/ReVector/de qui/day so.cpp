#include<bits/stdc++.h>
using namespace std;
int sum(int *a,int n)
{
	if(n==0) return 0;
	return sum(a,n-1)+a[n];
}
void xuat(int *a,int n)
{
	if(n==0) return;
	xuat(a,n-1);
	cout<<a[n]<<"\t";
}
void dao(int *a,int L,int R)
{
	if(L>=R) return;
	dao(a,L+1,R-1);
	swap(a[L],a[R]);
}
void chen(int *a,int n)
{
	if(n==1) return;
	if(a[n]>=a[n-1]) return;
	swap(a[n],a[n-1]);
	chen(a,n-1);
}
void sapxep(int *a,int n)
{
	if(n==1) return;
	sapxep(a,n-1);
	chen(a,n);
}
int Tong(int *a,int L,int R)
{
	if(L==R) return a[L];
	int M=(L+R)/2;
	return Tong(a,L,M)+Tong(a,M+1,R);
}
int main()
{
	int a[]={0,1,2,3,9,5,6,7,8,4},n=sizeof(a)/sizeof(int)-1;
	cout<<"\nDay a : \n";
	xuat(a,n);
	cout<<"\nTong la "<<sum(a,n);
	cout<<"\nTong la "<<Tong(a,1,n);
	dao(a,1,n);
	cout<<"\nDay a sau khi dao:\n";
	xuat(a,n);
	sapxep(a,n);
	cout<<"\nDay sau khi sap xep : \n";
	xuat(a,n);
}

