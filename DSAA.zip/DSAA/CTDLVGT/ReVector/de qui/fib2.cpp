#include<bits/stdc++.h>
using namespace std;
long long f[100];
long long fib(int n)
{
	if(f[n]>=0) return f[n];
	if(n<=1) return f[n]=n;
	return f[n]=fib(n-1)+fib(n-2);
}
int main()
{
	for(int i=0;i<100;i++)
	f[i]=-1;
	for(int k=0;k<51;k++)
	{
		cout<<fib(k)<<"\t";
	}
}

