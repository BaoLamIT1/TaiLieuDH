#include<bits/stdc++.h>
using namespace std;
int gt(int n)
{
	return n?n*gt(n-1):1;
}
int fac(int n,int k=1)
{
	if(k>n) return 1;
	return fac(n,k+1)*k;
}
int main()
{
	cout<<gt(10)<<endl;
	cout<<fac(10);
}

