#include<bits/stdc++.h>
using namespace std;
template <class T>
T POW(T x,int n)
{
	if(n==0) return 1;
	return POW(x,n-1)*x;
}
template <class T>
T Pow(T x,int n)
{
	if(n==0) return 1;
	if(n%2==0) return Pow(x*x,n/2);
	return Pow(x*x,n/2)*x;
}
int main()
{
	cout<<POW<int>(2,10)<<endl;
	cout<<Pow<int>(2,10);
}

