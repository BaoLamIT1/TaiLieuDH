#include<bits/stdc++.h>
using namespace std;
#define  ss 0.0001
double sin(double);
double cos(double);
double sin(double x )
{
	if(fabs(x)<ss)	return x;
	return 2*sin(x/2)*cos(x/2);
}
double cos(double x )
{
	if(fabs(x)<ss) return 1;
	double u=cos(x/2),v=sin(x/2);
	return u*u-v*v;
}
int main()
{
	double x=3.14159263;
	cout<<"Sinx = "<<sin(x)<<endl;
	cout<<"cosx = "<<cos(x)<<endl;
}

