#include<bits/stdc++.h>
using namespace std;
int fib(int n)
{
	if(n<=1) return n;
	return fib(n-1)+fib(n-2);
}
void fi(int n,long long &a,long long &b)
{
	if(n==1)
	{
		a=0;
		b=1;
	}
	else
	{
		fi(n-1,a,b);
		b=a+b;
		a=b-a;
	}
}
typedef pair<long long, long long> PLL;
PLL fibo(int n)
{
	if(n==1) return make_pair(0LL,1LL);
	PLL x=fibo(n-1);
	return make_pair(x.second,x.first+x.second);
}
int main()
{
	long long a,b;
	for(int k=0;k<=10;k++)
	cout<<fib(k)<<"\t";
	for(int k=1;k<=51;k++)
	{
		fi(k,a,b);
		cout<<a<<"\t";
	}
	PLL p;
	for(int k=1;k<=51;k++)
	{
		p=fibo(k);
		cout<<p.first<<"\t";
	}
}

