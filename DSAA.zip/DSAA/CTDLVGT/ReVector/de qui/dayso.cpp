#include<bits/stdc++.h>
using namespace std;
void nhap(int *&a,int &n)
{
	cout<<"Nhap vao so so nguyen : ";
	cin>>n;
	a=new int[n+2];
	cout<<"\nNhap vao day so : \n";
	for(int i=2;i<=n+1;i++)
	cin>>a[i];
}
int tich(int *a,int n)
{
	if(n==0) return 0;
	if(n>=2)
	return tich(a,n-1)*a[n];
}
void xuat(int *a,int n)
{
	if(n==1) return;
	xuat(a,n-1);
	cout<<a[n]<<"\t";
}
void chen(int *a,int n)
{
	if(n==2) return;
	if(a[n]>=a[n-1]) return;
	swap(a[n],a[n-1]);
	chen(a,n-1);
}
void sapxep(int *a,int n)
{
	if(n==2) return;
	sapxep(a,n-1);
	chen(a,n);
}
void dao(int *a,int L,int R)
{
	if(L>=R) return;
	dao(a,L+1,R-1);
	swap(a[L],a[R]);
}
int sum(int *a,int n)
{
	if(n==0) return 0;
	return sum(a,n-1)+a[n];
}
int main()
{
	int n;
	int *a;
	nhap(a,n);
	int l=n+1;
	cout<<"\nDay so vua nhap la :";
	xuat(a,l);
	cout<<"\nTich cac phan tu la : "<<tich(a,l);
	cout<<"\nTong cac phan tu la : "<<sum(a,l);
	dao(a,2,l);
	cout<<"\nDay sau khi dao la : ";
	xuat(a,l);
	sapxep(a,l);
	cout<<"\nDay sau khi sap xep la : ";
	xuat(a,l);
}

