#include<bits/stdc++.h>
using namespace std;
#include"set.cpp"
#include"setitr.cpp"
int main()
{
	int n,x;
	cin>>n;
	Vector<int> V;
	for(int i=0;i<n;i++)
	{
		cin>>x;
		V.insertAtRank(i,x);
	}
	V.pushback(5);
	cout<<V.size();
	cout<<"\nDay so thuc: ";
	for(int i=0;i<=n;i++)
	{
		int o;
		V.getAtRank(i,o);
		cout<<o<<" ";
	}
}

