#include<bits/stdc++.h>
using namespace std;

int main()
{
	string ten;
	cout<<"Nhap ten: ";
	cin.ignore(0);
	getline(cin,ten);
	cout<<ten<<"\n";
	for(int i=0;i<=ten.length()-1;i++)
	{
		if(ten[i]<97) ten[i]=ten[i]+32;
	}
	for(int i=0;i<=ten.length()-1;i++)
	cout<<ten[i];
	for(int i=0;i<=ten.length()-1;i++)
	{
		if(ten[i]>=97) ten[i]=ten[i]-32;
	}
	cout<<"\n";
	for(int i=0;i<=ten.length()-1;i++)
	cout<<ten[i];
}

