#include<bits/stdc++.h>
using namespace std;
void maxmin(int a,int b,int c,int &max,int &min)
{
	max=a>b?a:b;
	max=max>c?max:c;
	min=a<b?a:b;
	min=min<c?min:c;
}
int main()
{
	int a;
	int c;
	int b;
	int max;
	int min;
	cout<<"Nhap vao a,b,c: ";
	cin>>a>>b>>c;
	maxmin(a,b,c,max,min);
	cout<<"\nMax: "<<max<<"\nMin: "<<min;
}

