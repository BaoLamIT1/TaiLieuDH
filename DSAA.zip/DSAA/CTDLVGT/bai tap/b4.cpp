#include<bits/stdc++.h>
using namespace std;
int MaxMin(int a,int b,int c,bool ismax=true)
{
	int max,min;
	max=a>b?a:b;
	max=max>c?max:c;
	min=a<b?a:b;
	min=min<c?min:c;
	if(ismax) return max;
	if(ismax==false) return min;
}
int main()
{
	int a;
	int c;
	int b;
	int x;
	cout<<"Nhap vao a,b,c: ";
	cin>>a>>b>>c;
	x=a+b+c-MaxMin(a,b,c)-MaxMin(a,b,c,false);
	cout<<"So can tim la: "<<x;
}

