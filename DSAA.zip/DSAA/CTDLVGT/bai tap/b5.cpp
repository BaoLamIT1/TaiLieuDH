#include<bits/stdc++.h>
using namespace std;
template<class T>
void max(T a,T b,T &max)
{
	max=a>b?a:b;
}
int main()
{
	int a,b,m;
	cout<<"Nhap vao a,b: ";
	cin>>a>>b;	
	max<int>(a,b,m);
		cout<<"\nMax la: "<<m;
}

