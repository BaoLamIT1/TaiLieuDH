#include<bits/stdc++.h>
using namespace std;
template<class T>
void nhap(int n,T *&A)
{
	A=new T[n+1];
	cout<<"Nhap vao day: \n";
	for(int i=1;i<=n;i++)
	cin>>A[i];
}
template<class T>
void xuat(int n,T *A)
{
	cout<<"\nDay : \n";
	for(int i=1;i<=n;i++)
	cout<<A[i]<<"\t";
}
int main()
{
	int *A;
	int n;
	cout<<"\nNhap vao so phan tu: ";\
	cin>>n;
	nhap<int>(n,A);
	xuat<int>(n,A);
}

