#include<bits/stdc++.h>
using namespace std;

int check(int a,int b,int c)
{
	int max;
	if(a>0&&b>0&&c>0)
	{
		if(a*a+b*b==c*c) return 1;
		else if(a*a==b*b+c*c) return 1;
		else if(a*a+c*c==b*b) return 1;
		else return 0;
	}
	return 0;
}
int main()
{
	int a,b,c;
	cout<<"\nNhap vao a,b,c: ";
	cin>>a>>b>>c;
	if(check(a,b,c)==1) cout<<"\nTao thanh tam giac vuong!";
	else cout<<"\nKhong tao thanh tam giac vuong!";
}

