#include<bits/stdc++.h>
using namespace std;
template<class T>
void uc(T a,T b)
{
	T c;
	for(int i=1;i<=a;i++)
	{
		if(a%i==0&&b%i==0)
		c=i;
	}
	cout<<"\nUcln cua a va b la: "<<c;
}
int main()
{
	int a,b;
	cout<<"Nhap vao a,b: ";
	cin>>a>>b;
	uc<int>(a,b);
}

