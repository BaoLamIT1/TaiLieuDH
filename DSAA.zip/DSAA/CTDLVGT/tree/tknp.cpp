#include<bits/stdc++.h>
using namespace std;
struct Node
{
	int Elem;
	Node *Left,*Right,*Parent;
	Node(int E=0,Node *L=0,Node *R=0,Node *P=0)
	{
		Elem=0;
		Left=L;
		Right=R;
		Parent=P;
	}
};
void preorder(Node *T)
{
	if(!T) return;
	cout<<T->Elem<<" ";
	preorder(T->Left);
	preorder(T->Right);
}
void inorder(Node *T)
{
	if(!T) return;
	inorder(T->Left);
	cout<<T->Elem<<" ";
	inorder(T->Right);
}
void postorder(Node *T)
{
	if(!T) return;
	postorder(T->Left);
	postorder(T->Right);
	cout<<T->Elem<<" ";
}
Node *insert(Node *T,int x)
{
	if(T==NULL) return new Node(x);
	if(T->Elem==x) return T;
	if(T->Elem>x)
	{
		if(T->Left==0) T->Left=new Node(x,0,0,T);
		else 
		{
			T->Left=insert(T->Left,x);
			T->Left->Parent=T;
		}
	}
	else if(T->Elem<x)
	{
		if(T->Right==0) T->Right=new Node(x,0,0,T);
		else 
		{
		T->Right=insert(T->Right,x);
		T->Right->Parent=T;
		}
	}
}
int Max(Node *T)
{
	return T->Right?Max(T->Right):T->Elem;
}
int Min(Node *T)
{
	return T->Right?Min(T->Right):T->Elem;
}
void remove(Node *&T,int x)
{
	if(!T) return;
	if(T->Elem>x) remove(T->Left,x);
	else if(T->Elem<x) remove(T->Right,x);
	else
	{
		if(T->Left==0 && T->Right==0)
		{
			if(T->Parent) T==T->Parent->Left?T->Parent->Left=0:T->Parent->Right=0;
		}
		else if(T->Left)
		{
			int m=Max(T->Left);
			T->Elem=m;
			remove(T->Left,m);
		}
		else
		{
			int m=Min(T->Right);
			T->Elem=m;
			remove(T->Right,m);
		}
	}
}
Node *Find(Node *T,int x)
{
	if(!T||T->Elem==x) return T;
	return T->Elem>x?Find(T->Left,x):Find(T->Right,x);
}
void Induong(Node*T,int x)
{
	Node *p=Find(T,x);
	if(p==0) 
	{
	cout<<"\nKhong co trong cay!";
	return;
	}
	cout<<"\nDi nguoc ve goc:";
	while(p)
	{
		cout<<p->Elem<<" ";
		p=p->Parent;
	}
}
int main()
{
	Node *T=0;
	int a[]={14,7,17,10,23,50,8,16,30};
	for(auto x:a) T=insert(T,x);
	cout<<"\nTrung thu tu: "; inorder(T);
	Induong(T,30);
}
