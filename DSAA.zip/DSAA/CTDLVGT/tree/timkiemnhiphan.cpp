#include<bits/stdc++.h>
using namespace std;
struct Tree
{
	int Elem;
	Tree *Left,*Right;
	Tree(int x=0,Tree *T=NULL,Tree *P=NULL)
	{
		Elem=x;
		Left =T;
		Right=P;
	}
};
void insert(Tree *&T,int x)
{
	if(T==0) T=new Tree(x);
	else
	{
		if(T->Elem==x) return;// co toi thi them
		if(T->Elem>x)
		{
			if(T->Left) insert(T->Left,x);
			else T->Left=new Tree(x);
		}
		if(T->Elem<x)
		{
			if(T->Right) insert(T->Right,x);
			else T->Right=new Tree(x);
		}
	}
}
Tree *find(Tree *T,int x)
{
	if(!T) return NULL;
	if(T->Elem==x) return T;
	if(T->Elem>x) return find(T->Left,x);
	else return find(T->Right,x);
} 
int min(Tree *T)
{
	return T->Left?min(T->Left):T->Elem;
}
int max(Tree *T)
{
	return T->Right?max(T->Right):T->Elem;
}
void remove(Tree *&T,int x)
{
	if(!T) return;
	if(T->Elem>x) return remove(T->Left,x);
	if(T->Elem<x) return remove(T->Right,x);
	if(T->Left==0&&T->Right==0) T=0;
	else if(T->Left!=0)
	{
		int m=max(T->Left);
		T->Elem=m;
		remove(T->Left,m);
	}
	else
	{
		int m=min(T->Right);
		T->Elem=m;
		remove(T->Right,m);
	}
}
void preorder(Tree *T)
{
	if(!T) return;
	cout<<T->Elem<<" ";
	preorder(T->Left);
	preorder(T->Right);
}
void inorder(Tree *T)
{
	if(!T) return;
	inorder(T->Left);
	cout<<T->Elem<<" ";
	inorder(T->Right);
}
void postorder(Tree *T)
{
	if(!T) return;
	postorder(T->Left);
	postorder(T->Right);
	cout<<T->Elem<<" ";
}
int main()
{
	Tree *T=0;
	int a[]={14,7,17,10,23,50,8,16,30};
	for(auto x:a) insert(T,x);
	cout<<"\nTrung thu tu: \n"; inorder(T);
	Tree *p=find(T,9);
	if(p==NULL) cout<<"\nKhong co";
	else cout<<"\nCo";
	cout<<"\nMin: "<<min(T);
	cout<<"\nMax:"<<max(T);
	remove(T,23);
	cout<<"\nCay sau khi xoa 23:";
	inorder(T);
}

