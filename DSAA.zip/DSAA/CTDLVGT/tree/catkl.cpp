/*Cat thanh kim loai:
	L=20
	n=5;
	cat 5 lan tai cac vi tri:
	13  13 7			13
	9	9 4 7			9
	17	9 4 4 3			9
	4	4 5 4 4 3		5
	6	4 2 3 4 4 3		4
	
*/
#include<bits/stdc++.h>
using namespace std;
struct Tre
{
	int a,b,max;
	Tre *L,*R;
	Tre(int _a=0,int _b=0)
	{
		a=_a;
		b=_b;
		max=b-a;
		L=R=NULL;
	}	
};
void add(Tre *&T,int x)
{
	if(T->L==0)
	{
		T->L=new Tre(T->a,x);
		T->R=new Tre(x,T->b);
	}
	else T->L->b>x?add(T->L,x):add(T->R,x);
	T->max=max(T->L->max,T->R->max);
}
int main()
{
	int n=5,m=20,a[]={13,9,17,4,6};
	Tre *T=new Tre(0,20);
	for(auto tt:a) 
	{
		add(T,tt);
		cout<<T->max<<"\t";
	}
}

