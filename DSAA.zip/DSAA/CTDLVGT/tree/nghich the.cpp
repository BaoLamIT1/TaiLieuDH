/*
	Dem so nghich the cua phep the
	cho n va a1,... ,an la hoan vi {1,..,n}
	vd: 4 7 3 6 2 1
	4:3
	7:4
	3:2
	6:2
	2:1
	1:0
	tong:12
*/
#include<bits/stdc++.h>
using namespace std;
struct Tre
{
	int a,b,dem;
	Tre *L,*R;
	Tre(int u,int v)
	{
		a=u;
		b=v;
		dem=0;
		if(u<v) 
		{
			L=new Tre(u,(u+v)/2);
			R=new Tre((u+v)/2+1,v);
		}
		else L=R=0;
	}
};
int upd(Tre *&T,int x,int &d)
{
	T->dem++;
	if(T->a==T->b) return 0; 
	if(x<=T->L->b)
	{
		upd(T->L,x,d);
		d+=T->R->dem;
	}
	else upd(T->R,x,d);
}
int main()
{
	int n,x,dem=0;
	cin>>n;
	Tre *T=new Tre(1,n);
	for(int i=1;i<=n;i++)
	{
		cin>>x;
		upd(T,x,dem);
	}
	cout<<"\nSo nghih the: "<<dem;
}

