#include<bits/stdc++.h>
using namespace std;
struct Tre
{
	int V;
	Tree *R,*L;
	Tree(int x,Tre *l=0,Tre *r=0)
	{
		V=x;
		L=l;
		R=r;
	}
};
void insert(Tre *&T,int x)
{
	if(!T) T=new Tre(x);
	if(T->V==x) return;
	else if(T->V>x) 
	{
		if(T->L)T->L?insert(T->L,x):T->L=new Tre(x);
	}
	else T->R?insert(T->R,x):T->R=new Tre(x);
}
int max(Tre *T)
{
	return T->R?max(T->R):T->V;
}
int min(Tre *T)
{
	return T->R?min(T->R):T->V;
}
void *remove(Tre *&T,int x)
{
	if(!T) return;
	if(T->V>x)
	{
		if(T->L->V==x&&T->L->L==0&&T->L->R==0) T->L=0;
		else remove(T->L,x);  
	}
	if(T->V<x)
	{
		if(T->R->V==x&&T->R->L==0&&T->R->R==0) T->R=0;
		else remove(T->R,x);  
	}
	else if(T->L)
	{
		int m=max(T->L);
		T->V=m;
		remove(T->L,m);
	}
	else
	{
		int m=min(T->R);
		T->V=m;
		remove(T->R,m);
	}
}
void query(Tre *T,int x)
{
	Tre *p=T;
	stack<int> S;
	while(p&&p->V!=x)
	{
		S.push(p->V);
		p=p->V>x?p->L:p->R;
	}
	if(p==0) cout<<"-1\n";
	else
	{
		while()
	}
}
int main()
{

}

