#include<bits/stdc++.h>
using namespace std;
struct Tre
{
	int n;
	vector<Tre*> Con;
	Tre(int x=0) 
	{
		n=x;
	}
};
Tre *Create(int m)
{
	Tre *T=new Tre(m);
	for(int a=1;a*a<=m;a++)
	if(m%a==0)
	{
		int z=(a-1)*(m/a+1);
		T->Con.push_back(Create(z));
	}
	return T;
}
void PreOrder(Tre *T)
{
	if(!T) return;
	cout<<T->n<<" ";
	for(auto tt:T->Con) PreOrder(tt);
}
int sum(Tre *T)
{
	if(T==0) return 0;
	int d=0;
	for(auto tt:T->Con) d+=sum(tt);
	return d+T->n;
}
int deepth(Tre *T)
{
	if(!T) return 1;
	int d=0;
	for(auto tt:T->Con)
	{
		int kk=deepth(tt);
		if(d<kk) d=kk;
	}
	return d+1;
}
int demla(Tre *T)
{
	if(T==0) return 0;
	if(T->Con.empty()) return 1;
	int d=0;
	for(auto tt:T->Con) d+=demla(tt);
	return d;
}
int main()
{
	int n;
	cin>>n;
	Tre *T=Create(n);
	PreOrder(T);
	cout<<"\n"<<sum(T);
	cout<<"\nChieu sau:"<<deepth(T);
	cout<<"\nSo la:"<<demla(T);
}

