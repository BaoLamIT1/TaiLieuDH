#include<bits/stdc++.h>
using namespace std;
struct Tree
{
	int Elem;
	Tree *Left,*Right;
	Tree(int E=0,Tree*L=0,Tree*R=0)
	{
		Elem=E;
		Left=L;
		Right=R;
	}
};

void add(Tree *T,int x)
{
	if(T==0) T=new Tree(x);
	else
	{
		int k=T->Elem+x/3;
		if(k%2==0)
		{
			if(T->Left==0) T->Left=new Tree(x);
			else add(T->Left,x);
		}
		else
		{
			if(T->Right==0) T->Right=new Tree(x);
			else add(T->Right,x);
		}
	}
}
void PreOrder(Tree *T)
{
	if(T)
	{
		cout<<T->Elem<<" ";
		PreOrder(T->Left);
		PreOrder(T->Right);
	}
}
void InOrder(Tree *T)
{
	if(T)
	{
		InOrder(T->Left);
		cout<<T->Elem<<" ";
		InOrder(T->Right);
	}
}
void PostOrder(Tree *T)
{
	if(T)
	{
		PostOrder(T->Left);
		PostOrder(T->Right);
		cout<<T->Elem<<" ";
	}
}
int main()
{
	int a[]={4,7,2,8,1,6,3,2,4,3};
	Tree *T=0;
	for(auto x:a) add(T,x);
	cout<<"Cay duyet theo trung thu tu: ";	InOrder(T);
}

