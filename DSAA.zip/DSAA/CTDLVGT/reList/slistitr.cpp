#ifndef slistIter__cpp
#define slistIter__cpp
#include<bits/stdc++.h>
#include"node.cpp"
#include"slist.cpp"
using namespace std;

template <class T>
class SingleListItr
{
	private:
		SingleList<T> *slist;
		Node<T> *cur;
	public:
	SingleListItr(SingleList<T> *list)
	{
		slist=list;
		cur=slist->first();
	}
	void reset()
	{
		cur=slist->first();
	}
	int hasNext()
	{
		return cur!=NULL;
	}
	T next()
	{
		T o;
		o=cur->getelem();
		cur=cur->setNext();
		return o;
	}
};
#endif
