#ifndef NODE_CPP
#define NODE_CPP
#include<bits/stdc++.h>
using namespace std;
template<class T>
class Node
{
	private:
		T elem;
		Node *Next;
	public:
		Node(T e,Node *N=nullptr)
		{
			elem=e;
			Next=N;
		}
		Node *getNext()
		{
			return Next;
		}
		void setNext(Node<T> *N)
		{
			Next=N;
		}
		T getelem()
		{
			return elem;
		}
		void setElem(T e)
		{
			elem=e;
		}
		
};
#endif

