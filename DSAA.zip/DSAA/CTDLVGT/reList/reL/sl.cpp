#ifndef slist_cpp
#define slist_cpp
#include<bits/stdc++.h>
#include"node.cpp"
using namespace std;

template<class T>
class SingleList
{
	Node<T> *header;
	Node<T> *trailer;
	long n;
	public:
		SingleList()
		{
			header=trailer=0;
		}
		long size()
		{
			return n;
		}
		int isEmpty()
		{
			if(n==0) return 0;
		}
		Node<T>* first()
		{
			return header;
		}
		Node<T>* last()
		{
			return trailer
		}
		void replace(Node<T> *p,T e)
		{
			p->setelem(e);
		}
		Node<T> *insertAfter(Node<T> *p,T e)
		{
			if(p==trailer) insertLast(e);
			p->setNext(new Node<T>(e,p->getNext()));
			n++;
		}
		Node<T> *insertFirst(T e)
		{
			if(n==0) trailer=header=new Node<T>(e);
			header=new Node<T> (e,header);
		}
		Node<T> *insertLast(T e)
		{
			trailer->setNext(new Node<T>(e));
			trailer=trailer->getNext();
			n++;
		}
		void remove(Node<T> *p)
		{
		}
		Node<T> *getNode(int i)
		{
			
		}

};
#endif
