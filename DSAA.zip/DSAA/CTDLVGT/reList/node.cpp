#ifndef NODE_CPP
#define NODE_CPP
#include<bits/stdc++.h>
using namespace std;
template<class T>
class Node
{
	private:
		T elem;
		Node *Next;
	public:
		Node(T e,Node *N=nullptr)
		{
			elem=e;
			Next=N;
		}
		Node *getNext()//tra lai dia chi  cua doi tuong do thanh phan next tro den
		{
			return Next;
		}
		void setNext(Node<T>* N)
		{
			Next=N;
		}
		T getelem()
		{
			return elem;
		}
		void setelem(T e)
		{
			elem=e;
		}
};
#endif
