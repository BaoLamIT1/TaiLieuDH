#ifndef slist_cpp
#define slist_cpp
#include<bits/stdc++.h>
#include"node.cpp"
using namespace std;

template<class T>
class SingleList
{
	Node<T> *header;
	Node<T> *trailer;
	long n;
	public:
		SingleList()
		{
			header=trailer=0;
		}
		long size()
		{
			return n;
		}
		int isEmpty()
		{
			if(n==0) return 0;
		}
		Node<T>* first()
		{
			return header;
		}
		Node<T>* last()
		{
			return trailer;
		}
		void replace(Node<T> *p,T e)
		{
			p->setelem(e);
			
		}
		Node<T> *insertAfter(Node<T> *p,T e)
		{
			if(p==trailer) insertLast(e);
			else
			{
				p->setNext(new Node<T> (e,p->getNext())); //goi ham tao node
				n++;
			}
		}
		Node<T> *insertFirst(T e)
		{
			if(n==0) header=trailer=new Node<T>(e);
			else 
			{
				header=new Node<T>(e,header);
			}
			n++;
		}
		Node<T> *insertLast(T e)
		{
			trailer->setNext(new Node<T>(e));
			trailer=trailer->getNext();
			n++;
		}
		void remove(Node<T> *p)
		{
			if(p==header)
			{
				if(p==trailer) header=trailer=0;
				else header=header->getNext();
			}
			else
			{
				Node<T> *q=header;
				while(q->getNext()!=p)
				q->getNext();
				q->setNext(p->setNext());
				if(trailer==p) trailer==q;
				n--;
			}
		}
		Node<T> *getNode(int i)
		{
			if(i<0||n==0||i>=n) return 0;
			Node<T> *p;
			for(p=header;i>0;p=p->getNext(),i--);//chu y co ; o cuoi for
			return p;		
		}

};
#endif
