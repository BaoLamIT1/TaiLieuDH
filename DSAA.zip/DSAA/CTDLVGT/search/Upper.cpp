#include<bits/stdc++.h>
using namespace std;

int main()
{
	int a[]={4,7,8,8,9,15,20};
	auto it=upper_bound(a,a+7,10);
	cout<<*it;
}

