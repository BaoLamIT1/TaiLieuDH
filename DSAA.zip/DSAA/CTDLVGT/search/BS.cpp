//Tim kiem nhi phan
#include<bits/stdc++.h>
using namespace std;
bool find(int *a,int n,int k)
{
	for(int i=1;i<=n;i++) if(a[i]==k) return true;
	return false;
}
bool binarysearch(int *a,int n,int k)
{
	int L=1,R=n;
	while(L<=R)
	{
		int M=(L+R)/2;
		if(a[M]==k) return true;
		a[M]>k?R=M-1:L=M+1;
	}
}

bool BS(int *a,int L,int R,int k) //de quy
{
	if(L>R) return false;
	int M=(L+R)/2;
	if(a[M]==k) return true;
	return a[M]>k?BS(a,L,M-1,k):BS(a,M+1,R,k);
}
int main()
{
	int a[]={4,7,2,9,1,5},n=sizeof(a)/sizeof(int);
	sort(a,a+n);
	int k=6;
//	if(BS(a,0,n-1,k)) cout<<"\nDay a co k!";
//	else cout<<"\nDay a khong co k!";
	if(binary_search(a,a+n,k)) cout<<"\nDay a co k!";
	else cout<<"\nDay a khong co k!";
}

