#include<bits/stdc++.h>
using namespace std;

int main()
{
	string a;
	cin.ignore(0);
	getline(cin,a);
	if((a[0]==50&&a[1]==51)||(a[0]==48&&a[1]<53)) cout<<"\n"<<a;
}

