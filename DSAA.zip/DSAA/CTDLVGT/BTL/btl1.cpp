#include<bits/stdc++.h>
using namespace std;
class kh
{
	string ten;
	long int sdt;
	public:
		void setTen(string t)
		{
			ten=t;
		}
		void setsdt(long int n)
		{
			sdt=n;
		}
		string getTen()
		{
			return ten; 
		}
		int getsdt()
		{
			return sdt;
		}	
	 	friend void nhap(kh *a,int &n)
	 	{
	 		ifstream khach ("khachhang.txt");	
		 	khach>>n;
		 	a=new kh[n+1];
		 	for(int i=1;i<n;i++)
		 	{
		 		khach>>a[i].ten;
				khach>>a[i].sdt;	
			}
			khach.close();
		}
};
int main()
{
	int n;
	kh *a;
	nhap(a,n);
	cout<<n;
	for(int i=1;i<=n;i++)
	{
		cout<<a[i].getTen();
		cout<<a[i].getsdt();
	}
}

