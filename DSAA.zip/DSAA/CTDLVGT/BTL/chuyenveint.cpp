#include <iostream>
#include <string>
#include <string.h>
#include <math.h>
using namespace std;
int nhuan(int y)
{ 
	if(y%400==0) return 1;
 	if(y%100==0) return 0;
	if(y%4==0) return 1;
 	return 0;
}
int SN(int d,int m,int y)
{
 	int t[]={0,31,28,31,30,31,30,31,31,30,31,30,31};
 	for(int i=1;i<m;i++)
 	d+=t[i];
 	if(nhuan(y)&&m>2)d++;
 	return d;
} 
int main(){
	int d,m,y;
    // Chuyen kieu string ve int
    string s;
    cout<<"\nNhap vao ngay thang nam sinh: ";
    cin.ignore(0);
    getline(cin,s);
    int l1 = s.length();
    int tg = 0;
    tg += (int)(s[9] - '0') * pow(10, l1-8-2);
    tg += (int)(s[8] - '0') * pow(10, l1-7-2);
    tg += (int)(s[7] - '0') * pow(10, l1-6-2);
    tg += (int)(s[6] - '0') * pow(10, l1-5-2);
    tg += (int)(s[4] - '0') * pow(10, l1-4-2);
    tg += (int)(s[3] - '0') * pow(10, l1-3-2);
    tg += (int)(s[1] - '0') * pow(10, l1-2-2);
    tg += (int)(s[0] - '0') * pow(10, l1-1-2);
    cout << "tg = " << tg << '\n';
    d= tg/1000000;
	m= (tg%1000000)/10000;
	y= (tg%1000000)%10000;
	int K=0;
 	for(int i=2018;i<y;i++)
 	K+= 365+nhuan(i);
 	K=K-SN(25,10,2018)+SN(d,m,y);
    int thu=(70000+K)%7;
    cout<<thu;
    switch(thu)
    {
    	case 2 : cout<<"Thu 7";  break;
    	case 3 : cout<<"Chu Nhat";  break;
	}
}
