#include<bits/stdc++.h>
using namespace std;
template<class T>
class Queue
{
	int C;//suc chua
	int n;//so ptu hien thoi
	T *A;
	int F;//danh dau vi tri dau
	int L;//danh dau vi tri cuoi
	public:
		Queue()
		{
			n=C=0;
			F=0;
			L=-1;
			A=nullptr;
		}
		~Queue()
		{
			delete []A;
		}
		int size()
		{
			return n;
		}
		bool empty()
		{
			return n==0;
		}
		T front()
		{
			return A[F];
		}
		T back()
		{
			return A[L];
		}
		void push(T x)//them x vao cuoi
		{
			
			if(n==C)//mo rong bo nho
			{
				int new_cap=C==0?10:C*2;
				T *B=new T[new_cap];
				for(int i=F,j=0;i<F+C;i++,j++)
				B[j]=A[i%C];
				C=new_cap;
				delete []A;
				A=B;
				F=0;
				L=C-1;
			}
			L=(L+1)%C;
			A[L]=x;
			n++;
			
		}
		void pop()//xoa phan tu dau
		{
			F=(F+1)%C;
			n--;
		}
};

