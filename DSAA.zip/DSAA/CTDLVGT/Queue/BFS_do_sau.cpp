#include<bits/stdc++.h>
using namespace std;
#include"set.cpp"
bool BFS(int n,int m)
{
	if(n==m)
	return 0;
	int d[n+5];
	fill(d,d+n+1,-1);//Gan mang toan false
	queue<int> Q;
	Q.push(n);
	d[n]=0;
	while(!Q.empty())
	{
		int u=Q.front();
		Q.pop();
		for(int a=1;a*a<=u;a++)
		if(u%a==0)
		{
			int v=(a-1)*(u/a+1);
			if(v>=m && d[v]==false)
			{
				d[v]=true;
				Q.push(v);
				if(v==m) return d[v];
			}
		}
	}
	return -1;
}
int main()
{
	cout<<BFS(30,6);
}

