#include<bits/stdc++.h>
using namespace std;

template<class T>
struct Node
{
	T Elem;
	Node *Next;
	Node(T x,Node *N=0)
	{
		Elem=x;
		Next=N;
	}
};
template<class T>
class hangdoi
{
	Node<T> *F,*L;
	int n ;//so luong phan tu
	public:
	hangdoi()
	{
		F=L=0;
		n=0;
	}
	int size()
	{
		return n;
	}
	bool empty()
	{
		return n==0;
	}
	T front()
	{
		return F->Elem;	
	}
	T back()
	{
		return L->Elem;
	}	
	void pop()
	{
		F=F->Next;
		n--;
	}
	void push(T x)
	{
		if(n==0) F=L=new Node<T>(x);
		else
		{
		L->Next=new Node<T>(x);
		L=L->Next;
		n++;
		}
	}
};

