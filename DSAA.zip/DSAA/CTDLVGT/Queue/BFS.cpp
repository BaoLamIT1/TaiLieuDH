//BFS moi con duong ve 0
#include<bits/stdc++.h>
#include"set.cpp"
using namespace std;
bool BFS(int n,int m)
{
	bool d[n+5];
	fill(d,d+n+1,false);//Gan mang toan false
	Queue<int> Q;
	Q.push(n);
	d[n]=1;
	while(!Q.empty())
	{
		int u=Q.front();
		Q.pop();
		for(int a=1;a*a<=u;a++)
		if(u%a==0)
		{
			int v=(a-1)*(u/a+1);
			if(v>=m && d[v]==false)
			{
				d[v]=true;
				Q.push(v);
				if(v==m) return 1;
			}
		}
	}
	return 0;
}
int main()
{
	if(BFS(30,29)) cout<<"Di duoc!";
	else cout<<"Khong di duoc!";
}

