#include<bits/stdc++.h>
using namespace std;
#include"setNode.cpp"
int main()
{
	hangdoi<int> Q;
	Q.push(4);
	Q.push(7);
	Q.push(2);
	Q.push(8);
	Q.push(8);
	Q.push(8);
	Q.push(8);
	Q.push(8);
	Q.push(8);
	Q.push(8);
	cout<<Q.size();
	while(Q.size())
	{
		cout<<Q.front()<<"\t";
		Q.pop();
	}
}

