//Bupbe Nga
/*
	cho n bupbe cos kich thuoc a1,a2..
	2 bupbe chenh nhau khoag cach >=k se long duoc vao nhau
	hay long vao nhau sao cho so con lai la min
	12 2
	4 7 2 8 4 8 3 2 4 6 2 4
*/
#include<bits/stdc++.h>
using namespace std;
// -> 8 8 7 6 4 4 4 4 3 2 2 2 
int main()
{
	int n,k;
	cin>>n>>k;
	int a[n];
	for(auto &x:a) cin>>x;
	sort(a,a+n,greater<int>());
	queue <int> Q;
	for(auto x:a)
	{
		Q.push(x);
		if(Q.front()>=x+k) Q.pop();
	}
	cout<<Q.size();
}

