#include<bits/stdc++.h>
using namespace std;

int main()
{
	set<int> S;// set:ko co 2 pt giong nau con multiset thi cho phep
	S.insert(4);
	S.insert(4);
	S.insert(3);
	S.insert(9);
	S.insert(1);
	for(set<int>::iterator it=S.begin();it!=S.end();it++)
	cout<<*it<<" ";
}

