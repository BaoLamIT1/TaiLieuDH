//Dia dao cu chi
#include<bits/stdc++.h>
using namespace std;
struct Cach
{
	int id;//Chi so
	int d;//Bac
	Cach(int _i=0,int _d=0)
	{
		id=_i;
		d=_d;
	}
};
int main()
{
	int a[]={0 ,3 ,2 ,3 , 2, 1, 1, 2, 1 ,1};
	int n=sizeof(a)/sizeof(int)-1;
	queue<Cach> Q;
	bool ok=1;
	Q.push(Cach(1,a[1]));
	for(int i=2;i<=n;i++)
	{
		while(!Q.empty() && Q.front().d==0) Q.pop();
		if(Q.empty())
		{
			cout<<"\nKhong tao duoc.";
			return 0;
		}
			Q.front().d--;
			Q.push(Cach(i,a[i]-1));
	} 
		while(!Q.empty()&&Q.front().d==0) Q.pop();
	 	cout<<(Q.empty()?"Thanh cong!":"That bai!");
}

