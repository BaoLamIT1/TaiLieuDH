#include<bits/stdc++.h>
#include<queue>
using namespace std;

int main()
{
	queue<int> Q;
	Q.push(4);
	Q.push(5);
	Q.push(6);
	Q.push(7);
	while(!Q.empty())
	{
		cout<<Q.front()<<" ";
		Q.pop();
	}
}

