//Bupbe Nga
/*
	cho n bupbe cos kich thuoc a1,a2..
	2 bupbe chenh nhau khoag cach >=k se long duoc vao nhau
	hay long vao nhau sao cho so con lai la min
	12 2
	4 7 2 8 4 8 3 2 4 6 2 4
*/
#include<bits/stdc++.h>
using namespace std;
// -> 8 8 7 6 4 4 4 4 3 2 2 2 
int main()
{
	int n,k,x;
	cin>>n>>k;
	priority_queue<int> PQ;
	for(int i=1;i<=n;i++)
	{
		cin>>x;
		PQ.push(x);
	}
	queue <int> Q;
	while(!PQ.empty())
	{
		x=PQ.top();
		Q.push(x); PQ.pop();
		if(Q.front()>=x+k) Q.pop();
	}
	cout<<Q.size();
}

