//Hang doi uu tien
#include<bits/stdc++.h>
#include<queue>
using namespace std;

int main()
{
	priority_queue<int,vector<int> , greater<int> > Q;
	Q.push(4);
	Q.push(5);
	Q.push(6);
	Q.push(7);
	Q.push(9);
	while(!Q.empty())
	{
		cout<<Q.top()<<" ";
		Q.pop();
	}
}

