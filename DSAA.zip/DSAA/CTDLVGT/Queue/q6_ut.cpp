//Noi thanh kim loai
/*
Neu noi a voi b ton 2a+b
Cho n thanh kiem loai a1,a2
Tim min chi phi
*/
#include<bits/stdc++.h>
using namespace std;

struct ss
{
	bool operator()(int a,int b)
	{
	return a>b;
	}
};
int main()
{
	int a[]={1,2,3,4,5,6,7},n=sizeof(a)/sizeof(int);
	int k=0;
	priority_queue<int,vector<int>,ss> PQ;
	while(PQ.size() >=2)
	{
		int a=PQ.top(); PQ.pop();
		int b=PQ.top(); PQ.pop();
		k+=2*a+b;
		PQ.push(a+b);
	}
	cout<<k;
}

