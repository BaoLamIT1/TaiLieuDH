#include <iostream> 
#include <fstream> 
#include <iostream> 
using namespace std;

int main()
{
    int a[10][10];
    int n;
    ifstream MaTran ("Ma Tran.txt");


        MaTran>>n;
        for(int i = 0; i < n; i++)
        {
            for(int j = 0; j < n; j++)
            {
                MaTran>>a[i][j];
            }
        }

    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
        {
            cout<<a[i][j];
            cout<<" ";
        }
        cout<<"\n";
    }
    MaTran.close();
    system("pause");
    return 0;
}
