#include<bits/stdc++.h>
using namespace std;
#define FOR(i,a,b) for(int i=a;i<=b;i++)
struct Gauss
{
	int n;
	float **a;
	~Gauss()
	{
		FOR(i,1,n) delete []a[i];
		delete []a;
	}
	void Nhap(char *name)
	{
		ifstream fin;
		fin.open(name,ifstream::in);
		fin>>n;
		a= new float* [n+1];
		FOR(i,1,n)
		{
			a[i] = new float [n+2];
			FOR(j,1,n+1) fin>>a[i][j];
		}
		fin.close();
	}
	void Xuat()
	{
		FOR(i,1,n)
		{
			FOR(j,1,n+1) cout<<setw(5)<<a[i][j];
			cout<<endl;
		}
	}
	void BDTT(int u,int v,float p=1) //Dem hang u nhan voi gia tri p cong vao hang v
	{
		FOR(j,1,n+1) a[v][j]+=a[u][j]*p;
	}
	void BuocThuan()
	{
		FOR(j,1,n-1)
		{
			if(a[j][j]==0)
			{
				int ok=0;
				FOR(i,j+1,n) if(a[i][j]) {ok=i;break;}
				if(ok==0) {cout<<"He vo nghiem hoac vo so nghiem"; return;}
				else BDTT(ok,j);
			}
			FOR(i,j+1,n) BDTT(j,i,-a[i][j]/a[j][j]);
		}
	}
	void BuocNghich()
	{
		float x[n+1];
		for(int i=n;i>=1;i--)
		{
			float s=a[i][n+1];
			for(int j=i+1;j<=n;j++) s-=a[i][j]*x[j];
			x[i]=s/a[i][i];
		}
		cout<<"\nNghiem cua he \n";
		FOR(i,1,n) cout<<"\nx"<<i<<" = "<<x[i];
	}
};

int main()
{
	Gauss G;
	G.Nhap("g1.txt");
	cout<<"Du lieu doc tu file \n";
	G.Xuat();
	G.BuocThuan();
	G.BuocNghich(); 
}

