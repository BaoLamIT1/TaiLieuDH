//Trung binh cong prefix cua mang
#include<bits/stdc++.h>
using namespace std;

void TBC(int n,float *x)  //O(n^2)
{
	for(int i=1;i<=n;i++)
	{
		float s=0;
		for(int j=1;j<=i;j++) s+=x[j];
		cout<<"A["<<i<<"] ="<<s/i;
	}
}
void TBC2(int n,float *x)  //O(n)
{
	float s=0;
	for(int i=1;i<=n;i++)
	{
		s+=x[i];
		cout<<"A["<<i<<"] ="<<s/i;
	}
}


int main()
{
	;
}

