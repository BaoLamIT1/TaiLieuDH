//#include<bits/stdc++.h>
using namespace std;

float f(int n,float x)    //O(n)
{
	float s=0;
	for(int i=1;i<=n;i++) s=s*x+1;
	return s;
}

float f2(int n,float x)  //O(n)   
{
	float s=0;
	for(int i=1;i<=n;i+=2) s=s*x+1;
	return s;
}

float f3(int n,float x)  //O(logn)   
{
	float s=0;
	for(int i=n;i>0;i/=3) s=s*x+1;
	return s;
}

float f4(int n,float x)  //O(sqrt(n))   
{
	float s=0;
	for(int i=1;i*i<=n;i++) s=s*x+1;
	return s;
}

void sort(int n,int *a) //o(n^2)
{
	for(int i=1;i<n;i++)
	for(int j=i+1;j<=n;j++) 
	if(a[i]>a[j]) swap(a[i],a[j]);
}


int main()
{
	;
}

