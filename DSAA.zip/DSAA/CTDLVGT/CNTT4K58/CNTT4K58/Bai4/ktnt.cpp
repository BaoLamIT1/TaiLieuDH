//Kiem tra nguyen to
#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
bool KTNT(LL n)
{
//	int d=0;
//	for(LL i=1;i<=n;i++) d+=n%i==0;
//	return d==2;
	if(n==2) return 1;
	if(n<2||n%2==2) return 0;
	for(LL i=3;i*i<=n;i+=2) if(n%i==0) return 0;
	return 1;
}

int main()
{
	LL n=1e18+8;
	//for(int n=1;n<=100;n++) 
	if(KTNT(n)) cout<<"n la so nguyen to";
	else cout<<"n khong la so nguyen to";
}

