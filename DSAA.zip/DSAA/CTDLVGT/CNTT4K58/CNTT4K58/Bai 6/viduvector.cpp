//Vector
#include<bits/stdc++.h>
#include<vector>
using namespace std;
int main()
{
	vector<int> a(10); //khai bao 1 vec to 10 phan tu
	vector<int> b(10,3); //khai bao 1 vec to 10 phan tu toan so 3
	for(int i=0;i<10;i++) cout<<b[i]<<"\t";
	b.resize(5);  //So phan tu con b0->b4
	cout<<"\nDay b sau khi resize\n";
	for(auto x:b) cout<<x<<"\t";
	b.push_back(7);   //them phan tu vao cuoi
	b.push_back(8);
	b.push_back(9);
	
	cout<<"\nDay b sau khi bo sung 7,8,9\n";
	for(int x:b) cout<<x<<"\t";
	//Duyet tinh tong
	int s=0;
	for(vector<int>::iterator x=b.begin();x!=b.end();x++) s+=*x;  //Duyet theo con tro (bo lap)
	cout<<"\nTong la "<<s; 
	//Duyet nguoc - xuat ra day dao lai
	cout<<"\nDay b theo thu tu dao\n";
	for(vector<int>::reverse_iterator x=b.rbegin();x!=b.rend();x++) cout<<*x<<"\t";
	
}

