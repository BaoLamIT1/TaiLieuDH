#include<bits/stdc++.h>
#include<iterator>
#include"t_vector.cpp"
//Bai tap ve nha code bo lap nguoc
using namespace std;

template <class T>
class VectorItr
{
	private :
		Vector<T>* theVector;
		T* current_Index;
	public:
		VectorItr(Vector<T>*v)
		{
			theVector = v;
			current_Index = theVector->begin();
		}
		T operator*(){return *current_Index;		}
		T *operator++(int k)
		{
			current_Index++;
			return current_Index;	
		}
		bool operator!=(T *x){return current_Index!=x;}
};//End of class VectorItr
int main()
{
	Vector<int>	V(5);   //Vector do chung ta code khong phai vector trong STL
	for(int i=0;i<V.size();i++) V[i]=i*i;
	//for(VectorItr<int> iV(&V);iV.hasNext();cout<<iV.next()<<" ");
	for(VectorItr<int> iV(&V);iV!=V.end();iV++)cout<<*iV<<" ";	
}
