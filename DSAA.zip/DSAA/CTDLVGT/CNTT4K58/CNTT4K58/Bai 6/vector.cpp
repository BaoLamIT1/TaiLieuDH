//Cai dat vector bang mang
#include<bits/stdc++.h>
#include"t_vector.cpp"

using namespace std;
int main()
{
	Vector<int> V(3);
	for(int i=0;i<3;i++) V[i]=i*i;
	for(int i=0;i<V.size();i++) cout<<V[i]<<"\t";
	V.push_back(6);
	V.push_back(7);
	V.push_back(8);
	cout<<"\nVec tor sau khi chen them\n";
	for(int i=0;i<V.size();i++) cout<<V[i]<<"\t";
	V.insert(3,20);
	V.insert(5,30);
	cout<<"\nVec tor sau khi chen them\n";
	for(int i=0;i<V.size();i++) cout<<V[i]<<"\t";
	V.remove(2);
	V.remove(0);
	cout<<"\nVec tor sau khi xoa\n";
	for(int i=0;i<V.size();i++) cout<<V[i]<<"\t";
}

