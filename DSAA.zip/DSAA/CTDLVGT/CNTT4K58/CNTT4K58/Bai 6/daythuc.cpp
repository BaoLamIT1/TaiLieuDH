/*
- Nhap vao mot day
- Xuat
- Tim max
- Dem so cap 2 phan tu o vi tri bat ky khac nhau co tong lon hon hoac bang 10
- Sap xep
- Nhap mot x tim co trong day khong
*/
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n;
	cout<<"Nhap so phan tu n = "; cin>>n;
	vector<float> A(n);
	for(auto &x:A) cin>>x;   //Nhap tung phan tu
	cout<<"\nDay vua nhap la :\n";
	for(int i=0;i<A.size();i++) cout<<A[i]<<"\t";  //A[i] -> A.at(i)
	if(A.empty()) cout<<"\nDay khong co phan tu nao";
	else
	{
		float M=A.front();    //M=A[0]
		for(vector<float>::iterator it=A.begin();it!=A.end();it++)
		if(M<*it) M=*it;
		cout<<"\nMax cua day "<<M;
	}
	vector<float>::iterator p=A.begin()+2;
	A.insert(p,100);
	cout<<"\nDay sau khi chen so 100 :\n";
	for(int i=0;i<A.size();i++) cout<<A[i]<<"\t";  //A[i] -> A.at(i)
	//Tim phan tu 4 va xoa khoi vector
	for(p=A.begin();p!=A.end();p++)  if(*p==4) break;
	if(p==A.end()) cout<<"\nKhong co so 4 trong day";
	else
	{
		A.erase(p);
		cout<<"\nDay sau khi xoa so 4 :\n";
		for(int i=0;i<A.size();i++) cout<<A[i]<<"\t";  //A[i] -> A.at(i)
	}
	sort(A.begin(),A.end());
	cout<<"\nDay sau khi sap xep tang dan :\n";
	for(int i=0;i<A.size();i++) cout<<A[i]<<"\t";  //A[i] -> A.at(i)
	sort(A.begin(),A.end(),greater<float>());
	cout<<"\nDay sau khi sap xep giam dan :\n";
	for(int i=0;i<A.size();i++) cout<<A[i]<<"\t";  //A[i] -> A.at(i)
	
}

