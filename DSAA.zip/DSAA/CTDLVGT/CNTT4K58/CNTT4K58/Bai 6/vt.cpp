#include<bits/stdc++.h>
using namespace std;
int main()
{
	vector<int> V;
	cout<<"\nKha nang chua "<<V.capacity();  //kha nang chua
	cout<<"\nSo phan tu dang co "<<V.size(); //so phan tu dang co
	
	V.resize(10);
	cout<<"\nKha nang chua "<<V.capacity();  //kha nang chua
	cout<<"\nSo phan tu dang co "<<V.size(); //so phan tu dang co

	V.resize(5);
	cout<<"\nKha nang chua "<<V.capacity();  //kha nang chua
	cout<<"\nSo phan tu dang co "<<V.size(); //so phan tu dang co
	//Duyet theo chi so
	cout<<endl;
	for(int i=0;i<V.size();i++) V[i]=i;
	//Duyet auto
	for(auto /*int*/ x:V) cout<<x<<"\t";
	//Duyet bo lap xuoi
	cout<<endl;
	for(/*vector<int>::iterator*/ auto it=V.begin();it!=V.end();it++) *it=(*it)*(*it);
	//Duyet bo lap nguoc
	for(/*vector<int>::reverse_iterator */auto it=V.rbegin();it!=V.rend();it++) cout<<*it<<"\t";
	
	
	
}

