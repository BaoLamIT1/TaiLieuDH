//xau string trong C++
#include<bits/stdc++.h>
using namespace std;
int main()
{
	string s;
	cout<<"Nhap vao xau s : "; //cin>>s;  //Khong doc khoang cach
	getline(cin,s);  //Doc duoc ca khoang trong
	cout<<"\nXau vua nhap\n"<<s;
	for(char &x:s) x=toupper(x);
	cout<<"\nXau vua sau khi viet hoa\n"<<s;
	sort(s.begin(),s.end());
	cout<<"\nXau vua sau khi sap xep ky tu \n"<<s;
	//Duyet
	cout<<"\nDuyet xau \n";
	for(int i=0;i<s.length();i++) cout<<s[i];
	
}

