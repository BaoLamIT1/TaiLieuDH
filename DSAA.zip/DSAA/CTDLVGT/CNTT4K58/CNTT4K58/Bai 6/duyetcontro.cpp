//Vi du ve duyet mang bang con tro
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int a[n];  //cap phat bo nho tinh cho a dung n phan tu
	for(int *p=a;p<a+n;p++)
	{
		cout<<"a["<<p-a<<"] = "; cin>>(*p);
	}
	cout<<"Day vua nhap \n";
	for(int *p=a;p<a+n;p++) cout<<(*p)<<"\t";	
}

