//Nhap mot xau cac chu thuong va dem tan xuat
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int i,d[300],*p=d+'a';
	for(i=0;i<26;i++) p[i]=0;  //p['a']=p['b']=...=p['z']=0;
	char x[30000];
	cout<<"Nhap xau x : "; cin>>x;
	for(int i=0;i<strlen(x);i++) p[x[i]-'a']++;
	cout<<"Tan xuat nhung chu cai xuat hien \n";
	for(i=0;i<26;i++)
	if(p[i]) cout<<"Ky tu "<<char(i+'a')<<" co tan xuat "<<p[i]<<endl;
}

