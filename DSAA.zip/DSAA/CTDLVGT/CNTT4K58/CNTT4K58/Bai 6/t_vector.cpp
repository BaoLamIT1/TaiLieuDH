#ifndef t_vector__cpp
#define t_vector__cpp

#include<bits/stdc++.h>
using namespace std;
template <class T>
class Vector
{
	private:
		int C;  //Kha nang luu tru    ->  Capacity
		int n;  //So luong hien thoi  ->  Volume
		T *A;   //Chua cac phan tu
		void extra()  //Mo rong kha nang luu tru
		{
			if(n<C) return;
			C=C*2; //Tang dung tich len gap doi
			//C+=100;
			T *B=new T[C];
			for(int i=0;i<n;i++) B[i]=A[i];
			delete []A;
			A=B;
		}
	public:
		T *begin(){return &A[0];}
		T *end() {return &A[n];}
		~Vector() {delete []A;}
		Vector(int m=0)
		{
			C=max(100,m);  //kha nang chua ban dau
			n=m;
			A=new T[C];
		}
		int size(){return n;}
		bool empty(){return n==0;}
		T &operator[](int k)        //Truy cap den phan tu o vi tri k
		{	
			if(k>=n|| k<0) {cout<<"loi chi so"; return A[0];}
			return A[k];
		}
		void push_back(T x)
		{
			if(n==C) extra();
			A[n++]=x;
		}
		void insert(int r,T x) //chen them x vao vi tri r
		{
			if(r<0||r>n) return;
			if(n==C) extra();
			for(int i=n-1;i>=r;i--) A[i+1]=A[i];
			A[r]=x;
			n++;
		}
		void remove(int r) //xoa di phan tu tai vi tri r
		{
			if(r<0||r>=n) return;
			for(int i=r+1;i<n;i++) A[i-1]=A[i];
			n--;
		}
};

#endif
