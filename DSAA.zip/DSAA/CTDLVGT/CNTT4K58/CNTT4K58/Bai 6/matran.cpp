//ma tran
#include<bits/stdc++.h>
using namespace std;
int main()
{
	vector<vector<int> > M;  //Khai bao mot ma tran n hang m cot thi nhu the nao
	int n,m;
	cout<<"So hang va so cot : "; cin>>n>>m;
	M.resize(n);
	for(int i=0;i<n;i++)
	{
		M[i].resize(m);
		for(int j=0;j<m;j++)
		{
			cout<<"M["<<i<<"]["<<j<<"] = ";
			cin>>M[i][j];
		}
	}
	cout<<"\nMa tran vua nhap\n";
	for(auto x:M)
	{
		for(auto y:x) cout<<y<<"\t";
		cout<<endl;
	}
}

