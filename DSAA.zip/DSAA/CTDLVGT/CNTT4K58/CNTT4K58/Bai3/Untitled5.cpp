#include<bits/stdc++.h>
using namespace std;

int &f(int y)
{
	return y;
}
int main()
{
	int x;
	int y=f(x);
	
}

