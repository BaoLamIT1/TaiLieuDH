//Con tro this
#include<bits/stdc++.h>
using namespace std;

struct ps
{
	int t,m;
	ps(int t=0,int m=1)
	{
		this->t=t;
		this->m=m;
	}
	ps &operator=(ps q)   //Tai boi toan tu gan  = 
	{
		this->t=q.m;
		this->m=q.t;
		return *this;
	}
	friend istream &operator>>(istream &is,ps &p)
	{
		cout<<"\nTu so "; is>>p.t;
		cout<<"Mau so "; is>>p.m;
		return is;
	}
	friend ostream &operator<<(ostream &os,ps p)
	{
		os<<p.t<<"/"<<p.m;
		return os;
	}
	friend ps operator+(ps a,ps b)
	{
		return ps(a.t*b.m+a.m*b.t,a.m*b.m);
	}
	ps operator*(ps p)
	{
		return ps(this->t*p.t,this->m*p.m);
	}
};
int main()
{
	ps s(2,3),p(3,4);
	cout<<"Nhap 2 phan so : "; cin>>s>>p;
	cout<<"\ns = "<<s<<"\np = "<<p;
	//p=p+s;
	cout<<"\nTong p+s = "<<p+s;
	cout<<"\nTich p*s = "<<p*s;
	cout<<"p = "<<p;
}

