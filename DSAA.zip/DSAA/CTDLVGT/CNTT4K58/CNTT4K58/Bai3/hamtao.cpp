#include<bits/stdc++.h>
using namespace std;

class ps
{
	public: int t,m;
	public:
	ps(int x=0,int y=1)  //ham tao co doi
	{
		t=x;
		m=y;
	}
	ps(string s)
	{
		sscanf(s.c_str(),"%d/%d",&t,&m);
	}
	~ps(){}
};
int main()
{
	ps r("232/3453");
	cout<<"r = "<<r.t<<"/"<<r.m;
//	ps p;   //khong doi 
//	cout<<"\np = "<<p.t<<"/"<<p.m;
//	ps q(2);    //Tao ra phan so 2/1    
//	cout<<"\nq = "<<q.t<<"/"<<q.m;
//	ps *a=new ps;   //goi ham tao khong doi
//	cout<<"\n*a = "<<a->t<<"/"<<a->m;   //*a.t   a->t
//	ps *b= new ps(5,6);  //Goi den ham tao co doi
//	cout<<"\n*b = "<<b->t<<"/"<<b->m;   //*a.t   a->t
//	p=5;
//	cout<<"\np = "<<p.t<<"/"<<p.m;
}

