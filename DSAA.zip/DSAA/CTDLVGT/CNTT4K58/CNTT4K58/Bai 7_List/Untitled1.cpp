teamplate<class T>
class slist
{
	Node<T> *Head,*Trail;
	int n;
	public:
		slist()
		{
			Head=Trail=0;
			n=0;
		}
		T back()
		{
			return Trail->getElem();
		}         
		T front()
		{
			return Head->getElem();
		}
		Node *begin()
		{
			return Head;
		}
		Node *end()
		{
			return NULL;
		}
		void pushf(T e)
		{
			if(n==0) Head=Trail=new Node(e);
			Head=new Node<T>(e,Head);
			n++;
		}
		void pushb(T e)
		{
			if(n==0) Head=Trail=new Node(e);
			else
			{
				Trail->setNext(new Node<T>(e));
				Trail=Trail->getNext();
				n++;
			}
		}
		void popf()
		{
			if(n==0) return;
			else
			{
				Head=Head->getNext();
				n--;
			}
		}
		void popb()
		{
			if(n==0) return;
			else if(n==1) Trail=Head=NULL;
			else
			{
				Node *p=Head;
				while(p->getNext()!=Trail) p=p->getNext();
				p->setNext(0);
				Trail=p;
				n--;
			}
		}
}
