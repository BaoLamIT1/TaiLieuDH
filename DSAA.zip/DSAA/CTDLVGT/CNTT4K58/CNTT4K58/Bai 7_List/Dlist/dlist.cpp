#ifndef dlist__cpp
#define dlist__cpp
#include<bits/stdc++.h>
#include"node.cpp"
using namespace std;

template <class T>
class Dlist
{
	private:
		Node<T> *Head,*Trail;
		int n;
	public:
		Dlist(){Head=Trail=0;n=0;}
		void push_back(T e)
		{
			if(n==0) {Head=Trail=new Node<T>(e);}
			else
			{
				Trail->setNext(new Node<T>(e,Trail,0));
				Trail=Trail->getNext();
			}
			n++;
		}
		void push_front(T e)
		{
			if(n==0) {Head=Trail=new Node<T>(e);}
			else
			{
				Head->setPrev(new Node<T>(e,0,Head));
				Head=Head->getPrev();
			}
			n++;
		}
		bool empty(){return n==0;}
		int sizef(){return n;}
		void visit()
		{
			for(Node<T> *p=Head;p;p=p->getNext()) cout<<p->getElem()<<"\t";
		}
		T front(){return Head->getElem();}
		T back(){return Trail->getElem();}
		Node<T>*begin(){return Head;}
		Node<T>*end(){return NULL;}
		void pop_back()
		{
			if(n==0) return;
			if(n==1) {Head=Trail=0;n=0; return;}
			Trail=Trail->getPrev();
			Trail->setNext(0);
			n--;
		}
		void pop_front()
		{
			if(n==0) return;
			if(n==1) {Head=Trail=0;n=0; return;}
			Head=Head->getNext();
			Head->setPrev(0);
			n--;
		}
		void insertAfter(Node<T>*p,T e)
		{
			if(p==Trail) push_back(e);
			else
			{
				Node<T>*q=p->getNext();
				Node<T>*r=new Node<T>(e,p,q);
				p->setNext(r);
				q->setPrev(r);
				n++;
			}
		}
		void insertBefor(Node<T>*p,T e)
		{
			if(p==Head) push_front(e);
			else insertAfter(p->getPrev(),e);
		}
		Node<T> *find(T e)
		{
			for(Node<T>*p=Head;p;p=p->getNext()) if(p->getElem()==e) return p;
			return 0;
		}
		void remove(Node<T> *p)
		{
			if(p==Head) pop_front();
			else if(p==Trail) pop_back();
			else
			{
				Node<T> *q=p->getPrev();
				Node<T> *r=p->getNext();
				r->setPrev(q); 
				q->setNext(r); 
			}
		}
		void replace(Node<T> *p,T e) {p->setElem(e);}
};
#endif

