#include<bits/stdc++.h>
#include"node.cpp"
#include"dlist.cpp"
#include"dlistiter.cpp"
using namespace std;

int main()
{
	Dlist<int> D;
	int ok=1;
	for(int i=1;i<=10;i++) 
	{
		ok? D.push_back(i):D.push_front(i);
		ok=!ok;
	}
	cout<<"\nNoi dung danh sach\n"; 	//D.visit();
	for(DlistIter<int> it=D.begin();it!=D.end();it++) cout<<*it<<"\t";
	D.pop_front();D.pop_front();
	D.pop_back();
	cout<<"\nNoi dung danh sach\n"; 	D.visit();
	Node<int> *p=D.find(2);
	if(p) D.insertAfter(p,30);
	if(p) D.insertBefor(p,45);
	cout<<"\nNoi dung danh sach\n"; 	D.visit();
	if(p) D.replace(p,20);
	cout<<"\nNoi dung danh sach\n"; 	D.visit();
	if(p) D.remove(p);
	cout<<"\nNoi dung danh sach\n"; 	D.visit();
}

