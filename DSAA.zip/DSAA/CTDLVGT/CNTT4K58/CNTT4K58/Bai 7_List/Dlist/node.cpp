
#ifndef Node__cpp
#define Node__cpp

template <class T>
class Node
{
	private :
		T Elem;
		Node *Next,*Prev;
	public:
		Node(T e,Node *P=0,Node *N=0) {Elem=e; Prev=P; Next=N;} //Ham tao
		void setElem(T e) {Elem =e;}
		void setPrev(Node *p){Prev=p;}
		void setNext(Node *p){Next=p;}
		T getElem(){return Elem;}
		Node *getPrev(){return Prev;}
		Node *getNext(){return Next;}
};


#endif
