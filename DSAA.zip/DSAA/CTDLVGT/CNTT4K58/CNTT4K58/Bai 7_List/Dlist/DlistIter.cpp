
#ifndef DlistIter__cpp
#define DlistIter__cpp
#include<bits/stdc++.h>
#include"node.cpp"
#include"dlist.cpp"
using namespace std;

template <class T>
class DlistIter    //Bo lap cho danh sach lien ket kep xuoi
{
	private :
		Node<T> *curr;  //Con tro duyet tren *S
	public:
		DlistIter(Node<T> *p=0) {curr=p;}
		T operator++(int )
		{
			T e=curr->getElem();
			curr=curr->getNext();  
			return e;
		}
		T operator*() {return curr->getElem();}
		bool operator!=(Node<T> *p) {return curr!=p;}
};

#endif
