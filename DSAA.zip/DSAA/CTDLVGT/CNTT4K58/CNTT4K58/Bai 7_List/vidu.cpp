#include<bits/stdc++.h>
#include<list>
using namespace std;
int main()
{
	list<int> L(5,1);
	for(auto &x:L) cin>>x;
	cout<<"\nDay vua duoc nhap :\n";
	for(list<int>::iterator it=L.begin();it!=L.end();it++) cout<<*it<<"\t";
	
	cout<<"\nDay dao nguoc lai:\n";
	for(list<int>::reverse_iterator it=L.rbegin();it!=L.rend();it++) cout<<*it<<"\t";
	L.push_back(12);  //them cuoi
	L.push_front(2); //them vao dau
	L.push_front(20); //them vao dau
	
	cout<<"\nDay sau khi them :\n";
	for(list<int>::iterator it=L.begin();it!=L.end();it++) cout<<*it<<"\t";
	L.pop_back();//xoa phan tu cuoi
	L.pop_front();//xoa phan tu dau

	cout<<"\nDay sau khi xoa :\n";
	for(list<int>::iterator it=L.begin();it!=L.end();it++) cout<<*it<<"\t";
	
	L.resize(4);
	cout<<"\nDay sau khi resize :\n";
	for(auto x:L) cout<<x<<"\t";
	auto itt=L.begin();
	itt++;
	L.insert(itt,10);  //chen 10 vao vi tri L[1]
	
	cout<<"\nDay sau khi chen 10 :\n";
	for(auto x:L) cout<<x<<"\t";
	L.erase(L.begin(),itt);
	cout<<"\nDay sau khi chen 10 :\n";
	for(auto x:L) cout<<x<<"\t";
	cout<<L.front();
	
}

