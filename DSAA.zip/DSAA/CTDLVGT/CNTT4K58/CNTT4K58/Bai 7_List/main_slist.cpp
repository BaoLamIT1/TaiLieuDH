#include<bits/stdc++.h>
#include"Node.cpp"
#include"slist.cpp"
using namespace std;

template <class T>
class SlistIter    //Bo lap cho danh sach lien ket don
{
	private :
		Node<T> *curr;  //Con tro duyet tren *S
	public:
		SlistIter(Node<T> *p=0) {curr=p;}
		//void operator=(Node<T> *p) {curr=p;}
		//T operator++(){curr=curr->getNext();return curr->getElem();}
		T operator++(int )
		{
			T e=curr->getElem();
			curr=curr->getNext();
			return e;
		}
		T operator*() {return curr->getElem();}
		bool operator!=(Node<T> *p) {return curr!=p;}
};
int main()
{
	Slist<int> S;
	for(int i=1;i<=10;i++) i%2?S.push_back(i):S.push_front(i);
	cout<<"Noi dung danh sach\n";	
	//S.visit();
	for(SlistIter<int> it=S.begin();it!=S.end();it++)cout<<*it<<"\t"; 
	S.pop_front();
	S.pop_front();
	S.pop_back();
	S.pop_back();
	S.pop_back();
	cout<<"\nNoi dung danh sach\n";	S.visit();
	Node<int> *p=S.find(3);
	if(p) S.insertAfter(p,9);
	cout<<"\nNoi dung danh sach\n";	S.visit();
	p=S.find(3);
	if(p) S.remove(p);
	cout<<"\nNoi dung danh sach\n";	S.visit();	
	p=S.find(2);
	if(p) S.replace(p,10);
	cout<<"\nNoi dung danh sach\n";	S.visit();	
}

