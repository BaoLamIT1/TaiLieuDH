//Cai dat slist
#ifndef slist__cpp
#define slist__cpp
#include<bits/stdc++.h>
#include"Node.cpp"
using namespace std;

template <class T>
class Slist
{
	private:
		Node<T> *Head,*Trail;   //Head-Dau ds, Trail - Cuoi ds
		int n; 					//So phan tu dang co trong ds
	public:
		Slist(){Head=Trail=0; n=0;} //Tao ra danh sach rong
		bool empty() {return n==0;}
		int size(){return n;}
		void push_front(T e)   //Them mot node vao dau danh sach
		{
			if(n==0) Head=Trail = new Node<T>(e);
			else Head=new Node<T>(e,Head);
			n++;
		}
		void push_back(T e)    //Them mot node vao cuoi danh sach
		{
			if(n==0) Head=Trail = new Node<T>(e);
			else
			{
				Trail->setNext(new Node<T>(e));
				Trail=Trail->getNext();
			}
			n++;
		}
		void visit()//duyet
		{
			for(Node<T> *p=Head;p;p=p->getNext()) cout<<p->getElem()<<"\t";
		}
		void pop_front()  //Loai bo phan tu dau;
		{
			if(n==0) return;
			Head=Head->getNext();
			n--;
		}
		void pop_back()  //Loai bo phan tu cuoi;
		{
			if(n==0) return;
			if(n==1) Head=Trail=NULL;
			else
			{
				Node<T> *p=Head;
				while(p->getNext()!=Trail) p=p->getNext();
				p->setNext(0);
				Trail=p;
			}
			n--;
		}
		Node<T> *find(T e)
		{
			for(Node<T> *p=Head;p;p=p->getNext()) if(p->getElem()==e) return p;
			return 0;
		}
		T front(){return Head->getElem();}
		T back(){return Trail->getElem();}
		Node<T> *begin(){return Head;}
		Node<T> *end(){return NULL;}
		void insertAfter(Node<T> *p,T e)
		{
			p->setNext(new Node<T>(e,p->getNext()));
			n++;
			if(p==Trail) Trail=Trail->getNext(); 
		}
		void remove(Node<T> *p)
		{
			if(p==Trail) pop_back();
			else if(p==Head) pop_front();
			else
			{
				Node<T>*q=Head;
				while(q->getNext()!=p) q=q->getNext();
				q->setNext(p->getNext());
				n--;
			}
		}
		void replace(Node<T> *p,T e)
		{
			p->setElem(e);
		}
};

#endif

