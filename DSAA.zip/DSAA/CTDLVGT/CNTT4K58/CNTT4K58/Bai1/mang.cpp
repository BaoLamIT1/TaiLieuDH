//mang -> tinh tong
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n;
	cout<<"Nhap so phan tu n = "; cin>>n;
	int a[n];  //khai bao mang a co n phan tu
	for(auto &x:a) cin>>x;
	cout<<"Mang vua nhap \n";
	for(auto x:a) cout<<x<<"\t";
	int s=0;
	for(auto x:a)s+=x;
	cout<<"\nTong cua mang "<<s;
}

