//swap 2 mang
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int a[8],b[8],*x=a,*y=b;
	for(int i=1;i<=8;i++)a[i-1]=i;
	cout<<"Mang a : ";	for(int x:a) cout<<x<<"\t";
	for(int t=1;t<3;t++)
	{
		for(int i=0;i<4;i++) y[i]=x[i]+x[i+4];
		for(int i=4;i<8;i++) y[i]=x[i]-x[i-4];
		swap(x,y);
	}
	cout<<"\nMang a sau khi bien doi : ";	for(int x:a) cout<<x<<"\t";
//	int a[3]={1,2,3},b[5]={4,5,6,7,8};
//	cout<<"Mang a : ";	for(int x:a) cout<<x<<"\t";
//	cout<<endl;
//	cout<<"Mang b : ";	for(int x:b) cout<<x<<"\t";
//	
//	int *u=a,*v=b;
//	swap(u,v);  //u tro toi b, v tro toi a
//	
//	cout<<"\nMang u : ";	for(int i=0;i<5;i++) cout<<u[i]<<"\t";
//	cout<<"\nMang v : ";	for(int i=0;i<3;i++) cout<<v[i]<<"\t";

}

