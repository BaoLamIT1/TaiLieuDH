//binh phuong
#include<bits/stdc++.h>
using namespace std;

int bp(int x) {return x*x;}
float bp(float x) {return x*x;}

int main()
{
	int x=bp(3);     //
	float z=bp(3.5f); //
	float t=bp(4);   //
	cout<<"\nx = "<<x;
	cout<<"\nz = "<<z;
	cout<<"\nt = "<<t;
}

