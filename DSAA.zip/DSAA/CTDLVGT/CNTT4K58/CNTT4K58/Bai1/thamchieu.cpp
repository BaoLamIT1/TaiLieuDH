//tham chieu
#include<bits/stdc++.h>
using namespace std;

void bp(int x,int &y){y=x*x;}
int main()
{
	int a=3,b=5;
	bp(a,b);
	cout<<"a = "<<a<<endl<<"b = "<<b<<endl;
	swap(a,b);  //hoan doi
	cout<<"a = "<<a<<endl<<"b = "<<b;
	
//	int x;
//	int &y=x;  //y la tham chieu cua x tuc la x va y co cung vung nho
//	y=7;
//	cout<<"x = "<<x;
}

