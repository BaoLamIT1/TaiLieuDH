//Giai phuong trinh bac nhat voi he so phuc
#include<bits/stdc++.h>
using namespace std;

int main()
{
	complex<float> a,b,k(0,0);  //ax+b=0;
	cout<<"Nhap vao a = "; cin>>a;
	cout<<"Nhap vao b = "; cin>>b;
	if(a==k) cout<<(b==k?"vo so nghiem":"vo nghiem");
	else cout<<"Nghiem x = "<<-b/a;
}

