//nhap day
#include<bits/stdc++.h>
using namespace std;

void nhapday(int &n,int *&a)  //Nhap so phan tu, cap phat dong va nhap day
{
	cout<<"So phan tu n = "; cin>>n;
	a=new int[n];
	for(int i=0;i<n;i++) {cout<<"a["<<i<<"]="; cin>>a[i];}
}
void nhapday(int *n,float **a)  //Nhap so phan tu, cap phat dong va nhap day
{
	cout<<"So phan tu n = "; cin>>(*n);
	(*a)=new float[*n];
	for(int i=0;i<*n;i++) {cout<<"a["<<i<<"]="; cin>>(*a)[i];}
}
int main()
{
	int n,*a;
	nhapday(n,a); 
	cout<<"\n day a vua nhap \t";
	for(int i=0;i<n;i++) cout<<a[i]<<"\t";
	int m;
	float *b;
	nhapday(&m,&b);
	cout<<"\n day b vua nhap \t";
	for(int i=0;i<m;i++) cout<<b[i]<<"\t";
}

