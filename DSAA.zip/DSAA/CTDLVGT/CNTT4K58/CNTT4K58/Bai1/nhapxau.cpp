//Nhap xuat voi xau ky tu

#include<bits/stdc++.h>
using namespace std;
int main()
{
//	int n;
//	char x[100];
//	cout<<"Nhap so nguyen n = ";	cin>>n;
//	cout<<"Xin moi cho biet quy danh : ";
//	cin.ignore(1);   //fflush(stdin)
//	cin.getline(x,100);
//	cout<<"Ten cua ban la "<<x;	
	string x;
	cout<<"Xin moi cho biet quy danh : ";
	getline(cin,x);
	for(auto &t:x) t=toupper(t);   //c++11
	cout<<"Ten cua ban la : "<<x;
}

