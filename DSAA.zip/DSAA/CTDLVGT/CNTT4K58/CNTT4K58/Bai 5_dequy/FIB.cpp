//Fibonacci
#include<bits/stdc++.h>
using namespace std;

long long Fib(int n)
{
	if(n<=1) return (long long)n;
	return Fib(n-1)+Fib(n-2);
}
void Fi(int n,long long &a,long long &b)
{
	if(n==1) {a=0;b=1;}
	else
	{
		Fi(n-1,a,b); 
		b=a+b; 
		a=b-a;
	}
}
typedef pair<long long,long long> PLL;
PLL Fibo(int n)
{
	if(n==1) return make_pair(0LL,1LL);
	PLL x=Fibo(n-1);
	return make_pair(x.second,x.first+x.second);	
}

int main()
{	
	//long long a,b;
	PLL p;
	for(int k=1;k<=51;k++) 
	{
		p=Fibo(k);
		cout<<p.first<<"\t";
	}
}

