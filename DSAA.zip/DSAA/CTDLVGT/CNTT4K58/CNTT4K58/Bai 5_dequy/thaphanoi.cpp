//Thap ha noi
#include<bits/stdc++.h>
using namespace std;

void THN(int n,char A,char B,char C)
{
	if(n==1) cout<<"\nChuyen dia "<<n<<" tu "<<A<<" sang "<<B;
	else
	{
		THN(n-1,A,C,B);
		cout<<"\nChuyen dia "<<n<<" tu "<<A<<" sang "<<B;
		THN(n-1,C,B,A);
	}
}

int main()
{
	THN(3,'A','B','C');
}

