//Luy thua
#include<bits/stdc++.h>
using namespace std;

template <class T>
T POW(T x,int n) //O(n)
{
	if(n==0) return 1;
	return POW(x,n-1)*x;
}

template <class T>
T Pow(T x,int n) //O(logn)
{
//	if(n==0) return 1;
//	if(n%2==0) return Pow(x*x,n/2);
//	return Pow(x*x,n/2)*x;
	return n?(n%2?Pow(x*x,n/2)*x:Pow(x*x,n/2)):1;
}

int my_pow(int x,int n) //O(logn)
{
	if(n==0) return 1;
	//int t=my_pow(x,n/2);
//	return n%2?t*t*x:t*t;
	return (n%2)?x*my_pow(x,n-1):my_pow(x*x,n/2);
}

int main()
{
	cout<<my_pow(2,6);
}

