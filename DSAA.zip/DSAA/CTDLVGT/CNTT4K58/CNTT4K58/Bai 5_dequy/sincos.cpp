//De quy tuong ho


#include<bits/stdc++.h>
using namespace std;
#define ss 0.0001
double Sin(double);  //prototype
double Cos(double);

double Sin(double x)
{
	if(fabs(x)<ss) return x;
	return 2*Sin(x/2)*Cos(x/2);
}

double Cos(double x)
{
	if(fabs(x)<ss) return 1;
	double u=Cos(x/2),v=Sin(x/2);
	return u*u-v*v;
}
int main()
{
	double x=3.14159263/4;
	cout<<"Sinx : "<<Sin(x)<<endl;
	cout<<"Cosx : "<<Cos(x)<<endl;
}

