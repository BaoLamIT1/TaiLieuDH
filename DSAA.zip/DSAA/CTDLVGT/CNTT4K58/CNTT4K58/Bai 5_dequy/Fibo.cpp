
#include<bits/stdc++.h>
using namespace std;

long long F[100];
long long Fib(int n)
{
	if(F[n]>=0) return F[n];
	if(n<=1) return F[n]=n;
	return F[n]=Fib(n-1)+Fib(n-2);
}

int main()
{
	for(int i=0;i<100;i++)F[i]=-1;
	for(int k=0;k<51;k++) 
	{
		cout<<Fib(k)<<"\t";
	}
}

