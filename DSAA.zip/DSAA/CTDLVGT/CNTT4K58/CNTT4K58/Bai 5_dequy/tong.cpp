//Cong cac phan tu mot mang
#include<bits/stdc++.h>
using namespace std;

int sum(int *a,int n) //Tong tu a1->an;
{
	if(n==0) return 0;
	return sum(a,n-1)+a[n];
}
void xuat(int *a,int n)
{
	if(n==0) return ;
	xuat(a,n-1);
	cout<<a[n]<<"\t";
}
void Dao(int *a,int L,int R)
{
	if(L>=R) return;
	Dao(a,L+1,R-1); swap(a[L],a[R]);
}
void Chen(int *a,int n) //chen an vao day day da sap a1,...an-1;
{
	if(n==1) return;
	if(a[n]>=a[n-1]) return;
	swap(a[n],a[n-1]);
	Chen(a,n-1);
}
void SapXep(int *a,int  n)
{
	if(n==1) return;
	SapXep(a,n-1);
	Chen(a,n);
}

int Tong(int *a,int L,int R)
{
	if(L==R) return a[L];
	int M=(L+R)/2; 
	return Tong(a,L,M)+Tong(a,M+1,R);
}
int main()
{
	int a[]={0,4,7,2,8,1,6,9,3,5},n=sizeof(a)/sizeof(int)-1;
	cout<<"\nDay a:\n"; xuat(a,n);
	cout<<"\nTong la "<<sum(a,n);   //21
	cout<<"\nTong la "<<Tong(a,1,n);   //21
	Dao(a,1,n);
	cout<<"\nDay a sau khi dao:\n"; xuat(a,n);
	SapXep(a,n);
	cout<<"\nDay a sau khi Sap xep:\n"; xuat(a,n);
	
}

