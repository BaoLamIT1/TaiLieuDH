//xau nhi phan khong chua 101
#include<bits/stdc++.h>
using namespace std;

int A(int n);
int B(int n);

int A(int n)
{
	if(n<=2) return n;
	return A(n-1)+B(n-1); 
}
int B(int n)
{
	if(n<=2) return n;
	return B(n-1)+A(n-2);
}
int main()
{
	int n=4;
	cout<<"So xau nhi phan can tim : "<<A(n)+B(n);
}

