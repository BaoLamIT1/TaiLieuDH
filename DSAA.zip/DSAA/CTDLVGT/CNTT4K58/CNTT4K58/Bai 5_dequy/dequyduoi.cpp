//De quy duoi khong su dung stack
#include<bits/stdc++.h>
using namespace std;

void gt(int n,int &kq)
{
	if(n==1) return;
	kq=kq*n;
	gt(n-1,kq);  //loi goi de quy o cuoi cung nen khong can stack
}


int main()
{
	int k=1;
	gt(10,k);
	cout<<k;
}

