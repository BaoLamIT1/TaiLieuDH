//Nhap toa do cac dinh tam giac tinh chu vi va dien tich
//huong chuc nang = huong thu tuc
#include<bits/stdc++.h>
#include<iomanip>
using namespace std;
struct diem {float x,y;};
struct tgiac {diem A,B,C;};
void nhap(tgiac &t)
{
	cout<<"Diem A :"; cin>>t.A.x>>t.A.y;
	cout<<"Diem B :"; cin>>t.B.x>>t.B.y;
	cout<<"Diem C :"; cin>>t.C.x>>t.C.y;
}
float dodai(diem A,diem B)
{
	return sqrt((A.x-B.x)*(A.x-B.x)+(A.y-B.y)*(A.y-B.y));
}
float chuvi(tgiac &t)
{
	return dodai(t.A,t.B)+dodai(t.B,t.C)+dodai(t.C,t.A);
}
float dinhthuc(diem A,diem B)
{
	return A.x*B.y-A.y*B.x;
}
float dientich(tgiac &t)
{
	float d=dinhthuc(t.A,t.B)+dinhthuc(t.B,t.C)+dinhthuc(t.C,t.A);
	return (d>0?d:-d)/2;
}
float Heron(tgiac &t)
{
	float a=dodai(t.B,t.C),b=dodai(t.C,t.A),c=dodai(t.A,t.B),p=(a+b+c)/2;
	return sqrt(p*(p-a)*(p-b)*(p-c));
}
int main()
{
	tgiac t;
	nhap(t);
	cout<<"\nChu vi  "<<chuvi(t);
	cout<<"\nDien tich  "<<dientich(t);	
	cout<<"\nDien tich theo Heron  "<<setw(10)<<Heron(t);	
}

