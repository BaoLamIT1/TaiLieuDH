//max
#include<bits/stdc++.h>
using namespace std;
template <class T>  //gia su co kieu du lieu T
T MAX(T a,T b){	return a>b?a:b;}
struct ps
{
	int t,m;
};
bool operator>(ps a,ps b)
{
	double x=a.t*1.0/a.m;
	double y=b.t*1.0/b.m;
	return x>y;
}
int main()
{
	ps a,b;
	a.t=-3;a.m=5;
	b.t=7;b.m=-9;
	ps c=MAX<ps>(a,b);
	cout<<"\nMax cho phan so "<<c.t<<"/"<<c.m<<endl;	
	cout<<"\nMax cho so nguyen "<<MAX<int>(3,5);
	cout<<"\nMax cho so thuc "<<MAX<double>(3.2,5.4);
}

