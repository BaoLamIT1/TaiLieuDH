//Lap trinh huong doi tuong
#include<bits/stdc++.h>
using namespace std;
class dathuc
{
	public: 
	int n;
	float *a;
	void nhap();
	void xuat();
	float giatri(float t);
	friend dathuc operator+(dathuc p,dathuc q);
};
void dathuc::nhap()
{
	cout<<"\nNhap Bac cua da thuc : "; cin>>n;
	a=new float [n+1];   		//chua noi den giai phong bo nho
	for(int i=0;i<=n;i++)
	{
		cout<<"He so thu : "<<i<<" : "; cin>>a[i];
	}
}
void dathuc::xuat()
{
	for(int i=0;i<=n;i++) cout<<a[i]<<"\t";
}
dathuc operator+(dathuc p,dathuc q)
{
	dathuc r;
	r.n = max(p.n,q.n);
	r.a=new float[r.n+1];
	for(int i=0;i<=r.n;i++)
	r.a[i]=i<=p.n&&i<=q.n?p.a[i]+q.a[i]: (i>p.n?q.a[i]:p.a[i]);
	return r;	
}
int main()
{
	dathuc p,q,r;
	p.nhap();q.nhap();
	r=p+q;
	cout<<"\nCac he so cua da thuc tong \n";	r.xuat();
}

