//lop hinh chu nhat
#include<bits/stdc++.h>
using namespace std;
class HCN
{
	//private:
		int dai,rong;
	public:
		void set(int a,int b)
		{
			dai=a;
			rong=b;
		}
		int area() {return dai*rong;}
};
int main()
{
	HCN h;
	h.set(4,5);  
	cout<<"Dien tich : "<<h.area();	
	HCN *k;//=&h;
	k=new HCN;
	k->set(6,5);  
	cout<<"\nDien tich : "<<k->area();	
}

