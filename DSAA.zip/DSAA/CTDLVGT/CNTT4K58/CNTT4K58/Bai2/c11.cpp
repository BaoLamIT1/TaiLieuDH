#include<bits/stdc++.h>
using namespace std;
int main()
{
	vector<int> a(10,0);
	stack<float> S;
	
	int k=10;
	for(auto &x:a) x=k++;
	//for(auto x:a) cout<<x<<"\t";
	for_each(a.begin(),a.end(),print);//[](int x){cout<<x<<"\t";});
	sort(a.begin(),a.end(),[](int x,int y){return x>y;});
	cout<<endl;
	for(auto x:a) cout<<x<<"\t";
}

