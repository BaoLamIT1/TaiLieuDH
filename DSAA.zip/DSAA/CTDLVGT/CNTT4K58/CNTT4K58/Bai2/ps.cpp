//nap chong toan tu
#include<bits/stdc++.h>
using namespace std;
struct ps
{
	int t,m;
};
//ps cong(ps a,ps b)
ps operator+(ps a,ps b)
{
	ps c;
	c.t=a.t*b.m+b.t*a.m;
	c.m=a.m*b.m;
	return c;	
};
int main()
{
	ps a,b,c;
	a.t=2; a.m=3;
	b.t=1; b.m=6;
	c=a+b;  //cong(a,b);
	cout<<"Tong la "<<c.t<<"/"<<c.m;
}


