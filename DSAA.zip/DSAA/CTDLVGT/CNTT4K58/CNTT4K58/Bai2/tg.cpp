//Tam giac huong doi tuong
#include<bits/stdc++.h>
using namespace std;
class diem 
{
	public:
	float x,y;
	void nhap() 
	{
		cout<<"Hoanh do : "; cin>>x;
		cout<<"Tung do  : "; cin>>y;
	}
};
struct tamgiac
{
	public:
	diem A,B,C;
	void nhap(){A.nhap();B.nhap();C.nhap();}
	float dodai(diem A,diem B)
	{
		float u=A.x-B.x,v=A.y-B.y;
		return sqrt(u*u+v*v);
	}
	float chuvi(){return dodai(A,B)+dodai(B,C)+dodai(C,A);}
	float dinhthuc(diem A,diem B) {return A.x*B.y-A.y*B.x;}
	float dientich()
	{
		return fabs(dinhthuc(A,B)+dinhthuc(B,C)+dinhthuc(C,A))/2;
	}
};
int main()
{
	tamgiac T;
	T.nhap();
	cout<<"\nChu vi "<<T.chuvi();
	cout<<"\nDien tich "<<T.dientich();
}

