//ma tran vuong
#include<bits/stdc++.h>
using namespace std;

class matran
{
	int n,**a;
	void nhap();  //nho phai cap phat bo nho dong
	void xuat();
	int max();    //tim gia tri lon nhat
	int tong();   //Tong cac phan tu cua ma tran
	bool ktratamgiactren(); 
	friend matran operator+(matran A,matran B);
	friend matran operator*(matran A,matran B);
};


int main()
{
	;
}

