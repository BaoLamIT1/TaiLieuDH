//Ham mau nhap xuat day
#include<bits/stdc++.h>
using namespace std;
template <class K>
K *nhap(int &n)   //Nhap day co n phan tu co cap phat bo nho va tra ve so phan tu duoc nhap
{
	cout<<"Nhap so phan tu : "; cin>>n;
	K *a= new K[n];
	for(int i=0;i<n;i++)
	{
		cout<<"Phan tu thu "<<i<<" : "; cin>>a[i];
	}
	return a;
}
template <class Z>
void xuat(int n,Z *a)
{
	for(int i=0;i<n;i++) cout<<a[i]<<"\t";	
}
int main()
{
	int n,*a,m;
	float *b;
	a=nhap<int>(n);
	b=nhap<float>(m);
	cout<<"\nMang a : \n"; xuat(n,a);
	cout<<"\nMang b : \n"; xuat(m,b);
	delete []a;delete []b;
}

