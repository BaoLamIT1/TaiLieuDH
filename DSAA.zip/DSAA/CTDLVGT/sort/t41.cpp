#include<bits/stdc++.h>
using namespace std;

int main()
{
	int n;
	cin>>n;
	int a[n+1];
	map<int,int> M;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		M[a[i]]=i;
	}
	sort(a+1,a+n+1);
	for(int i=1;i<=n;i++)
	cout<<M[a[i]]<<" ";
}
