#include<bits/stdc++.h>
using namespace std;
template<class T>
void merge_sort(T *a,T *b,T *c,int L,int R)
{
	if(L>=R) return;
	int M=(L+R)/2;
	merge_sort(a,b,c,L,M);
	merge_sort(a,b,c,M+1,R);
	int i,j,k;
	for(i=L;i<=M;i++)
	b[i]=a[i];
	for(i=M+1;i<=R;i++)
	c[i]=a[i];
	for(i=L,j=M+1,k=L;k<=R;k++)
	a[k]=i<=M&&j<=R?(b[i]<c[j]?b[i++]:c[j++]):(i>M?c[j++]:b[i++]);
}
int main()
{
	int a[]={4,7,2,8,1,6,3,9,5},n=sizeof(a)/sizeof(int);
	int b[n+6],c[n+5];
	cout<<"\nDay truoc khi sap: \n";
	for(auto x:a)
	cout<<x<<"\t";
	merge_sort<int>(a,b,c,0,n-1);
	cout<<"\nDay sau khi sap: \n";
	for(auto x:a)
	cout<<x<<"\t";
}

