#include<bits/stdc++.h>
using namespace std;
template<class T>
void ins_sort(T *A,int L,int R,bool cmp(T,T))
{
	for(int i=L+1;i<=R;i++)
	{
		T x=A[i];
		int j=i-1;
		while(j>=L&&cmp(x,A))	
	}	
}
int main()
{

}

