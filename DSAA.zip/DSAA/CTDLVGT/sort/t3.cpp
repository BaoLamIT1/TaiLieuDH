#include<bits/stdc++.h>
using namespace std;
typedef pair<int,int> pii;

void sort(pii *A,int n,bool cmp(pii,pii),int k)		//Sap da k diem cua n diem A1...An theo ham ss cmp
{
	for(int i=2;i<=k;i++)
	{
		int j=i-1;
		pii tem=A[i];
		while(j>=1&&cmp(tem,A[j])) 
		{
			A[j+1]=A[j];
			j--;
		}
		A[j+1]=tem;
	}
}
void nhap(pii *A,int &n)
{
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>A[i].first>>A[i].second;
}
void xuat(pii *A,int n)
{
	for(int i=1;i<=n;i++)
	cout<<"("<<A[i].first<<","<<A[i].second<<")" ;
}

int main()
{
	int n;
	pii A[100];
	nhap(A,n);
	sort(A,n,[](pii u,pii v) {return u.first<v.first;},n/2);
	xuat(A,n);
	cout<<endl;
	sort(A,n,[](pii u,pii v) {return u.second>v.second;},n/2);
	xuat(A,n);
		
}
