#include<bits/stdc++.h>
using namespace std;
template <class T> 
void bbs(T *a,int n,bool cmp(T,T))
{
	for(int i=0;i<=n-1;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			if(cmp(a[i],a[j])) swap(a[i],a[j]);
		}
	}
}
template<class T>
void sls(T *a,int n,bool cmp(T,T))
{
	int i,j,min;
	for(int i=0;i<n;i++)
	{
		min=i;
		for(int j=i+1;j<=n;j++)
		{
			if(cmp(a[min],a[j])) min=j;
		}
		if(min!=i) swap(a[min],a[i]);
	}
}
template<class T>
void its(T *a,int n,bool cmp(T,T))
{
	int i,j;
	T x;
	for(int i=1;i<=n;i++)
	{
		j=i-1;
		x=a[i];
		while(cmp(a[j],x)&&j>=0)
		{
			a[j+1]=a[j];
			j--;
		}
		a[j+1]=x;
	}
}
int main()
{
	int a[]={1,6,3,2,9,7,2};
	int n=sizeof(a)/sizeof(int);
	for(auto x:a) cout<<x<<"\t";
	bbs<int>(a,n-1,[](int u,int v)->bool{return u>v;});
	cout<<"\n";
	for(auto x:a) cout<<x<<"\t";
	cout<<"\n";
	sls<int>(a,n-1,[](int u,int v)->bool{return u<v;});
	for(auto x:a) cout<<x<<"\t";
	cout<<"\n";
	its<int>(a,n-1,[](int u,int v)->bool{return (u-v)%2==0?u<v:u%2<v%2;});
	for(auto x:a) cout<<x<<"\t";
}

