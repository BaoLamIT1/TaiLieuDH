#include<bits/stdc++.h>
using namespace std;
template<class T>
void vun(T *a,int L,int R,int k)
{
	if(L+2*(k-L)+1>R) return;
	int p=L+2*(k-L)+1;
	if(p+1<R && a[p]<a[p+1]) p++;
	if(a[k]>=a[p]) return;
	swap(a[k],a[p]);
	vun(a,L,R,p);
}
template<class T>
void heap_sort(T *a,int L,int R)
{
	for(int i=R;i>=L;i--) vun(a,L,R,i);	
	for(int i=R;i>=L;i--) 
	{
		swap(a[L],a[i]);
		vun(a,L,i-1,L);
	}
}
int main()
{
	int a[]={4,7,2,8,1,6,3,9,5},n=sizeof(a)/sizeof(int);
	cout<<"\nDay truoc khi sap: \n";
	for(auto x:a)
	cout<<x<<"\t";
	heap_sort<int>(a,0,n-1);
	cout<<"\nDay sau khi sap: \n";
	for(auto x:a)
	cout<<x<<"\t";
}

