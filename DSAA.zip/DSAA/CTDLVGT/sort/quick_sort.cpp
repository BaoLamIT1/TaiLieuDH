#include<bits/stdc++.h>
using namespace std;
template<class T>
void quick_sort(T *a,int L,int R,bool cmp(T,T))
{
	if(L>=R) return;
	int i=L;
	for(int j=L+1;j<=R;j++)
	if(cmp(a[j],a[L])) swap(a[++i],a[j]);
	swap(a[L],a[i]);
	quick_sort(a,L,i-1,cmp);
	quick_sort(a,i+1,R,cmp);
}
int main()
{
	int a[]={4,7,2,8,1,6,3,9,5},n=sizeof(a)/sizeof(int);
	cout<<"\nDay truoc khi sap: \n";
	for(auto x:a)
	cout<<x<<"\t";
	quick_sort<int>(a,0,n-1,[](int u,int v)->bool{return (u-v)%2==0?u<v:u%2<v%2;});
	cout<<"\nDay sau khi sap: \n";
	for(auto x:a)
	cout<<x<<"\t";
}

