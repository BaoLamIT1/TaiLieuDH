#include<bits/stdc++.h>
using namespace std;

int main()
{
 int i=1;
 cout<<i++;
 cout<<++i;
}

