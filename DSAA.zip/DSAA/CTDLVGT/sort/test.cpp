#include<bits/stdc++.h>
using namespace std;
template<class T>
void bubblesort(T *a,int n,bool cmp(T,T))
{
	for(int i=0;i<n-1;i++)
	{
		for(int j=i+1;j< n;j++)
		{
			if(cmp(a[i],a[j])) swap(a[i],a[j]);
		}
	}
}
template<class T>
void selectionsort(T *a,int n,bool cmp(T,T))
{
	int i,j,m;
	for(int i=0;i<n-1;i++)
	{
		m=i;
		for(int j=i+1;j<n;j++)
		{
			if(cmp(a[m],a[j])) m=j;
		}	
		if(m!=i)
		swap(a[i],a[m]);
	}	
}
template<class T>
void insertionsort(T *a,int n,bool cmp (T,T))
{
	T x;
	int i,j;
	for(int i=1;i<=n;i++)
	{
		j=i-1;
		x=a[i];
		while(cmp(a[j],x)&&j>=0)
		{
			a[j+1]=a[j];
			j--;
		}
		a[j+1]=x;
		
	}
}
int main()
{
	int a[]={4,7,2,8,1,6,3,9,5},n=sizeof(a)/sizeof(int);
	cout<<"\nDay truoc khi sap: \n";
	for(auto x:a)
	cout<<x<<"\t";
//	bubblesort<int>(a,n,[](int u,int v)->bool{return (u-v)%2==0?u<v:u%2<v%2;});
//	bubblesort<int>(a,n,[](int u,int v)->bool{return u>v?0:1;});
	selectionsort<int>(a,n,[](int u,int v)->bool{return u<v?0:1;});
//	insertionsort<int>(a,n,[](int u,int v)->bool{return u>v?0:1;});
	cout<<"\nDay sau khi sap: \n";
	for(auto x:a)
	cout<<x<<"\t";
}
