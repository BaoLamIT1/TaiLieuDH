#include<bits/stdc++.h>
using namespace std;
typedef pair<int,int> pii;
int main()
{
	int n;
	cin>>n;
	pii A[n];
	for(int i=0;i<n;i++)
	{
		cin>>A[i].first;
		A[i].second=i+1;
	}
	sort(A,A+n);
	for(int i=0;i<n;i++) cout<<A[i].second<<" ";
}
