//Bai 3 
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
class thisinh{
private:
	int sbd, namsinh, diemtoan, diemly, diemhoa;
	string gioitinh; 
	string name;
public:
	void nhap(){
		cout<<"Nhap ten: " ; cin>>name;
		cout<<"Nhap nam sinh: "; cin>>namsinh;
		cout<<"Nhap gioi tinh: "; cin>>gioitinh;
		cout<<"Nhap diem toan: ";cin>>diemtoan;
		cout<<"Nhap diem ly: ";cin>>diemly;
		cout<<"Nhap diem hoa: ";cin>>diemhoa;
	};
	void xuat(){
		cout<<"Ho ten: "<<name<<endl;
		cout<<"Nam sinh: "<<namsinh<<endl;
		cout<<"Gioi tinh: "<<gioitinh<<endl;
		cout<<"Tong diem la: "<<diemtoan+ diemly+diemhoa<<endl;		};
};
int main() {
	thisinh ts;
	ts.nhap();
	ts.xuat();
}
