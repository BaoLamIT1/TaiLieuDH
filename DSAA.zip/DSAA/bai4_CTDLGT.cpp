//Bai 4
#include<iostream>
#include<bits/stdc++.h>
    using namespace std;
class thoigian{
private: 
int  h,m,s;
public: 
    void nhap(){
	cout<<"Nhap du lieu: "<<endl;
	cout<<"Gio:";cin>>this->h;
    cout<<"Phut:";cin>>this->m;
    cout<<"Giay:";cin>>this->s;
}
        void display(){
	cout<<"Bay gio la:"<<this->h<<":"<<this->m<<":"<<this->s;
}
    void advance(){
	while(this->s>=60)
    {
      this->m+=1;
      this->s-=60;
    }
    while(this->m>=60)
    {
      this->h+=1;
      this->m-=60;
    }

    while(this->h>=24)  this->h-=24;
}
    void reset(){
   cout<<endl<<"Ban muon chinh lai thoi gian hien tai."<<endl;
   cout<<"Gio:";cin>>this->h;
   cout<<"Phut:";cin>>this->m;
   cout<<"Giay:";cin>>this->s;   
}
};
    int main(){
	thoigian tg ;
	tg.nhap();
	tg.display();
	tg.advance();
	tg.reset();
	cout<<"Thoi gian sau khi da chinh lai: "<<endl;
	tg.display();
}
