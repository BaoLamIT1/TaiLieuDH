//FILE Demo.cpp
/*
#include<bits/stdc++.h>
#include<conio.h>
#include"StuApp.cpp"

    using namespace std;

int main() {
VectorApp x;
x.run();
return 0;

}
*/