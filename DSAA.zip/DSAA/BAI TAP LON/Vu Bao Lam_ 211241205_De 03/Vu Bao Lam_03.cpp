#include<bits/stdc++.h>
#include<conio.h>
using namespace std;
// 1.	Cài đặt lớp Vector
//  BEGIN **********Class Vector**********
template<class T>
class Vector{
	int n,cap;
	T *buf;
	private:
		void recap(int k){
			if(k<=cap){
				return ;
			}
			T *p=buf;
			buf=new T[k];
			for(int i=0;i<n;i++){
				buf[i]=p[i];
			}
			cap=k;
			
			delete []p;
		}
	public:
		typedef T* iterator;
		
		Vector(){
			n=cap=0;
			buf=NULL;
		}
		
		Vector(int k,T x){
			n=cap=k;
			buf=new T[k];
			for(int i=0;i<n;i++){
				buf[i]=x;
			}
		}
		//Hàm huỷ
		~Vector(){
			if(buf) delete[]buf;
		}
		//Trả về kích thước của vector
		int size(){
			return n;
		}
		// Kiểm tra xem vector có rỗng hay không
		bool empty(){
			return n==0;
		}
		//Trả về phần tử đầu của vector
		T &front(){
			return buf[0];
		}
		//Trả về phần tử cuối của vector
		T &back(){
			return buf[n-1];
		}
		//Nạp chồng toán tử [] trả về phần tử theo vị trí truyền vào
		T &operator[](int index){
			return buf[index];
		}
		//Trả về phần tử theo vị trí được truyền vào
		T &at(int index){
			return buf[index];
		}
		//Thêm 1 phần tử vào cuối vector
		void push_back(T x){
			if(n==cap){
				recap(cap*2+1);
			}
			buf[n]=x;
			n++;
		}
		//Xoá phần tử cuối cùng của vector
		void pop_back(){
			n--;
		}
		//Trả về con trỏ đầu vào vector
		iterator begin(){
			return buf;
		}
		//Trả về con trỏ đầu cuối vào vector
		iterator end(){
			return  buf+n;
		}
		//Thêm 1 phần tử vào vị trí vất kì của vector
		void insert(T *index,T x){
			if(n==cap){
				recap(cap*2+1);	
			}
			for(T *p=buf+n;p>index;p--){
				*p=*(p-1);
			}
			*index=x;
			n++;
		}
		//Xoá 1 phần tử bất kì trong vector
		void erase(T *index){
		    for(T *i=index;i<end()-1;i++){
		    	*i=*(i+1);
			}
			n--;
		}
		
	    //Ham Quick sort
	    template<class CMP=less<T>>
        T *patrition(T *L,T *R,CMP ss=less<int>()){
	        T *pivot=R;  // khai báo phần tử đánh dấu pivot
	        T *l=L;      //khai báo biến bên trái 
	    	T *r=R-1;    //khai báo biến bên phải
	    	while(1){
		    	while(l<=r && ss(*pivot,*l))  // tìm phần tử >= phần tử pivot trong mảng
		    	{l++;}
		    	while(r>=l && ss(*r,*pivot)) // tìm phần tử <= phần tử pivot trong mảng
		    	{r--;}
		    	if(l>=r) 
		    	{break;}      // sau khi duyệt xong thì thoát khỏi vòng lặp
		    	swap(*l,*r);  // nếu chưa xong thì sử dụng hàm swap() để tráo đổi. 
		    	l++;
		    	r--;
	   		}
	    	swap(*l,*pivot);
	    	return l;
    	} 

    	template<class CMP=less<T>>
    	void QUICK_SORT(T *L,T *R,CMP ss=less<T>()){
	    	if(L<R){   // index là phần tử chia mảng làm 2 mảng con trái & phải 
		    	T *index=patrition(L,R,ss);    // Gọi đệ quy sắp xếp 2 mảng con trái và phải
		    	QUICK_SORT(L,index-1,ss);
		    	QUICK_SORT(index+1,R,ss);
	    	}
    	}
	
	// 2.	Bổ sung vào lớp Vector một phương thức sắp xếp theo thuật toán Heapsort, Phương thức sắp xếp thực hiện sắp xếp các phần tử theo một hàm so sánh là đối của hàm.
//Sap xep heap sort
template <class CMP>
void heapy(T *L, T *R, int k, CMP ss) 
{
	if(L+2*k+1>=R) return;
	int *p=L+2*k+1;     // xet con 1
	if(p+1<R && ss(*p,*(p+1))) p++; // neu con 2 lon hon chuyen p sang con 2
	if(ss(*(L+k),*p))
	{
		swap(*(L+k),*p);
	  	heapy(L,R,p-L,ss);
	}
}
template <class CMP = less<T> >
void heapsort(T *L, T *R, CMP ss= less<T>())
{
	for(T *i=R-1;i>=L;i--) heapy(L,R,i-L,ss);   // tao dong
	for(T *i=R-1;i>L;i--)
	{
		swap(*L,*i);
		heapy(L,i,0,ss);
	}
}
};
// END **********Class Vector**********  
//---------------------------------------------------------------------------- 
// **********class Student**********
class Student{
	string msv;
	string ngaysinh,hoten,gioitinh;
	public:
	//Getter and Setter
	//**hoten**
	string getHoten(){return hoten;}
	void setHoten(string ten){ hoten=ten;}
	//**MSV**
	string getMsv(){return msv;}
	void setMsv(string ma){msv=ma;}
	//**ngay sinh**
	string getNgaysinh(){return ngaysinh;}
	void setNgaysinh(string Dob){ngaysinh=Dob;}
	//**gioitinh**
	string getGioitinh(){return gioitinh;}
	void setGioitinh(string sex){ gioitinh=sex;}
	
	// Ham so sanh sinh vien
	static bool sosanhMsv(Student a, Student b){
		return a.getMsv()>b.getMsv();
	}
	static bool sosanhHoten(Student a, Student b)
	{
		return a.getHoten()>b.getHoten();
	}
	void nhapSv()
	{
	cout<<"\nNhap ma sinh vien: ";fflush(stdin);getline(cin,msv);
	cout<<"\nNhap ho ten: "; fflush(stdin);getline(cin,hoten);
	cout<<"\nNhap ngay sinh: ";fflush(stdin);getline(cin,ngaysinh);
	cout<<"\nNhap gioi tinh: ";fflush(stdin);getline(cin,gioitinh);
	}
};
// END **********class Student**********
//---------------------------------------------------------------------------- 
// 4.	Viết chương trình cho phép thực hiện các chức năng sau:
//Class VectorApp
class VectorApp{
	private:
		Vector<Student> v; 
	public:
		//App Operator
		void menu(); 
		void run();
		// App Functions
		void InsertElement();   // Nhap them 1 sinh vien moi
		void RemoveElement();   // Xoa 1 sinh vien theo ma sinh vien
		void ReplaceElement();  // Sua doi thong tin sinh vien
		void SortElement();     // Sap xep sinh vien
		void ListElement();     // Hien thi danh sach sinh vien
		void FindElement();    // Tim kiem sinh vien 
};
void VectorApp::menu()
{
	cout<<"* * * * * * * * * * * * * * * * * * * * * * *"<<endl;
	cout<<"*                                           *"<<endl;
	cout<<"* 1.Nhap them mot sinh vien moi             *"<<endl;
	cout<<"* 2.Xoa mot sinh vien theo ma sinh vien     *"<<endl;
	cout<<"* 3.Sua doi thong tin sinh vien             *"<<endl;
	cout<<"* 4.Sap xep sinh vien theo ho ten           *"<<endl;
	cout<<"* 5.Hien thi danh sach sinh vien            *"<<endl;
	cout<<"* 6.Tim kiem sinh vien theo ho ten          *"<<endl;
	cout<<"* 7.Thoat chuong trinh                      *"<<endl;
	cout<<"*                                           *"<<endl;
	cout<<"* * * * * * * * * * * * * * * * * * * * * * *"<<endl;	    
}
void VectorApp::run()
{
	menu();
	int pick; 	
	do{
         cout<<"\nNhap chuc nang : ";cin>> pick;
	    switch(pick)
	    {
	     	case 1: 
			InsertElement();
			break;
			case 2:
				RemoveElement();
				break;				
			case 3:
				ReplaceElement();
				break;
			case 4:
				SortElement();
				break;		
			case 5:
			     ListElement();
				break;
			case 6:
				FindElement();
				break;	
			case 7:
				cout<<"Cam on da su dung ung dung !";
				break;
			default:
				cout<<"Khong co chuc nang nay !"<<endl;
				
	} 
   getch();
}
while (pick !=7); 
}
//a.	Nhập thêm một danh sách sinh viên, sau khi hoàn thành nhập thông tin của một sinh viên, chương trình đưa ra câu hỏi có nhập nữa không (c/k)? 
//      Nếu người dùng nhập: c thì tiếp tục nhập, nhập k thì kết thúc.
void VectorApp::InsertElement()
{
	Student x;
    cout<<"Nhap sinh vien can them"<<endl;
			x.nhapSv();
			this ->v.push_back(x);
			char select;
			do {
				cout<<"\nNhap c de nhap thong tin sinh vien,nhap k de thoat qua trinh nhap: ";
				cin>>select;
  				switch (select)
 				{
  					case 'c':
					{
  						cout<<"\n Nhap thong tin sinh vien: \n";
  						x.nhapSv(); 
  						v.push_back(x);
  						break;
					}
					case 'k':
					{
						cout<<"\n ket thuc nhap! "<<endl;
						break;
					}
					default:
	  				 cout <<"\n ko hop le yeu cau nhap lai: ";	
  				}
			} while(select!='k');
	
}
//b.	Xóa đi một sinh viên theo mã sinh viên
void VectorApp::RemoveElement()
{
	if(v.size()==0){
	cout<<"Khong co sinh vien nao !"<<endl;}
	else 
	{
		string Masv;
		float kt=0;
		cout<<"Nhap ma sinh vien can xoa : ";fflush(stdin);getline(cin,Masv);
		for(int i=0;i<=v.size();i++)
		{
			if(v[i].getMsv()==Masv)
			{
				v.erase(v.begin()+i);
				kt++;
			}
		}
		if(kt!=0) cout<<"Xoa thanh cong"; else cout<<"Xoa ko thanh cong";
	}
	
}
//c.	Sửa đổi thông tin của một sinh viên bất kỳ trong danh sách
void VectorApp::ReplaceElement()
{
	string ma; 
	cout<<"\nNhap ma sinh vien can sua doi : "; cin>>ma;
	int kt=0;
	for(int i=0;i<=v.size();i++)
	{
		if(v[i].getMsv()==ma)
		{
			 string NewName, NewDob,NewSex;
			 cout<<"\nNhap ten moi: ";cin.ignore(1);getline(cin,NewName);
			 cout<<"\nNhap ngay sinh moi: ";cin.ignore(1);getline(cin,NewDob);
			 cout<<"\nNhap gioi tinh: ";cin.ignore(1);getline(cin,NewSex);
			 this->v[i].setHoten(NewName);
			 this->v[i].setNgaysinh(NewDob);
			 this->v[i].setGioitinh(NewSex);
			 kt++; break;
		}
	}
	if(kt==0) cout<<"\nKhong co sinh vien can sua!\n";
	else cout<<"Sua thanh cong!\n";
}

//d.	Sắp xếp danh sách sinh viên theo họ tên bằng thuật toán sắp xếp QuickSort
void VectorApp::SortElement()
{
	if(this->v.size()==0)
	{
		cout<<"\nKhong co sinh vien de sap xep!!!";
	}
	else{
		this->v.QUICK_SORT(this->v.begin(),this->v.end()-1,Student::sosanhHoten);
		cout<<"\nSap xep thanh cong!";
	}
}

// e.	Hiển thị toàn bộ danh sách sinh viên hiện có trong Vector 
void VectorApp::ListElement()
{
		if(this->v.size()==0)
		{
			cout<<"\nKhong co sinh vien de hien thi!!!"<<endl;
		}
		else 
		{
			for(int i=0;i<this->v.size();i++){
			cout<<" "<<this->v[i].getMsv()<<" "<<this->v[i].getHoten()<<" "<<this->v[i].getNgaysinh()<<" "<<this->v[i].getGioitinh()<<endl;
		}
	}
}

// f.	Tìm kiếm sinh viên theo họ tên 
void VectorApp::FindElement()
{
	int kt=0;
	string FindName;
	cout<<"\nNhap ten sinh vien can tim: ";cin>>FindName;
	for(int i=0;i<this->v.size();i++)
	{
		if(this->v[i].getHoten()==FindName)
		{
		cout<<"\nSinh vien co ton tai !!!"<<endl;
		//In ra so lieu sinh vien can tim
		cout<<this->v[i].getMsv()<<endl;
        cout<<this->v[i].getNgaysinh()<<endl;
		cout<<this->v[i].getGioitinh()<<endl;
			kt++;
		}
	}
	if(kt==0){
		cout<<"\nKhong co sinh vien !!!";
	}
}
int main()
{
	VectorApp p;
	p.run();	
}
