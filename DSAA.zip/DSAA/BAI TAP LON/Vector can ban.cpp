
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;

      

int main() { 
vector <int> v;
v.push_back(10);
v.push_back(20);
v.push_back(30);
cout<<v.size()<<endl; 
v.push_back(40);
cout<<v.size()<<endl;
cout<<"Phan tu dau tien: "<<v[0]<<endl;
cout<<"Phan tu cuoi cung: "<<v[v.size()-1]<<endl;
// hoac 
cout<<"Phan tu cuoi cung: "<<v.back()<<endl;
//DUyet bang index
for(int i=0;i<v.size();i++)
cout<<"Duyet bang index"<<v[i]<<endl;
//Duyet cac  phan tu trong vector
for(int x:v)
 cout<<"Duyet bang for each:"<<x<<endl;
//DUyet bang iterator 
 for(vector<int> ::iterator it= v.begin(); it != v.end();it++)
 cout<<"Duyet bang iterator: "<<*it<<endl;
 // hoac for(auto it =v.begin();it!=v.end();it++)
return 0;
}
