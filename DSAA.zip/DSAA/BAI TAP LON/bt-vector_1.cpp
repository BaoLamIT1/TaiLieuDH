#include<iostream>
using namespace std;
class Giaovien{
	int magv;
	char hoten[10],gioitinh[4],trinhdo[5],bomon[10];
	public :
		friend istream & operator >>(istream & is,Giaovien &gv)
		{
			cout<<"Nhap ma giao vien :";cin>>gv.magv;
			cout<<"Nhap ho ten :";cin.ignore(1);cin.get(gv.hoten,10);
			cout<<"Nhap gioi tinh :";cin.ignore(1);cin.get(gv.gioitinh,4);
			cout<<"Nhap bo mon :";cin.ignore(1);cin.get(gv.bomon,10);
			cout<<"Nhap trinh do :";cin.ignore(1);cin.get(gv.trinhdo,10);
			return is;
		}
		friend ostream & operator <<(ostream & os,const Giaovien & gv)
		{
			cout<<gv.magv<<"\t"<<gv.hotem<<"\t"<<gv.gioitinh<<"\t"<<gv.bomon<<"\t"<<gv.trinhdo;
			return os;
		}
		int getmagv()
		{
			return magv;
		}
};
#include<iostream>
#include<Vector.cpp>
#include<VectorItr.cpp>
#include<Giaovien.cpp>
class Quanly{
	Vector<Giaovien> v;
	public :
		void menu()
		{
			cout<<"1.Them 1 giao vien vao 1 vi tri bat ki \n";
			cout<<"2.Xoa 1 giao vien o 1 vi tri nao do \n";
			cout<<"3.Thay the giao vien o 1 vi tri nao do\n";
			cout<<"4.Them 1 giao vien vao cuoi danh sach \n";
			cout<<"5.Xoa giao vien co ma cho truoc \n";
			int n;
			cout<<"Nhap n :";cin>>n;
		}
		void run()
		{
			int ch;
			ch=menu();
			do{
				switch(ch)
				{
					case 1:
						insertElem_batky();
						break;
					case 2:
						removElem_batky();
						break;
					case 3:
						replaceElem();
						break;
					case 4:
						insertElem_cuoi();
						break;
					case 5:
						removElem_chotruoc();
						break;
					case 6:
						List();
						break;
				}
				getch();
			}
			while(ch != 7);
		}
		void insertElem_batky()
		{
			Giaovien x;
			int r;
			cout<<"Nhap vi tri chen :";cin>>r;
			cout<<"Nhap thong tin giao vien";
			cin>>x;
			if(v.insertAtRank(r,x)) cout<<"Them thanh cong";
			else cout<<"Them khong thanh cong";
		}
		void removElem_batky()
		{
			Giaovien x;
			int r;
			cout<<"Nhap vi tri xoa :";cin>>r;
			if(v.removeAtRank(r,x))
			cout<<"Xoa thanh cong "<<x;
			else cout<<"Xoa khong thanh cong "<<x;
		}
		void 	replaceElem()
		{
			Giaovien x;
			int r;
			cout<<"Nhap vi tri thay the :";cin>>r;
			cout<<"Nhap thong tin thay the ";cin>>x;
			if(v.replaceAtRank(r,x))
			cout<<"Thay the thanh cong ";
			else cout<<"Thay the khong thanh cong";
		}
		void insertElem_cuoi()
		{
			Giaovien x;
			cout<<"Nhap thong tin ";cin>>x;
			int r=v.size();
			if(v.insertAtRank(r,x))
			cout<<"Them vao cuoi thanh cong";
			else cout<<"Them vao cuoi khong thanh cong";
		}
		void 	removElem_chotruoc()
		{
			Giaovien x;
			int ma,t,kt=0;
			cout<<"Nhap ma :";cin>>ma;
			for(int i=1;i<=v.size();i++)
			{
				if(v.getAtRank(i,x))
				{
					t=i;
					if(x.getmagv()==ma) 
					{
						kt++;
							v.removeAtRank(t,x);
					}
				t=0;
				}
			}
			if(kt!=0) cout<<"Xoa thanh cong";else cout<<"Xoa khong thanh cong";
		}
		void List()
		{
			VectorItr<Giaovien>Itr(&v,v.size());
			cout<<"Danh sach ";
			while(Itr.hasNext())
			cout<<Itr.next()<<"\n";
		}
};
