#include<iostream>
//#include<vector.cpp>
using namespace std;
class Xemay{
	string bienkiemsoat,ho_ten,nhan_hieu;
	int nam_sx;
	public :
		friend istream & operator >>(istream & is,Xemay &xm)
		{
			cout<<"Nhap bien kiem soat :";cin.ignore(1);getline(cin,xm.bienkiemsoat);
			cout<<"Nhap ho ten :";cin.ignore(1);getline(cin,xm.ho_ten);
			cout<<"Nhap nhan hieu :";cin.ignore(1);getline(cin,xm.nhan_hieu);
			return is;
		}
		friend ostream & operator <<(ostream & os,const Xemay & xm)
		{
			cout<<xm.bienkiemsoat<<"\t"<<xm.ho_ten<<"\t"<<xm.nhan_hieu;
			return os;
		}
		string getbks()
		{
			return bienkiemsoat;
		}
};
template<class T>
class QLDS{
	int n;
	int N;
	T *V;
	public :
		int insertAtRank(int r, T o)
		  {  
		    if(r<0 || r > n )
				 return 0;   
		    if(n==N)
			{  //Phat trien mang
				T *A;
				N = 2*N;
				A = new T[N];
				for(int i=0;i<n;i++)
					A[i] = V[i];
				delete V;
				V = A;
			    int k = n-1;
		    	while(k>=r)
		    	{
		    	  V[k+1] = V[k];
		    	   k--;
		    	}
			 }
			 V[r]= o;
			 n++;
			 return 1;
		  } 
		int removeAtRank(int r, T &o)
		  {
				if(r<0 || r>n-1)
				  return 0;
				o = V[r];
				int k = r;
				while(k<n-1)
				{
					V[k] =  V[k+1];
					k++;
				}
				n--;
				return 1;
		  }
  int getAtRank(int r, T &o)
	  {
		  if(r<0 || r>n-1)
			 return 0;
		  o = V[r];
		  return 1;
	  }
};
int main()
{
	QLDS<Xemay> a;
	Xemay b;
	cin>>b;
	if(a.insertAtRank(8,b))
	cout<<a;
	Xemay c;
	cin>>c;
	if(a.removeAtRank(8,c)) cout<<"Da xoa thanh cong ";
	else cout<<"Xoa khong thanh cong ";
	if(a.getAtRank(8,c))
	cout<<c;
	
}
