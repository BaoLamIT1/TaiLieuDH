#include<bits/stdc++.h>
#include<conio.h>
using namespace std;

//Cai dat vector
template<class T>
class Vector{
	int n,cap;
	T *buf;
	private:
		void recap(int k){
			if(k<=cap){
				return ;
			}
			T *p=buf;
			buf=new T[k];
			for(int i=0;i<n;i++){
				buf[i]=p[i];
			}
			cap=k;
			
			delete []p;
		}
	public:
		typedef T* iterator;
		
		Vector(){
			n=cap=0;
			buf=NULL;
		}
		
		Vector(int k,T x){
			n=cap=k;
			buf=new T[k];
			for(int i=0;i<n;i++){
				buf[i]=x;
			}
		}
		
		~Vector(){
			if(buf) delete[]buf;
		}
		
		int size(){
			return n;
		}
		
		bool empty(){
			return n==0;
		}
		
		T &front(){
			return buf[0];
		}
		
		T &back(){
			return buf[n-1];
		}
		
		T &operator[](int index){
			return buf[index];
		}
		
		T &at(int index){
			return buf[index];
		}
		
		void push_back(T x){
			if(n==cap){
				recap(cap*2+1);
			}
			buf[n]=x;
			n++;
		}
		
		void pop_back(){
			n--;
		}
		
		iterator begin(){
			return buf;
		}
		
		iterator end(){
			return  buf+n;
		}
		
		void insert(T *index,T x){
			if(n==cap){
				recap(cap*2+1);	
			}
			for(T *p=buf+n;p>index;p--){
				*p=*(p-1);
			}
			*index=x;
			n++;
		}
		
		void erase(T *index){
		    for(T *i=index;i<end()-1;i++){
		    	*i=*(i+1);
			}
			n--;
		}
		
	    //Ham Quick sort
	    template<class CMP=less<T>>
        T *patrition(T *L,T *R,CMP ss=less<int>()){
	        T *pivot=R;
	        T *l=L;
	    	T *r=R-1;
	    	while(1){
		    	while(l<=r && ss(*pivot,*l)) 
		    	{l++;}
		    	while(r>=l && ss(*r,*pivot)) 
		    	{r--;}
		    	if(l>=r) 
		    	{break;}
		    	swap(*l,*r);
		    	l++;
		    	r--;
	   		}
	    	swap(*l,*pivot);
	    	return l;
    	} 

    	template<class CMP=less<T>>
    	void QUICK_SORT(T *L,T *R,CMP ss=less<T>()){
	    	if(L<R){
		    	T *index=patrition(L,R,ss);
		    	QUICK_SORT(L,index-1,ss);
		    	QUICK_SORT(index+1,R,ss);
	    	}
    	}
		
};

//Tao lop nhan vien
class KhachHang{
	int maKH;
	string HoTen;
	string SDT;
	public:
		void nhapKH();
		
		string getHoTen();
		void setHoTen(string ten);
		int getMaKH();
		void setMaKH(int ma);
		string getSDT();
		void setSDT(string sdt);
		
		//Cac ham so sanh khach hang
		static bool soSanhMaKH(KhachHang a,KhachHang b){
	           return a.getMaKH()>b.getMaKH();
        }
        
        static bool soSanhTen(KhachHang a,KhachHang b){
	           return a.getHoTen()>b.getHoTen();
        }
};

//Tao ung dung
class App{
	Vector<KhachHang> kh;
	private:
		//Phan khoi tao ung dung
		void start();
		void menu();
		void docDuLieu();
		//Cac chuc nang chinh cua ung dung
		void themKhachHang();
		void xoaKHTheoSDT();
		void suaKhachHang();
		void sxTheoMaKH();
		void sxTheoTenKH();
		void hienThiDSKH();
		void ghiVaoFile();
	
	public:	
	    //Thuc thi chuong trinh
	    void run(){
			this->start();
			this->menu();
			char cn;
			do
			{
			    cout<<"\n=>Nhap chuc nang ban muon :";cin>>cn;
			    switch(cn){
				    case '1':
					    this->themKhachHang();
					    break;
				    case '2':
						this->xoaKHTheoSDT();
						break;
					case '3':
						this->suaKhachHang();
						break;
					case '4':
						this->sxTheoMaKH();
						break;
					case '5':
						this->sxTheoTenKH();
						break;
					case '6':
						this->hienThiDSKH();
						break;
					case '7':
						this->ghiVaoFile();
						break;
					case '8':
						cout<<"Cam on ban da su dung ung dung!";
						break;
					default:
						cout<<"Khong co chuc nang nay!"<<endl;
				}
		    }while(cn!='8');
		}	
};


/*
HAM MAIN
*/
int main(){
   App a;
   a.run();
}


/*
TRIEN KHAI LOP KHACH HANG
*/
//Ham nhap khach hang
void KhachHang::nhapKH(){
	cout<<"Nhap ma khach hang :";cin>>this->maKH;
	fflush(stdin);
	cout<<"Nhap ten khach hang :";getline(cin,this->HoTen);
	fflush(stdin);
	cout<<"Nhap so dien thoai cua khach hang :";getline(cin,this->SDT);
}

//Cac getter,setter
string KhachHang::getHoTen(){
	return HoTen;
}
		
void KhachHang::setHoTen(string ten){
	HoTen=ten;
}
		
int KhachHang::getMaKH(){
	return maKH;
}
		
void KhachHang::setMaKH(int ma){
	maKH=ma;
}
		
string KhachHang::getSDT(){
	return SDT;
}
		
void KhachHang::setSDT(string sdt){
	SDT=sdt;
}


/*
XAY DUNG CAC CHUC NANG CHO CLASS APP
*/
//Bat dau chuong trinh
void App::start(){
	this->docDuLieu();
	cout<<"CHAO MUNG BAN DEN VOI UNG DUNG QUAN LI KHACH HANG!!!"<<endl;
	cout<<"Nhan nut bat ki de tiep tuc!"<<endl;
	getch();
	system("cls");
}

//Hien thi menu lua chon
void App::menu(){
	cout<<"* * * * * * * * * * * * * * * * * * * * * * * *"<<endl;
	cout<<"*                                             *"<<endl;
	cout<<"*           MENU QUAN LI KHACH HANG           *"<<endl;
	cout<<"*                                             *"<<endl;
	cout<<"* 1.Them khach hang                           *"<<endl;
	cout<<"* 2.Xoa khach hang theo so dien thoai         *"<<endl;
	cout<<"* 3.Sua so dien thoai ,ho ten cua khach hang  *"<<endl;
	cout<<"* 4.Sap xep khach hang theo ma khach hang     *"<<endl;
	cout<<"* 5.Sap xep khach hang theo ho ten            *"<<endl;
	cout<<"* 6.Hien thi danh sach khach hang             *"<<endl;
	cout<<"* 7.Ghi danh sach khach hang vao file         *"<<endl;
	cout<<"* 8.Thoat chuong trinh!                       *"<<endl;
	cout<<"*                                             *"<<endl;
	cout<<"* * * * * * * * * * * * * * * * * * * * * * * *"<<endl;
}

//Doc du lieu
void App::docDuLieu(){
	int n;
	int ma;
	char ten[30];
	char sdt[11];
	FILE *f;
	f=fopen("dataKhachHang.txt","r");
	if(f){
		fscanf(f,"%d\n",&n);
		for(int i=0;i<n;i++){
			fscanf(f,"%d\n",&ma);
			fscanf(f,"%[^\n]\n",ten);
			fscanf(f,"%[^\n]\n",sdt);
			KhachHang x;
			x.setMaKH(ma);
			x.setHoTen(string(ten));
			x.setSDT(string(sdt));
			this->kh.push_back(x);
		}
	}
	fclose(f);
}

//Chuc nang 1
void App::themKhachHang(){
   KhachHang x;
   cout<<"Nhap khach hang ban muon them"<<endl;
   x.nhapKH();
   this->kh.push_back(x);
   char out;
   do{
   	cout<<"Ban co muon them khach hang ko ?(Y/N)";
   	cin>>out;
   }while(out!='Y' &&out !='N' && out!='n' && out!='y');
   if(out=='y' || out=='Y'){this->themKhachHang();}
   else{return;}
}

//Chuc nang 2
void App::xoaKHTheoSDT(){
	
	if(this->kh.size()==0){
		cout<<"Khong co khach hang nao!"<<endl;
    }else{
    	string soDT;
	    cout<<endl<<"Nhap so dien thoai cua khach hang ma ban muon xoa :";fflush(stdin);getline(cin,soDT);
	    int dem=0;
	    for(int i=0;i<this->kh.size();i++){
	    	if(this->kh[i].getSDT()==soDT){
	    		this->kh.erase(this->kh.begin()+i);
	    		dem++;
	    		break;
			}
		}
		if(dem==0){
			cout<<"Khong co khach hang ma ban muon xoa!"<<endl;;
		}else{
			cout<<"Xoa thanh cong!"<<endl;
		}
	}
}

//Chuc nang 3
void App::suaKhachHang(){
	int ma;
	cout<<"\nNhap ma khach hang ban muon sua :";cin>>ma;
	int kt=0;
	for(int i=0;i<this->kh.size();i++){
	    if(this->kh[i].getMaKH()==ma){
	    	cout<<"Sua ten va so dien thoai cho "<<this->kh[i].getHoTen()<<":\n";
	    	string tenMoi;
	    	string sdtMoi;
	    	cout<<"Nhap ten moi :";fflush(stdin);getline(cin,tenMoi);
	    	cout<<"Nhap so dien thoai moi :";fflush(stdin);getline(cin,sdtMoi);
	    	this->kh[i].setHoTen(tenMoi);
	    	this->kh[i].setSDT(sdtMoi);
	    	kt++;
			break;	
		}
	}
	
	if(kt==0){
		cout<<"Khong co khach hang ma ban muon sua!\n";
	}else{
		cout<<"Sua thanh cong!\n";
	}
}

//Chuc nang 4
void App::sxTheoMaKH(){
	if(this->kh.size()==0){
		cout<<"\nKhong co khach hang de sap xep!";
	}else{
		KhachHang *L=this->kh.begin();
		KhachHang *R=this->kh.end()-1;
		this->kh.QUICK_SORT(L,R,KhachHang::soSanhMaKH);
		cout<<"Sap xep thanh cong!";
	}
}

//Chuc nang 5
void App::sxTheoTenKH(){
	if(this->kh.size()==0){
		cout<<"\nKhong co khach hang de sap xep!";
	}else{
		this->kh.QUICK_SORT(this->kh.begin(),this->kh.end()-1,KhachHang::soSanhTen);
		cout<<"Sap xep thanh cong!";
	}
}

//Chuc nang 6
void App::hienThiDSKH(){
	cout<<endl;
	if(this->kh.size()==0){
		cout<<"Khong co khach hang nao de hien thi!!!"<<endl;
	}else{
		cout<<"+----------+----------------------------+---------------+"<<endl;
	    cout<<"|MA KH     |TEN KHACH HANG              |SO DIEN THOAI  |"<<endl;
	    cout<<"+----------+----------------------------+---------------+"<<endl;
	    for(int i=0;i<this->kh.size();i++){
	    cout<<"|"<<left<<setw(10)<<this->kh[i].getMaKH()<<"|"<<left<<setw(28)<<this->kh[i].getHoTen()<<"|"<<left<<setw(15)<<this->kh[i].getSDT()<<"|"<<endl;
	    cout<<"+----------+----------------------------+---------------+"<<endl;
		}
	}
}

//Chuc nang 7
void App::ghiVaoFile(){
	if(this->kh.size()==0){
		cout<<"Khong co khach hang de ghi vao file!"<<endl;
	}else{
		ofstream ofs("dataKhachHang.txt");
	    ofs<<this->kh.size()<<endl;
	    for(int i=0;i<this->kh.size();i++){
		   ofs<<this->kh[i].getMaKH()<<endl;
		   ofs<<this->kh[i].getHoTen()<<endl;
		   ofs<<this->kh[i].getSDT()<<endl;
	    }
	    ofs.close();
		cout<<"Da ghi thanh cong danh sach khach hang vao file dataKhachHang.txt"<<endl;
	}
	
}
