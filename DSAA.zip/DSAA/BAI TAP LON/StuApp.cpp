// FILE StuApp.cpp
#include<iostream>
#include<bits/stdc++.h>
#include<conio.h>
#include"Student.cpp"
#include"VITR.cpp"
#include"Vector.cpp"
      using namespace std;
/*
class VectorApp{
	private:
		vector<double> v; // vector<Student> v;
	public:
		int menu();
		void run();
		void InsertElement();
		void RemoveElement();
		void ReplaceElement();
		void ListElement();
		void FindElement();
};
int VectorApp::menu()
{
	system("cls"); // clear screen
	cout<<"----------QUAN LY SINH VIEN----------";
	cout<<"\n1.Nhap them mot sinh vien moi";
	cout<<"\n2.Xoa mot sinh vien theo ma sinh vien";
	cout<<"\n3.Sua doi thong tin sinh vien";
	cout<<"\n4.Sap xep sinh vien theo ho ten";
	cout<<"\n5.Hien thi danh sach sinh vien";
	cout<<"\n6.Tim kiem sinh vien theo ho ten";
	cout<<"\n7.Thoat chuong trinh";
	cout<<"\n***********************************";
	int chon; 
	cout<<"\nChon chuc nang: ";cin>>chon;
		    if(0<=chon and chon<=9)
		    return chon;
			return menu();
}
void VectorApp::run()
{
	int pick;
	do{
		system("cls"); pick=menu();
		system("cls");
		switch(pick)
		{
			case 1: 
			InsertElement();
			break;
		/*	case 2:
				RemoveElement();
				break;
			case 3:
				ReplaceElement();
				break;
			case 4:
				GetElement();
				break;
			case 5:
				ListElement();
				break;
			case 6:
				FindElement();
				break;
			
		}
		getch();
	} 
}

//while (pick !=7); 
}
*/
//a.	Nhập thêm một danh sách sinh viên, sau khi hoàn thành nhập thông tin của một sinh viên, 
//      chương trình đưa ra câu hỏi có nhập nữa không (c/k)? 
//      Nếu người dùng nhập: c thì tiếp tục nhập, nhập k thì kết thúc.
/*void VectorApp::InsertElement()
{
	Student x;
	char select;
	cout<<"Nhap thong tin cua sinh vien can them"; cin>>x;
	cout<<"Co nhap them sinh vien nua khong ? (c/k)";cin>>select;
	if(select=='c')  cin>>x;
	else if(select=='k') system("cls");
}
//b.	Xóa đi một sinh viên theo mã sinh viên
/*void VectorApp::RemoveElement()  
{
	Student x; int n;
	float masv;
	cout<<"Nhap ma sinh vien can xoa bo: "; cin>>masv;
	for(int i=0;i<n;i++)
	if(strcmp)
}
*/
//
// e.	Hiển thị toàn bộ danh sách sinh viên hiện có trong Vector 
/*void VectorApp::ListElement()
{
	VectorItr <Student> Itr(&v,v.size());
	cout<<"Danh sach cac sinh vien:\n";
	while(Itr.hasNext())
	cout<<Itr.next()<<"\n";
}

*/

/*
int main() {
VectorApp x;
x.run();

return 0;

}

*/