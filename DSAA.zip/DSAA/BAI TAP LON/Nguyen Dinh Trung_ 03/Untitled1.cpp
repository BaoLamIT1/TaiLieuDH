#include<bits/stdc++.h>
using namespace std;
template<class T>
class vt_rite  //xay dung bo lap nguoc cho vector
{
	T*curr;
	public:
		vt_rite(T *c=NULL) {curr=c;}
		vt_rite<T> &operator=(vt_rite<T> it){this->curr=it.curr; return *this;}
		bool operator!=(vt_rite<T> it)	{return this->curr!=it.curr;}
		T &operator*(){return *curr;}
		vt_rite<T> operator++(int)  //it++
		{
			T* c=curr;
			curr=curr-1;
			return vt_rite<T>(c);
		}
		vt_rite<T> operator++()  //++it
		{
			curr=curr-1;
			return vt_rite<T>(curr);
		}
};
template<class T>
class Vector
{
	int n,cap;  //n-size, cap-capacity
	T *buf;     //luu cac phan tu
	private:
		void recap(int k)  //mo rong kha nang luu theo k
		{
			if(cap>=k) return;
			cap=k;
			T *tem=new T[cap];
			for(int i=0;i<n;i++) tem[i]=buf[i];
			if(buf) delete[]buf;
			buf=tem;
		}
	public:
		typedef T*iterator;
		iterator begin() {return buf;}
		iterator end() {return buf+n;}
		typedef vt_rite<T> reverse_iterator;
		reverse_iterator rbegin(){return buf+n-1;}
		reverse_iterator rend(){return buf-1;}
		Vector() {n=cap=0;buf=NULL;}
		Vector(int k,T x) //
		{
			n=cap=k;
			buf=new T[k];
			for(int i=0;i<k;i++) buf[i]=x;
		}
		Vector(Vector<T> &v)
		{
			if(v.n==0) {this->buf=0; this->n=this->cap=0;}
			else
			{
				this->cap=v.cap;
				this->n=v.n;
				this->buf=new T[v.cap];
				for(int i=0;i<v.n;i++) this->buf[i]=v.buf[i];
			}	
		}
		Vector<T> &operator=(Vector<T> &v)
		{
			if(v.n==0) {this->buf=0; this->n=this->cap=0;}
			else
			{
				this->buf=new T[v.cap];
				for(int i=0;i<v.n;i++) this->buf[i]=v.buf[i];
				this->n=v.n;
				this->cap=v.cap;
			}	
			return *this;
		}
		~Vector() {if(buf) delete[]buf;}
		int size() {return n;}
		bool empty(){return n==0;}
		T &front() {return buf[0];}
		T &back()  {return buf[n-1];}
		T &operator[](int i) {return buf[i];}
		T &at(int i) {return buf[i];}
		void pop_back() {n--;}
		void push_back(T x)
		{
			if(n==cap) recap(cap?cap*2:1);
			buf[n++]=x;
		}
		void resize(int k,T x)
		{
			if(n>=k) {n=k; return;}  //thu nho
			if(k>cap) recap(k);
			for(int i=n;i<k;i++) buf[i]=x;
			n=k;
		}
		void insert(iterator &it,T x)
		{
			if(n==cap) 
			{
				int k=it-buf;
				recap(cap?cap*2:1);
				it=buf+k;
			}
			for(iterator it1=buf+n-1;it1>=it;it1--) *(it1+1)=*it1;
			*it=x;
			n++;
		}
		void erase(iterator it)
		{
			for(iterator it1=it;it1<buf+n;it1++) *it1=*(it1+1);
			n--;
		}
		int *binary_search(int *L,int *R,int x)  //dung vong lap
        {
	     while(L+1<=R)
      	{    
		int *M=L+(R-L)/2;
		if(*M==x) return M;
		*M<x?L=M+1:R=M-1;
    	}
    	return NULL;
        } 
		void heapify(int a[],int n, int i)
        {
	    int l=2*i+1;
	    int r=2*i+2;
       	int largest=i;
    	if(l<n&&a[l]>a[largest]){
		largest=l;
    	}
    	if(r < n&&a[r]>a[largest])
    	{
		largest=r;
     	}
    	if(largest !=i)
    	{
		swap(a[i],a[largest]);
		heapify(a,n,largest);
    	}
        }  
};
class SinhVien{
	string msv,ngaysinh,hoten,gioitinh,lop;
	public: 
	   SinhVien(){
	   	msv="2112";
	   	ngaysinh="0/0/2002";
	   	hoten="A";
	   	gioitinh="nam";
	   	lop="CNTT1";
	   }
	   void nhap(){
	   	 cout <<"nhap ho va ten:  " ; cin >> hoten;
	   	 cout <<"nhap msv: ";cin>>msv;
	   	 cout<<"nhap ngay sinh: ";cin>>ngaysinh;
	   	 cout<<"nhap gioi tinh: ";cin>>gioitinh;
	   	 cout<<"nhap lop: ";cin>> lop;
	   }
	   void xuat(){cout <<hoten<<" "<< msv <<" "<<ngaysinh<<" "<<gioitinh<<" "<<lop<<endl;}
	   string getmsv(){return msv;}
	   string gethoten(){return hoten;}
	   string getgioitinh(){return gioitinh;}
	   string getlop(){return lop;}
	   string getngaysinh(){return ngaysinh;}
	   bool operator ==(const SinhVien& a){return hoten==a.hoten;}
};

class DanhSach
{
	private:
		vector<SinhVien> arrSinhVien;
	//	int sze;
	public:
		int sze = 0;
		void nhap()
		{
			SinhVien p; char x;
			p.nhap(); sze++;
			arrSinhVien.push_back(p);
			do {
				cout<<" \n Nhap c de nhap thong tin sinh vien,nhap k de thoat qua trinh nhap.";
				cin >> x;
  				switch (x)
 				{
  					case 'c':
					{
  						cout<<"\n Nhap thong tin sinh vien: \n";
  						p.nhap(); sze++;
  						arrSinhVien.push_back(p);
  						break;
					}
					case 'k':
					{
						cout<<"\n ket thuc nhap! "<<endl;
						break;
					}
					default:
	  				 cout <<"\n ko hop le yeu cau nhap lai: ";	
  				}
			} while(x!='k');
		}
		
		void xuat()
		{
			for(int i = 0;i<arrSinhVien.size();i++)
				arrSinhVien[i].xuat();
		}
		
		void xoasinhvientheomsv(const string & MSV)
		{
    		for(int i=0;i<arrSinhVien.size();i++){
                if(arrSinhVien[i].getmsv()==MSV)
                  arrSinhVien.erase(arrSinhVien.begin()+i);            
		}}
		
		void timkiemsinhvientheoht(const string & ten){
	 	int t=0; 
	 	 for(int i=1;i<=arrSinhVien.size();i++){
                if(arrSinhVien[i-1].gethoten()==ten){
                	 arrSinhVien[i-1].xuat();
                	 t=1;
				}
		if(t=0) cout << "khong tim thay  sinh vien nao ten "<<ten;		
	 }}
		void suadoithongtinsinhvien(string &ten1)
		{
			int found = 0;	 
    		for(int i=1;i<=arrSinhVien.size();i++){
        		if (arrSinhVien[i-1].gethoten()==ten1) {
        		found=1;
         	    arrSinhVien[i-1].nhap();       
        		}
   			}		
    		if (found == 0) cout << "khong co sinh vien nao ten "<<ten1;		
		}
		void quicksort( int L, int R)
		{

			if (L+1>=R) return;
			swap(arrSinhVien[L],arrSinhVien[L+(R-L)/2]);
			int i=L;
			for (int j=L+1;j<R;j++) 
			if (arrSinhVien[j].gethoten().front()<arrSinhVien[L].gethoten().front())
			swap(arrSinhVien[++i],arrSinhVien[j]);
			swap(arrSinhVien[L],arrSinhVien[i]);
			quicksort(L,i);
			quicksort(i+1,R);
		} 
};
int main()
{
	DanhSach a;
	a.nhap();
	a.xuat();
	string msv;
	cout<<"nhap ma sinh vien can xoa: ";cin.ignore(1);getline(cin,msv);
	a.xoasinhvientheomsv(msv); a.xuat();
	string ten;
	cout<<"nhap ten sinh vien can sua: ";getline(cin,ten);
	a.suadoithongtinsinhvien(ten);a.xuat();
	string ten1;
	cout<<"nhap ten sinh vien can tim: ";getline(cin,ten1);
	a.timkiemsinhvientheoht(ten1);
	a.xuat();
	a.quicksort(0,a.sze);
		a.xuat();
}
