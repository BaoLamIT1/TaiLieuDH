#ifndef STUDENT_CPP
#include<iostream>
#include<bits/stdc++.h>

using namespace std;

// 1.	Cài đặt lớp Vector
//  BEGIN **********Class Vector**********
template <class T>  
class Vector{
	private:
			int  N;        //maximum of dimensions
			T *V;     //save up data
			int n;          //number of elements
	public:
			Vector();
			~Vector();
			int getAtRank(int r, T &o);
			int replaceAtRank(int r, T o);
			int insertAtRank(int r, T o);
			int removeAtRank(int r, T &o);
			int size();
			int isEmpty();
};
template<class T>
  Vector<T>::Vector()
  {
	  V = new T[1];
	  N = 1;
	  n = 0;
  }
template<class T>
  Vector<T>::~Vector()
  {
	 delete V;
  }
  //Ham insertAtRank
template<class T>
  int Vector<T>::insertAtRank(int r, T o)
  {  
    if(r<0 || r > n )
		 return 0;   
    if(n==N)
	{  //Phat trien mang
		T *A;
		N = 2*N;
		A = new T[N];
		for(int i=0;i<n;i++)
			A[i] = V[i];
		delete V;
		V = A;
	    int k = n-1;
    	while(k>=r)
    	{
    	  V[k+1] = V[k];
    	   k--;
    	}
	 }
	 V[r]= o;
	 n++;
	 return 1;
  } 
  //Ham lay ra mot phan tu
template<class T>
  int Vector<T>::getAtRank(int r, T &o)
  {
	  if(r<0 || r>n-1)
		 return 0;
	  o = V[r];
	  return 1;
  }
  //Ham thay the mot phan tu
template<class T>
  int Vector<T>::replaceAtRank(int r, T o)
  {
		if(r<0 || r>n-1)
		  return 0;
		V[r] = o;
		return 1;
  }
template<class T>
  int Vector<T>::removeAtRank(int r, T &o)
  {
		if(r<0 || r>n-1)
		  return 0;
		o = V[r];
		int k = r;
		while(k<n-1)
		{
			V[k] =  V[k+1];
			k++;
		}
		n--;
		return 1;
  }
template<class T>
  int Vector<T>::size(){ return n;}
  template<class T>
  int Vector<T>::isEmpty()
  {
	  return n==0;		
  } 
  
// END **********Class Vector**********  
//---------------------------------------------------------------------------- 
// BEGIN **********Class VectorItr**********
      
template <class T>
class VectorItr{
	private :
		 Vector<T>* theVector;
		 int cur_Index;
	public:
		VectorItr(Vector<T>*V1)
		{
			theVector = V1;
			cur_Index = 0;
		}
		int hasNext(){
			if (cur_Index<theVector->size())
				 return 1;
			else
				return 0;
		 }
		T next(){
			T o;
			theVector->getAtRank(cur_Index, o);
			cur_Index++;
			return o;

		}
};
//**********End of class VectorItr**********
//----------------------------------------------------------------------------   
// 2.	Bổ sung vào lớp Vector một phương thức sắp xếp theo thuật toán Heapsort, Phương thức sắp xếp thực hiện sắp xếp các phần tử theo một hàm so sánh là đối của hàm.
//Sap xep heap sort
template<class T>
void Pushdown (T *A, int i, int n)
{
    int j = i; 
    int kt=0;
    int max;
    while (j<=n/2 && kt==0)
    {
       if(2*j==n)
           max = 2*j;
       else 
          if (A[2*j]<=A[2*j+1])
              max = 2*j+1;
          else  
			  max = 2*j;
       if (A[j]<A[max])  
       {
          Swap (A[j], A[max]);
          j = max;
       }
       else 
         kt=1;
     }
  }
  template<class T>
  void HeapSort(T *A, int n)
  {  
     int i;
     
     for(i=(n-1)/2; i>= 0;i--)
        Pushdown(A,i, n-1);
        
     for(i=n-1;i>=2;i--)
     {
        Swap(A[0],A[i]);
	     Pushdown(A,0,i-1);
     }
  } 

// 3.	Bổ sung vào lớp Vector phương thức tìm kiếm theo phương pháp tìm kiếm nhị phân trên mảng với hàm so sánh là một đối của phương thức tìm kiếm.

// **********class Student**********
class Student{
	private:
		float masv;
		string hoten, ngaysinh, gioitinh;
		public:
			friend istream &operator>>(istream &, Student&);
			friend ostream &operator<<(ostream&, const Student&);
			void XoaSV();
			float getMasv(){ return masv;
			}
			string getHoten(){return hoten;
			}
};
istream &operator>>(istream&Cin,Student&Stu)
{
	cout<<"\nNhap ma sinh vien: "; Cin>>Stu.masv;
	cout<<"\nNhap ho ten: "; Cin.ignore(1);getline(cin,Stu.hoten);
	cout<<"\nNhap ngay sinh: ";Cin.ignore(1);getline(cin,Stu.ngaysinh);
	cout<<"\nNhap gioi tinh: ";Cin.ignore(1);getline(cin,Stu.gioitinh);
	return Cin;
} 
ostream &operator<<(ostream&Cout,const Student&Stu)
{
	Cout<<Stu.masv<<"\t"<<Stu.hoten<<"\t"<<Stu.ngaysinh<<"\t"<<Stu.gioitinh;
	return Cout;
}   
// END **********class Student**********
//---------------------------------------------------------------------------- 
// 4.	Viết chương trình cho phép thực hiện các chức năng sau:
//Class Vector
class VectorApp{
	private:
		Vector<Student> v; // vector<Student> v;
	public:
		int menu();
		void run();
		void InsertElement();
		void RemoveElement();
		void ReplaceElement();
		void SortElement();
		void ListElement();
		void FindElement();
};
int VectorApp::menu()
{
	cout<<"\n1.Nhap them mot sinh vien moi";
	cout<<"\n2.Xoa mot sinh vien theo ma sinh vien";
	cout<<"\n3.Sua doi thong tin sinh vien";
	cout<<"\n4.Sap xep sinh vien theo ho ten";
	cout<<"\n5.Hien thi danh sach sinh vien";
	cout<<"\n6.Tim kiem sinh vien theo ho ten";
	cout<<"\n7.Thoat chuong trinh";
	cout<<"\n***********************************";
	int chon; 
	cout<<"\nChon chuc nang: ";cin>>chon;
		   
		    return chon;
	

}
void VectorApp::run()
{
	int pick; 	
	do{
		system("cls");
		pick=menu();
		system("cls");
	    switch(pick)
	    {
	
			case 1: 
			InsertElement();
			break;
			case 2:
				RemoveElement();
				break;				
			case 3:
				ReplaceElement();
				break;
			case 4:
				SortElement();
				break;		
			case 5:
			     ListElement();
				break;
			case 6:
				FindElement();
				break;	
	//getch();
		default:
		cout<<"\nKo hop le vui long nhap lai!";
		
	} 
}
while (pick !=7); 
}
//a.	Nhập thêm một danh sách sinh viên, sau khi hoàn thành nhập thông tin của một sinh viên, chương trình đưa ra câu hỏi có nhập nữa không (c/k)? 
//      Nếu người dùng nhập: c thì tiếp tục nhập, nhập k thì kết thúc.
void VectorApp::InsertElement()
{
	Student x;
	char select;
	cout<<"\nNhap thong tin cua sinh vien can them"; cin>>x;
	cout<<"Co nhap them sinh vien nua khong ? (c/k)";cin>>select;
	if(select=='c')  {
	cin>>x;}
	else system("cls");
	if(v.insertAtRank(select,x)) cout<<"Them thanh cong";
			else cout<<"Them khong thanh cong";
}

//b.	Xóa đi một sinh viên theo mã sinh viên
void VectorApp::RemoveElement()
{
	Student x;
    float id,t,kt=0;
    cout<<"\nNhap ma sinh vien can xoa: ";cin>>id;
    for(int i=1;i<=v.size();i++)
    {
    	if(v.getAtRank(i,x))
    	{
    		t=i;
    		if(x.getMasv()==id)
    		{
    			kt++;
    		    v.removeAtRank(t,x);
			}
			t=0;
		}
	}
	if(kt!=0) cout<<"Xoa thanh cong"; else cout<<"Xoa ko thanh cong";	
}

//c.	Sửa đổi thông tin của một sinh viên bất kỳ trong danh sách
void VectorApp::ReplaceElement()
{
	Student x;
	int r;
	cout<<"\nNhap vi tri sinh vien can sua doi: "; cin>>r;
	cout<<"***Nhap thong tin can sua doi***"; cin>>x;
	if(v.replaceAtRank(r,x))
		cout<<"/nSua doi thanh cong/n";
	else cout<<"/nSua doi khong thanh cong/n";
}

//d.	Sắp xếp danh sách sinh viên theo họ tên bằng thuật toán sắp xếp QuickSort
void VectorApp::SortElement()
{
	
}


//
// e.	Hiển thị toàn bộ danh sách sinh viên hiện có trong Vector 
void VectorApp::ListElement()
{
	VectorItr<Student> Itr(&v);
	cout<<"Danh sach cac sinh vien:\n";
	while(Itr.hasNext())
	  cout<<Itr.next()<<"\n";		
}


// f.	Tìm kiếm sinh viên theo họ tên 
void VectorApp::FindElement()
{
   	Student x;
   	
}  

int main() {
VectorApp x;
x.run();

return 0;

}
#endif