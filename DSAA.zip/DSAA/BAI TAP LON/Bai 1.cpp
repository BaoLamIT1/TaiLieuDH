// Bai 1: THUC HANH CAU TRUC VECTOR
/*Yêu cầu:
a. Xây dựng lớp vector, lớp bộ lặp của lớp vector
b. Sử dụng lớp vector và lớp bộ lặp của lớp vector xd chương trình quản lý danh sách các số thực có các chức năng sau:
1. Chèn 1 pt vào vector
2. xoá 1 phần tử của vector
3.Thay thế 1 phần tử của vector
4.Lấy giá trị của 1 phần tử của vector
5.In danh sách các pt hiện có trong vector
*/
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
class quanlysothuc{
	vector<double> V;
	string fname;
	ifstream fin;
	double x;
	public:
		int menu()
		{
			system("cls"); // clear screen xoa man hinh 
			cout<<"1.Them so thuc vao cuoi\n";
			cout<<"2.Sap xep\n";
			cout<<"3.Thay the tai vi tri k\n";
			cout<<"4.Dao day nguoc lai\n";
			cout<<"5.Xoa tai 1 vi tri\n";
			cout<<"6.Liet ke cac phan tu:\n";
			cout<<"7.Tim gia tri lon nhat\n";
			cout<<"8.Liet ke nhung vi tri co max\n";
			cout<<"9.Thoat";
			cout<<"\nMoi ban chon: ";
		    int chon; cin>>chon;
		    if(0<=chon and chon<=9)
		    return chon;
			return menu();
		}
		void run()
		{
			
			string fname;
			ifstream fin;
			double x;
			while(1)
			{
				switch(menu())
				{
                    case 0:
					cout<<"\nNhap ten file :"; cin.ignore(1);
					getline(cin,fname);
					fin.open(fname,ifstream::in); //C++11
					while(fin>>x) V.push_back(x);
					fin.close();
					break;
					case 8:
						cout<<"\nNoi dung vector: ";
						for(auto x:V) cout<<x<<" ";
						break;
						default:return ;			
			}
			system("pause");
		}
	}
};
      
int main() {
quanlysothuc Q;
int x=Q.menu();
cout<<x;
Q.run();

}
