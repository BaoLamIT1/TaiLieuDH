#include "app.cpp"
#include "stdio.h"

int main(){
	AppSingleList x;
	x.run();
	return 0;
}
