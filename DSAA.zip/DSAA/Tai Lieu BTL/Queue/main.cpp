#include"AppQueue.cpp"
int main()
{
	AppQueue q;
	q.run();
}
