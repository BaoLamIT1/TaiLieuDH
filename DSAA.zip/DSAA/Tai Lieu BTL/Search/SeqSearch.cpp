template<class T>
int SeqSearch(T *S, int n, T k){
    int found = 0;
    int i= 0;
    while(i<n && found==0){
         if(S[i]==k) 
           found = 1;
         i++;    
    }
    return found;
}
