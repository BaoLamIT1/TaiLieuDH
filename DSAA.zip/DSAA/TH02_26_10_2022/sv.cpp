#include<bits/stdc++.h>
      using namespace std;
struct sv{
	string ten; int tuoi,ma ; double diem;
	
};
istream &operator >>(istream &is, sv&S){
	is.ignore(1);
	getline(is,S.ten);
	is>>S.ma>>S.tuoi>>S.diem;
	return is;
}
ostream &operator <<(ostream& os, sv S)
{
	os<<setw(10)<<left<<S.ten<<" "<<setw(10)<<S.ma<<" "<<setw(5)<<S.tuoi<<" "<<S.diem;
	return os;
}
int main(){
	vector<sv> A;
	ifstream fin("sv.txt");
	int n;
	sv s;
	fin>>n;
	while(n--) {
		fin>>s; A.push_back(s);
	}
	fin.close();
	for(auto a:A) cout<<a<<"\n";
}
/*
int main() 
{
FILE *f=fopen("sv.txt","r");
int n;
vector<sv> C;
fscanf(f,"%d\n",&n);
for(int i=0;i<n;i++)
{
	char ten[30]; int tuoi;
	double diem;
	fscanf(f,"%[^0-9]",ten);
	fscanf(f,"%d%lf",&tuoi,&diem);
	sv s;
	s.ten=ten; s.ten.pop_back();
	s.tuoi=tuoi;
	s.diem=diem;
	C.push_back(s);
}
fclose(f);
for(auto v:C) cout<<v.ten<<" "<<v.tuoi<<" "<<v.diem<<"\n";
}
*/
