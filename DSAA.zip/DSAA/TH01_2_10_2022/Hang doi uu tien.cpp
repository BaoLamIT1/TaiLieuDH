//Hang doi uu tien
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;

      
int main() {
	//priority_queue<int>Q;
	//priority_queue<int,vector<int>> sap xep giam dan
priority_queue<int,vector<int>, greater<int>> Q;// them greater<int> de sap xep tang dan
for(int x:{523,263,346,52,76000}) Q.push(x);
while(Q.size())
{
	cout<<Q.top()<<" ";
	Q.pop();
}
}
