// Bai Nhom Ban
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
class Group
{
	int n,m, d[100005]={}, k=0, res=0;//mang d phan nhom
	vector<int> A[100005];
	public:
		void sol()
		{
			cin>>n>>m;
			for(int i=1;i<=m;i++)
			{
				int u,v;
				cin>>u>>v;
				A[u].push_back(v);
				A[v].push_back(u);
			}
			for(int i=1;i<=n;i++)
			if(d[i]==0)
			{
				k++;
				int z=DFS(i);
				if(res<z) res=z;
				
			}
			cout<<k<<"\n"<<res;
		}
		int DFS(int s) // tim ra nhom lien thong voi s tra ve so phan tu thuoc nhom do
		{
			int dem=1;
			stack<int> S;
			d[s]=k;
			S.push(s);
			while(S.size()){
			int u=S.top(); S.pop();
			for(int v:A[u])	
			if(d[v] ==0)
			{
				d[v]=k;
				dem++;
				S.push(v);
			}
			}
			return dem;
		}
};
      
int main()  {
	Group G;
	G.sol();

}
