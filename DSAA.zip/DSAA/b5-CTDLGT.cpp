#include<bits/stdc++.h>
#include<iostream>

using namespace std;

class Student{
  private:
  string name;
  int age;
  string gender;
  double gpa;
  public:
void nhap(){ 
 	cout<<"Nhap ten sinh vien: " ; cin>>name;
 	cout<<"Nhap tuoi sinh vien: "; cin>>age;
 	cout<<"Nhap gioi tinh sinh vien: "; cin>>gender;
 	cout<<"Nhap gpa sinh vien: "; cin>>gpa;
 }
void display(){
      cout <<"Ten: "<<name<<endl;
      cout<<"Tuoi: "<<age<<endl;
      cout<<"Gender: "<<gender<<endl;
      cout<<"GPA: "<<gpa<<endl;    
	  } 
};
int main() {	
Student stu1,stu2,stu3();
stu1.nhap();
stu1.display();
stu2.nhap();
stu2.display();
return 0;
}
