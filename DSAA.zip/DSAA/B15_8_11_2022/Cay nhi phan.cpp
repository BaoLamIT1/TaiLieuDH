// Cay nhi phan

// C++ Code to insert node and to print inorder traversal
// using iteration
#include <bits/stdc++.h>
using namespace std;

struct node
{
	int elem;
	node *left,*right,*next;
	node(int n) // ham tao duoc viet de quy -> tao ra ca cay luon
	{
		elem=n; 
		next=0;
		if(n%2 ||n<=4) left=right=0;
		else
		{
			left= new node(n/2-2);
			right=new node(n/2+2);
		}
 	}
};
void inorder(node *H,list<node*> &L)
{
	if(!H) return;
	inorder(H->left);
	//cout<<H->elem<<" ";
	L.push_back(H);
	if(L.size()==2)
	{
		L.front()->next=L.back();
		L.pop_front();
	}
	inorder(H->right);
}
class node_ite // bo lap xuoi
{
	node *curr;
	public:
		node *&getcur(){ return curr;}
		node_ite(node*c=NULL) { curr=c;} // ham tao
//		slist_ite<T>(slist_ite<T> &it)
//		{ 		
//		  cout<<"copy";
//		  this->curr=it.curr;
//		}
		node_ite &operator=(node_ite const &it) //toan tu gan
		{
			this->curr=it.curr;
			return *this;
		}
		bool operator!=(node_ite it) // so sanh ko bang
		{
			return curr!=it.curr;
		}
		int &operator*(){ return curr->elem;	} // toan tu lay gia tri *it
		node_ite operator ++()//++it
		{
			curr=curr->next;
			return curr;
		}
		node_ite operator++(int)//it++
		{
			node *p=curr;
			curr=curr->next;
			return p;
		}
};
class Group{
	node *root;
	public:
		void nhap()
		{
			int n;
			cin>>n;
			root=new node(n);
		}
		typedef node_ite iterator;
		iterator beign()
		{
			list <node*> L;
			inorder(root,L);
			node *p=root; while(p->left) p=p->left;
			return p;
			
		}
		iterator end() { return NULL;}
		
};
int main()
{
	Group G; G.nhap();
	for(auto x:G) cout<<x<<" ";
}