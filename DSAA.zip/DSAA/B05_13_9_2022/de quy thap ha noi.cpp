
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
    
 void thap ( int n , char A, char B, char C){
 	if(n>1)  thap(n-1,A,C,B);
 	cout<<"\nChuyen dia "<<n<<" tu " <<A <<" Sang "<<B;
 	if(n>1) thap(n-1,C,A,B);
 }
int main() {
  int n; 
  cin>>n; 
  thap (n,'A','B','C');
return 0;
}
