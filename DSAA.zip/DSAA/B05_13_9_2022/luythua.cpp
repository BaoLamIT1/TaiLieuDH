#include<math.h>
#include<stdio.h>
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
double pow(double x , int n)
      {
      	if(n==0) return 1;
      	return pow(x,n-1)*x;
	  }
double mypow(double x,int n)
{
	if(n==0) return 1;
	double t=mypow(x,n/2);
	return x%2?t*t*x:t*t;
}
double luythua(double x, int n)
{
	if(n==0) return 1;
	if(n%2==0) return ;luythua(x*x,n/2);
	return x*luythua(x*x,n/2);
}
int main() {
	cout<<pow(3,10);
	cout<<"\n"<<mypow(3,10);
	cout<<"\n"<<luythua(3,10);


}
