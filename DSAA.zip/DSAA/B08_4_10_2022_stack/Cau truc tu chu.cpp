//Cat dat stack bang danh sach lien ket
// Cau truc tu tro
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;

    struct Human{
    	string ten;
    	int tuoi;
    	struct Human *bo , *me;
    	Human(string t="vo danh", int tt=18)
    	{
    		ten=t;
    		tuoi=tt;
    		bo=me=NULL;
		}
	};  
int main() {
Human X("Chi pheo",15), Y("Thi no"), *Z=new Human("Ba Kien",25);
cout<<"\nX:"<<X.ten<<" "<<X.tuoi;
cout<<"\nY:"<<Y.ten<<" "<<X.tuoi;
cout<<"\nZ:"<<Z->ten<<" "<<(*Z).tuoi;
cout<<"\nBo cua Z: "<<Z->bo->ten;
delete Z;
}
