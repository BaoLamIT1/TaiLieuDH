
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;

      
int main() {
queue<int> Q;
for(int x:{4,7,2,8,1,6})
Q.push(x);
Q.front()=5;
Q.back()=9;
while(not Q.empty())
{
	cout<<Q.front()<<" ";
	Q.pop();
}

}
