//tap tam giac
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;

      
int main() {
queue<int> Q;
int n , res=0;
cin>>n;
int a[n];
for(auto &x:a) cin>>x; //cin a[0] .. a[n-1]
sort(a,a+n,greater<int>()); //sapxep giam dan
for(int x:a)
{
	while(Q.size()&& x+Q.back() <= Q.front())
	Q.pop();
	Q.push(x);
	if(res<Q.size())
	res=Q.size();
}
cout<<res;
}
// tim hieu bai bup be nga , canh cua than ki , DFS.