 // moi con duong ve 0
#include<bits/stdc++.h>
using namespace std;
struct node {
	int elem;
	vector <node*> child ;
	node( int n) // de quy 
	{
		elem =n;
		for( int a=1;a*a<=n;a++)
		
			if (n%a==0) child.push_back( new node((a-1)* (n/a+1)));
		
	}};
	void preoder(node * H){
		if ( !H ) return ; //H=Nulll;
		cout<< H->elem <<" ";
		for( auto h:H->child ) preoder(h);
	}
	void postoder(node * H){
		if ( !H ) return ; //H=Nulll;
		
		for( auto h:H->child ) postoder(h);
		cout<< H->elem <<" ";
	}
		void inoder(node * H){
		if ( !H ) return ; //H=Nulll;
		if (H->child.size()) inoder(H->child[0] );
		cout<< H->elem <<" ";
		for( int i=1;i<H->child.size();i++ ) inoder(H->child[i]);
	}

int main(){
	int s;
	cin>>s;
	node* root= new node(s);
	
//	cout<<root->elem<< "\n ";
//	cout<<root->child[2]->child[2]->child[2]->child[1]->elem<<endl;
//	cout<<"\n"; preoder(root);
//	cout<<"\n"; inoder(root); 
	cout<<"\n"; postoder(root);
 

	



	return 0;
}

