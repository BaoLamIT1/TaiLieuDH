//Cai dat hang doi bang danh sach lien ket
#include<iostream>
#include<bits/stdc++.h>
using namespace std;
//#ifndef __queue__cpp__
//#define __queue_cpp__
template<class T>
      struct node{
      	T elem;
      	node *next;
      	node(T x){
      		elem=x; 
			next=NULL;
		  }
	  };
template<class T>
class Queue{
	node<T> *Head, *Trail;
	int n;
	public:
		Queue() {
			Head=Trail=NULL;
			n=0;
		}
		~Queue()
		{
		  while(Head=NULL)
		  {
		  	node<T>*p=Head;
		  	Head=Head->next;
		  	delete p;
		  }
		}
		int size(){return n;}
		bool empty(){return n==0;}
	    T &front(){ return Head -> elem;}
		T &back() { return Trail -> elem;}
		void push(T x)
		{
			/*
			if(n>0)
			{
			node<T> *p=new node<T>(x);
			Trail ->next =p;
			Trail=p;
		    }
		    else 
		    {
		    	Head=new node<T>(x);
		    	Trail=Head;
			}
			*/
			if(n==0) Head=Trail=new node<T>(x);
			else
				Trail =Trail ->next= new node<T>(x);
				n++;	
		}
		void pop()
		{
			node<T>*p=Head; Head=Head->next;
			delete p;
			n--;
		}
		
};
      
int main() {
     Queue<int> Q;
     for(int x:{45,514,65,25,65,97,45})
    Q.push(x);
    Q.front()=100;
    Q.back()=20;
    while(Q.size())
    {
    	cout<<Q.front()<<" ";
    	Q.pop();
	}
}
    

