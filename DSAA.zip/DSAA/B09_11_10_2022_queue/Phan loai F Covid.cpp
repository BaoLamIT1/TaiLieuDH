// Thuat toan BFS Phân loại các F để cách ly Covid-19
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
int main()
{
	int n,m,q,x,u,v;
	cin>>n>>m;
	vector<int> A[n+5]; // Mang cac vector
	while(m--)
	{
		cin>>u>>v;
		A[u].push_back(v);
	}
	int d[n]
	}
}