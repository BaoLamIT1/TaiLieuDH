//Búp bê Nga
#include<bits/stdc++.h>
      using namespace std;

      
int main() {
int n,k;
cin>>n>>k;
int a[n];
for(int &x:a) cin>>x; //Nhap a[0]....a[n-1]
sort(a,a+n,greater<int>()); //sap xep giam dan
queue<int> Q;
int res=0;
for(auto x:a)
{
	Q.push(x);
	if(Q.front()>=x+k) Q.pop();
	else res+=x;
}
cout<<Q.size()<<" "<<res;
}
