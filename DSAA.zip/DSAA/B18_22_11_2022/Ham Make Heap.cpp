// Demo ham Make Heap
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;

      
int main() {
 int a[]={53,65,8,65,435,95,67,423,71,93,16,74};
 int n=sizeof(a)/sizeof(a[0]);
 make_heap(a,a+n);
 for(auto x:a) cout<<x<<" ";

}
