// Tim kiem nhi phan tren mang
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;

      
int main() {
int a[]={5,8,13,16,16,16,18,18,22,45,38,41}; // day da sap tang
int n=sizeof(a)/sizeof(a[0]);
int x;
cout<<"x= ";cin>>x;

int *p=lower_bound(a,a+n,x);
int *q=upper_bound(a,a+n,x);
if(p==a+n) cout<<"Khong co";
else
{
	cout<<"\nVi tri dau tien >=x la " <<p-a;
	cout<<"\nVi tri dau tien <x la "<<q-a;
}

}
