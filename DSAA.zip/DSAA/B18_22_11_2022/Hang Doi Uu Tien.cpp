// Hang Doi Uu Tien
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
template< class T, class CMP=less <T>>
class PQ
{
	T *a;
	int cap,n;
	CMP ss;
	private:
		void heapy(int *a, int n, int k)  // vun tai vi tri k trong day a tu a[0]...a[n-1]
{
	if(2*k+1>=n) return;
	int p=2*k+1;     // xet con 1
	if(p+1<n && ss(a[p],a[p+1])) p++; // neu con 2 lon hon chuyen p sang con 2
	if(ss(a[k],a[p])){
		swap(a[k],a[p]);
	  	heapy(a,n,p);}
}
    public:
    	PQ(){//buf=0, cap=n=0;
    	a=0;cap=n=0;
		}
		~PQ(){if(a) delete a;}
		int size(){ return n;}
		bool empty(){ return n==0;}
		T top(){ return a[0];}
		void push(T x)
		{
			if(n==cap)
			{
				cap=cap*2+1;
				T*tem=a;
				//buf=new T[cap];
				a=new T[cap];
				//for(int i=0;i<n;i++) buf[i]=tem[i];
				for(int i=0;i<n;i++) a[i]=tem[i];
				if(!tem) delete tem;
			}
			//buf[n++]=x;
			a[n++] =x;
			int k=n-1;
			while(k>0 && ss(a[(k-1)/2],a[k])) {
				swap(a[(k-1)/2],a[k]);
				k=(k-1)/2;
			}
		}
		void pop(){a[0]=a[--n]; heapy(a,n,0);	}
};
      
int main() {
 PQ<int,greater<int>> Q; // Sx be-> lon
  //PQ<int> Q; // SX lon -> be;
  for(auto x:{53,65,8,65,435,95,67,423,71,93,16,74}) Q.push(x);
  while (Q.size())
{
	cout<<Q.top()<<" ";
	Q.pop();
}
return 0;
}
