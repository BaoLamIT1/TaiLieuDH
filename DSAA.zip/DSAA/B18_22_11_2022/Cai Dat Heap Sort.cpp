// Cai dat Heap Sort
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
      /*   
	  //VERSION 1
void heapy(int *a, int n, int k)  // vun tai vi tri k trong day a tu a[0]...a[n-1]
{
	if(2*k+1>=n) return;
	int p=2*k+1;     // xet con 1
	if(p+1<n && a[p]<a[p+1]) p++; // neu con 2 lon hon chuyen p sang con 2
	if(a[k]<a[p])
	{
		swap(a[k],a[p]);
	  	heapy(a,n,p);
	}
}
void heapsort(int *a, int n)
{
	for(int i=n-1;i>=0;i--) heapy(a,n,i);   // tao dong
	for(int i=n-1;i>0;i--)
	{
		swap(a[0],a[i]);
		heapy(a,i,0);
	}
} 
int main() {
     int a[]={53,65,8,65,435,95,67,423,71,93,16,74};
 int n=sizeof(a)/sizeof(a[0]);
 heapsort(a,n);
 for(auto x:a) cout<<x<<" ";

}
*/
// VERSION 2: Con tro hoa
/*
void heapy(int *L, int *R, int k)  // Vun tai vi tri k trong day doan con tro L den R-1
{
	if(L+2*k+1>=R) return;
	int *p=L+2*k+1;     // xet con 1
	if(p+1<R && *p<*(p+1)) p++; // neu con 2 lon hon chuyen p sang con 2
	if(*(L+k)<*p)
	{
		swap(*(L+k),*p);
	  	heapy(L,R,p-L);
	}
}
void heapsort(int *L, int *R)
{
	for(int *i=R-1;i>=L;i--) heapy(L,R,i-L);   // tao dong
	for(int *i=R-1;i>L;i--)
	{
		swap(*L,*i);
		heapy(L,i,0);
	}
} 
int main() {
 int a[]={53,65,8,65,435,95,67,423,71,93,16,74};
 int n=sizeof(a)/sizeof(a[0]);
 heapsort(a,a+n);
 for(auto x:a) cout<<x<<" ";

}
*/
// VERSION 3
template <class T, class CMP>
void heapy(T *L, T *R, int k, CMP ss) 
{
	if(L+2*k+1>=R) return;
	int *p=L+2*k+1;     // xet con 1
	if(p+1<R && ss(*p,*(p+1))) p++; // neu con 2 lon hon chuyen p sang con 2
	if(ss(*(L+k),*p))
	{
		swap(*(L+k),*p);
	  	heapy(L,R,p-L,ss);
	}
}
template < class T, class CMP = less<T> >
void heapsort(T *L, T *R, CMP ss= less<T>())
{
	for(T *i=R-1;i>=L;i--) heapy(L,R,i-L,ss);   // tao dong
	for(T *i=R-1;i>L;i--)
	{
		swap(*L,*i);
		heapy(L,i,0,ss);
	}
}
int main()
{
 int a[]={53,65,8,65,435,95,67,423,71,93,16,74};
 int n=sizeof(a)/sizeof(a[0]);
 heapsort(a,a+n,greater<int>());
 for(auto x:a) cout<<x<<" ";	
}