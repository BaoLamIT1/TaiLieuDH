// Day con don dieu tang dai nhat
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;

      
int main() {
   int n,x;
   cin>>n;
   vector<int> b;
   while(n--)
   {
   	cin>>x;
   	if(b.size()==0 or b.back()<x) b.push_back(x);
   	else
   	{
   		auto p=lower_bound(b.begin(),b.end(),x);
   		*p=x;
	   }
   }
   cout<<b.size();
//run 
//12
//4 7 2 8 3 6 1 8 4 9 3 6
}
