// B?ng bam
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
template <class T>
class HT // unordered_Set va unordered_map
{
	int M=12347; // so ngan cua mang
	int n;
	list<T> L[M];
	int hashfunction(T x)
	{
		hash<T> M;
		return H(x)%M;
	}
	public:
		HT(){n=0;}
		int size(){return n;}
		int empty(){return n=0;}
		void insert(T x)
		{
			int k=hashfunction(x);
			L[k].push_back(x);
			n++;
		}
		bool find(T x)
		{
			int k=hashfunction(x);
			for(auto it=L[k].beign();it!=L[k])
		}
		void erase(T x)
		{
			int k=hashfunction(x);
			auto it=L[k].begin();
			
		}
int main() {


}
