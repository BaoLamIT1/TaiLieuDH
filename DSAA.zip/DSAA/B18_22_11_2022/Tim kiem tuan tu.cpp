
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
/*
int *search(int *L, int *R,int x)
{
	for(int *p=L;p<R;p++) if(*p==x) return p;
	return NULL;
}
 */
 template <class T>
 T *search(T *L,T *R, T x)
 {
 	for(T *p;p<R;p++) if(*p==x) return p;
 	return NULL;
	 }    
int main() {
int a[]={235,36,46,72,735,6346,37}; n=7;
int *p=search(a,a+n,72);
if(!p) cout<<"Khong co";
else cout<<"co tai vi tri "<<p-a;
}
