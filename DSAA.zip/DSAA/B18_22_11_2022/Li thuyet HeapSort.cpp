/*
Sắp xếp vận động Heap Sort
a>  Heap( đống)
 Heap là cây nhị phân đc đ/n đệ quy 
 +> Cây rỗng hoặc 1 phần tử là heap
 +> Cây nhị phân >> gốc >= với mọi pt trong cây
                 >> Cây trái & phải đều là heap
     Minh hoạ:
                   87
              65         56
          42    57     50    32
        17 35 26 47  34 25
        // hàm có sẵn: make_heap

b>  Bd Heap bằng mảng
       0  1  2  3  4  5  6  7  8  9  10 11 12
      |87|65|56|42|57|50|32|17|35|26|47|34|25|
      
      a[k] >> a[2k+1]
           >> a[2k+2]
c>  Tạo đống 

      * Vun đống tại vị trí k   >> K có con hoặc các con <= a[k] thì xong
	                            >> Ngược lại > B1: Đổi chỗ con với a[k]
								             > B2: Vun đống từ vị trí con vừa rồi 
d>  SX
    B1: Tạo đống: Duyệt tất cả vị trí từ cuối về đầu và vun đống
    B2: SX  
    * Duyệt từ cuối về đầu, i chạy k-1 ->1   >> Đổi chỗ a[0] và a[i]
                                             >> Vun lại tại a[0] sau khi cắt a[i] đi
    ** Minh Hoạ:
    
    Iu:      36 63 72 27 49 53 25 14 36 42 75 44 24
    B1:      75 63 72 36 49 53 25 14 27 42 36 44 24
    B2: SX   
e>  Đánh giá độ phức tạp
 * Vun đống có độ phức tạp: O(log(n))
 * Tạo đống n bước: O(n log(n))
 * Sắp xếp: O(n log(n))
 ==> T(n)= O(n log(n))
                      
                         