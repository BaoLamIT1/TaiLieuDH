// Chua xong
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
/*
int *binary_search(int *L, int *R, int x)  // dung vong lap
{
	while(L+1<R)
	{
		int *M=L+(R-L)/2;
		if(*M==x) return M;
		*M<x?L=M+1:R=M-1;
	}
	return NULL;
}
      
int main() {
int a[]={5,8,13,16,16,16,18,18,22,45,58,61}; // day da sap tang
int n=sizeof(a)/sizeof(a[0]);
int x; cin>>x;
int *p=binary_search(a,a+n,x);
if(!p) cout<<"Khong co";
else cout<<"co tai vi tri "<<p-a;

}
*/
// VERSION 2 de quy
template <class T>
T *binary_search(T *L, T *R, T x)
{
	while(L+1<R)
	{
		int *M=L+(R-L)/2;
		if(*M==x) return M;
		*M<x?L=M+1:R=M-1;
	}
	return NULL;
}
template < class T>
int *bs(int *L, int *R ,int x) // dung de quy
{
	if(L+1>=R) return NULL;
	int *M=L+(R-L)/2;
	if(*M==x) return M;
	if(*M<x) return bs(M+1,R,x);
	return bs(L,M-1,x);
}
int main() {
int a[]={5,8,13,16,16,16,18,18,22,45,58,61}; // day da sap tang
int n=sizeof(a)/sizeof(a[0]);
int x; cin>>x;
int *p=binary_search(a,a+n,x);
if(!p) cout<<"Khong co";
else cout<<"co tai vi tri "<<p-a;

}