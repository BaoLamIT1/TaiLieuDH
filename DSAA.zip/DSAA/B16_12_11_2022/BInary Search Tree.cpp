//Cay BST- Cay tim kiem nhi phan( moi node toi da 2)
// cai dat cay -> duyet cay -> Độ sâu 
// cho a1... an voi moi ai tim phan tu nhon hon lon nhat dung truoc
//cat dat set
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
struct node{
	int elem;
	node *left,*right;
	node(int e){ elem=e;left=right=0;
	}// tao 1 node
};
void update(node *&H, int x)
{
	if(!H) H=new node(x);
	if (H->elem==x) return;
	update(x<H->elem?H->left:H->right,x);
}
void inorder(node *H, string p="\n")
{
	if(H)
	{
		inorder(H->left,p+"\t");
		cout<<p<<H->elem;
		inorder(H->right,p+"\t");
	}
}
int Max(node*H)
{
	if(!H) return -INT_MAX;
	return H->right?Max(H->right):H->elem;
}
int Min(node*H)
{
	if(!H) return INT_MAX;
	return H->left?Min(H->left):H->elem;
}
void remove(node *&H,int x)
{
	if(!H) return;
	if(H->elem!=x) return remove(x<H->elem?H->left:H->right,x);
	if(!H->left) H=H->right;
	else if(!H->right) H=H->left;
	else
	{
		H->elem=Max(H->left);
		remove(H->left,H->elem);
	}
}
int main() {
	freopen("data.txt","r",stdin);
int n,x;
cin>>n;
node*root=0;
while(n--)
{
	cin>>x;
	update(root,x);
}
cout<<"\n Cay tim kiem nhi phan :\n\n";
inorder(root);
cout<<"\nMax: "<< Max(root);
cout<<"\nMin: "<<Min(root);
remove(root,73);
cout<<"\nCay tknp sau khi xoa: \n\n"; inorder(root);
}
