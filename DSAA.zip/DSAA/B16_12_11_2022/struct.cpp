
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
struct node
{
	T elem;
	node *left,*right;
	node(int e){ elem=e;left=right=0;
}
};
template<class T>
void update(node<T>*&H, int x)
{
	if(!H) H=new node<T>(x);
	if (H->elem==x) return;
	update(x<H->elem?H->left:H->right,x);
}
template<class T>
void inorder(node<T> *H, string p="\n")
{
	if(H)
	{
		inorder(H->left,p+"\t");
		cout<<p<<H->elem;
		inorder(H->right,p+"\t");
	}
}
template<class T>
int Max(node*H)
{
	if(!H) return -INT_MAX;
	return H->right?Max(H->right):H->elem;
}
template<class T>
int Min(node*H)
{
	if(!H) return INT_MAX;
	return H->left?Min(H->left):H->elem;
}
int main() {


}
