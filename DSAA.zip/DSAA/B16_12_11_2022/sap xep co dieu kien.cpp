
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
// sap xep co dieu kien
//4 7 2 8 4 9 3 6
//-> 3 6 9 4 4 7 2 8
bool ss(int a, int b) // ham so sanh
{
	return a%3==b%3? a<b:a%3<b%3;
}
// C3:
struct SS  // doi tuong so sanh
{
   	bool operator()(int a,int b){return a%3==b%3? a<b:a%3<b%3;}
   	
};
int main() {
int n; cin>>n;
int a[n];
for(auto &x:a) cin>>x;
sort(a,a+n,greater<int>()); //C1:
//sort(a,a+n,[](int a, int b){return a%3==b%3? a<b:a%3<b%3;});    //lambda C2:
// C3:
//sort(a,a+n,SS());
for(int i=1;i<=8;i++) a[i]+=i; 
cout<<*max_element(a,a+n)+2;
//for(auto x:a) cout<<x<<" ";

}
