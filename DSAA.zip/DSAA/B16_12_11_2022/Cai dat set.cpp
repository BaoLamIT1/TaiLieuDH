// cai dat set
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;

      
int main() {
multiset<int,greater<int> > S;
for(int x:{4,7,2,8,4,8,3,2}) S.insert(x);

cout<<"\n S: " ;for(auto s:S) cout<<s<<" ";
S.erase(4);
auto it=S.begin();it++;
S.erase(it);
cout<<"\n S : " ; for(auto s:S) cout<<s<<" ";
}
