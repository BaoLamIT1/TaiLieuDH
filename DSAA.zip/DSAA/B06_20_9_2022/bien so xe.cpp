
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;

      
int main() {
map<string,int> M;
M["Ha Noi"]=29;
M["Hai Phong"]=16;
M["Thai Binh"]=17;
//cout<<M["Ha Noi"]
string s;
getline(cin,s);
if(M.find(s) == M.end()) cout<<"not found";
else cout<<M[s];


}