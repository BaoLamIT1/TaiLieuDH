//Khoi luong hoa chat
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;

      
int main() {
map <char, int> K={{'C',12},{'H',1},{'O',16},{'(',0}};
string x; getline(cin,x);
stack <int> s;
for(auto c:x)
if(K.find(c)!=K.end()) s.push(K[c]);
else if('0'<=c && c<='9')   s.top() *=c-'0';
else //')'
{
int t=0; while (s.top()) {
	t+=s.top(); s.pop();
}}	
int t=0; while(s.size()){
	t+=s.top();s.pop();
}
cout<<t;
}

