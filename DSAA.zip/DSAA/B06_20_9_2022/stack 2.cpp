
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;      
int main() {
	bool ok=1;     
	unordered_map<char,char> M= {{'(',')'}, {'[',']'}, {'{','}'}};
	unordered_map<char,char> prior={{'(', 1} ,{'[',2}, {'{', 3}};
string s; getline(cin,s);
stack<char> st;
for(char c:s)
if(c=='(' || c== '{') st.push(c);
else if(c==')')
{
	if(st.empty()or st.top()!='('){
	 ok =0;break;}
else st.pop();
}

else if(c=='}')
{
	if(st.empty()or st.top()!='}'){
	 ok =0;break;}
else st.pop();
}
else if(c==']')
{
	if(st.empty()or st.top()!='['){
	 ok =0;break;}
else st.pop();
}
cout<<(st.empty() and ok?"hop le:":"khong hop le");

}
