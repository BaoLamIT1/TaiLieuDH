//ci dat stack bang mang
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
template <class T>
class Stack{
	int n, cap;  // n-size, cap-capacity
	T *buf;
	public:
		 Stack(){
		 	n=cap=0;
		 	buff=NULL;
		 }
		 bool empty(){return n==0;}
		 int  size(){ return n;}
		 void pop(){n--;}
		 T &top(){ return buf[n-1];}	//&: read-write function
		 void push(T,x)
		 {
		 	if(n==cap)//full
		 }
};
int main() {


}
