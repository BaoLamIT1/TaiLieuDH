//Nhap n chuyen n thanh so nhi phan
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
int main() {
long long n; 
stack <int> S;
cin>>n;
while (n>0)
{
	S.push(n%2);
	n/=2;
}
while(S.size()){
cout<<S.top(); 
S.pop();
}
}
