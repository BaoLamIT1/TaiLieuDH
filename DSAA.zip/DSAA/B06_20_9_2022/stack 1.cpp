
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
int main() {
stack<int>s;
for(int x:{4,7,2,8,1,6}) s.push(x);
s.top()=9; // top: truy cap toi phan tu cuoi cung( o dinh? stack) thay 6=9
while (s.size()!=0) //size: tra lai so phan tu hien luu tru trong stack
{
	cout<<s.top()<<" "; // top : vua doc vua ghi
	s.pop();   // pop: lay ra va tra lai phan tu dc bo sung vao cuoi cung cua stack
}
return 0;
}
