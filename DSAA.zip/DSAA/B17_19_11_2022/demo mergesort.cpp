
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
      /* MERGE SORT VERSION 1
      int b[123525];
void mergesort(int *a, int L, int R) //sap xep A[l] ..a[R-1]
{
   if(L>=R-1) return;  // suy bien
   int M=(L+R)/2;
   mergesort(a,L,R);
   mergesort(a,M,R);
   //int b[R+5];
   for(int i=L,j=M,k=L;k<R;k++)
      b[k]=j>=R || (i<M && a[i]<a[j])?a[i++]:a[j++];
   for(int k=L;k<R;k++) a[k]=b[k];
      
}
  */  
  // MERGESORT VERSION 2
  /*
 int b[123525];
void mergesort( int *L, int *R, int *b) //sap xep A[l] ..a[R-1]
{
  if(L>=R-1) return;  // suy bien
  int *M=L+(R-L)/2;
  mergesort(L,M,b);
  mergesort(M,R,b);
  for(int *i=L,*j=M,*k=b;k<b+(R-L);k++)
   *k=j>=R ||(i<M && *i<*j)?*i++:*j++;
   for(int *k=L,*p=b;k<R;k++) *k=*p++;

}
void ms(int *L, int *R)
{
	int *b=new int[R-L+5];
	mergesort(L,R,b);
	delete []b;
}
int main() {
int a[]={23,64,74,68,38,78,86,62,43,28,39,18}, n=sizeof(a)/sizeof(int);
ms(a,a+n);
for(auto z:a) cout<<z<<" ";
}
*/
// MERGESORT LAST VERSION
 template<class T, class CMP>
 void mergesort(T *L,T *R,T *b, CMP ss)
 {
 	if(L>=R-1)
 }