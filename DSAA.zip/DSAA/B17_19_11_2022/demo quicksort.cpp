
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;
      /*  VERSION 1
void quicksort(int *a, int L, int R) // sx a[L]...a[R-1]
{
   if(L+1>=R) return ;
   swap(a[L],a[(L+R)/2]);
   int i=L;
   for(int j=L+1;j<R;j++)
   if(a[j]<a[L]) swap(a[++i],a[j]);
   swap(a[L],a[i]);
   quicksort(a,L,i);	
	quicksort(a,i+1,R);
}
int main() {
	int a[]={23,64,74,68,38,78,86,62,43,28,39,18}, n=sizeof(a)/sizeof(int);
	quicksort(a,0,n);
	for(auto z:a) cout<<z<<" ";

}
      */
      
      /*  VERSION 2
void quicksort( int *L, int *R) // sx a[L]...a[R-1]
{
   if(L+1>=R) return ;
   swap(*L,*(L+(R-L)/2));
   int *i=L;
   for(int *j=L+1;j<R;j++)
   if(*j<*L) swap(*++i,*j);
   swap(*L,*i);
   quicksort(L,i);	
	quicksort(i+1,R);
	
}      
      
int main() {
	int a[]={23,64,74,68,38,78,86,62,43,28,39,18}, n=sizeof(a)/sizeof(int);
	quicksort(a,a+n);
	for(auto z:a) cout<<z<<" ";

}
       */
       
    
    template <class T,class CMP =less<T> >
void quicksort(T *L,T *R,CMP ss=less<T>() )//con trỏ L đến con trỏ R-1
{
    if(L+1>=R) return;//suy biến thì thoát
    swap(*L,*(L+(R-L)/2));//Chọn chốt là phần tử ở giữa đổi lên đầu
    T *i=L;//chạy i từ L - lưu vị trí các số nhỏ hơn chốt
    for(T *j=L+1;j<R;j++)//duyệt con trỏ j: L+1 -> R-1
    if(ss(*j,*L)) swap(*++i,*j);
    //Nếu ss đúng -> đổi phần từ *j với *i
    swap(*L,*i);//Đổi lại chốt
    quicksort(L,i,ss);//Gọi đệ quy nửa trái
    quicksort(i+1,R,ss);//Gọi đệ quy nửa phải
}

 int main() {
	int a[]={23,64,74,68,38,78,86,62,43,28,39,18}, n=sizeof(a)/sizeof(int);
	quicksort(a,a+n);
	for(auto z:a) cout<<z<<" ";

}  
    
    
    
    
    
    
    
    
    
