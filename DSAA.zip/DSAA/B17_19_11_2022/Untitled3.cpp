//QUICK SORT
/*
TH1: Suy biến L>=R-1 thì chỉ có <=1 phần tử -> xong
TH2: L<R-1

1. Chia : + Chon x bat ky a1....aR-1 làm pt chốt
          + Phân hoạch a1....aR-1
2. Trị  : Đệ quy sx nửa trái a1....aM-1
                 sx nửa phải aM+1...aR-1
3. Lk : do nothing

  // MINH HOA
  7 4 2 8 3 7 2 1 5
  
  // Đánh giá độ phức tạp
  