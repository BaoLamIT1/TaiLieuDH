
/*Bt : cho a(0),a(1), ....a(n-2),a(n-1). Hay sx tang hoac giam
Idea: Chia để trị( Divide and conquer)
TH1: Suy biến L>=R-1 thì chỉ có <=1 phần tử -> xong
TH2: L<R-1

1. Chia mảng 2 nửa bằng nhau bởi để chia M=(L+R)/2
2. Trị : Đệ quy - Sx tăng dần a1 .... a(m-1)
                - sx tang dần a(m) .... a(r-1)
3. Lket: Trộn 2 nửa tăng thành dãy tăng

      MINH HOẠ
    0 1 2 3 | 4 5 6 7 8
    4 7 2 8 | 4 8 3 2 5
           /  \
    4 7 2 8   4 8 3 2 5
    4 7|2 8   (4 8)|(2 3 5)
    /\           /  \
4 7   2 8     4 8    3| 2 5
4|7              4 8    / \ 
 /\                    3   2 5
4  7 


* Đánh giá độ phức tạp
 Pros: Nhanh, Dễ song song hoá
 Cons: Dùng bộ nhớ phụ