
#include<iostream>
#include<bits/stdc++.h>
      using namespace std;

      
int main() {
map <char, int> ut{{'(',1},{'[',2}, {'{',3}, {')',1} , {']',2}, {'}',3}};
map <char, int> mp{{'(',')'}, {'[',']'},{'{','}'}};
int t; cin>>t;
while(t--)
{
	stack <char>s;
	string x; cin>>x;
	int check =1;
	for(char c:x)
	{
		if(c=='('||c=='['|| c=='{')
		{
			if(s.size() && ut[c]>ut[s.top()])
			{
				check=0;
				break;
			}
			s.push(mp[c]);
		}
		else 
		{
			if(s.empty() || s.top()!=c)
			{
				check=0;
				break;
			}
		else s.pop();	
		}
	}
	if(check ==1 && s.empty()) cout<<"Dung"<<endl;
		else cout<<"Sai"<<endl;
}

}
