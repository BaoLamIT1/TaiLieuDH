//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Test01_6_3.rc
//
#define IDC_MYICON                      2
#define IDD_TEST0163_DIALOG             102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_TEST0163                    107
#define IDI_SMALL                       108
#define IDC_TEST0163                    109
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define ID_H32771                       32771
#define ID_H32772                       32772
#define ID_H32773                       32773
#define ID_H_TGV                        32774
#define ID_H_HCN                        32775
#define ID_H_CHORD                      32776
#define ID_M32777                       32777
#define ID_M32778                       32778
#define ID_KI32779                      32779
#define ID_KI32780                      32780
#define ID_M_RED                        32781
#define ID_M_YELLOW                     32782
#define ID_KV_NETDUT                    32783
#define ID_KI32784                      32784
#define ID_KV_NETLIEN                   32785
#define ID_H32786                       32786
#define ID_H_EXIT                       32787
#define ID_M32788                       32788
#define ID_M32789                       32789
#define ID_M32790                       32790
#define ID_M32791                       32791
#define ID_NEN_GREEN	               32792
#define ID_NEN_PURPLE                   32793
#define ID_NEN_BLUE                     32794
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32795
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
